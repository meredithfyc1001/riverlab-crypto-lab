from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
evidence = Path(__file__).resolve().parent
checks = [
    ('legacy_reference_check.py', []),
    ('statistics_reference.py', ['--check']),
    ('phase2b_reference.py', ['--check']),
    ('research_reference.py', ['--check']),
    ('replay_reference.py', ['--check']),
    ('risk_reference.py', ['--check']),
    ('rules_reference.py', ['--check']),
    ('portfolio_reference.py', ['--check']),
    ('shared_pool_reference.py', ['--check']),
    ('market_regime_reference.py', ['--check']),
    ('advanced_research_reference.py', ['--check']),
    ('test_phase6c_bundle.py', []),
]
with (evidence / 'python-references.log').open('w') as file:
    for filename, arguments in checks:
        command = [sys.executable, '-B', 'tests/reference/' + filename, *arguments]
        print(' '.join(command), file=file, flush=True)
        subprocess.run(command, cwd=root, check=True, stdout=file, stderr=subprocess.STDOUT)
        print('PASS', filename, file=file, flush=True)
