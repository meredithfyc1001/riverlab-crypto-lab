# Phase 5B 五秒显示断言复核

本目录记录 Phase 6C-B 开工前对 #18 基线的复核。源提交为 `bbb8bbbb0cdbec08959b23a46fbf0b2dcf65fb3b`。主机为 Linux 6.18.57，容器可见 5 个逻辑 CPU，配额 4 核、16 GiB 内存，Node v24.19.0，Playwright 1.64.1，实际浏览器为 Debian 系统 Chromium 154.0.8037.57。CSV 和浏览器 profile 均由测试创建。全部项目 E2E 使用生产构建，各次完整运行使用仓库默认的两名 Playwright worker，未设置测试重试。

## 历史证据

`pr18-original-account.json` 保存本次复核时抓取的 [#18 PR 正文](https://github.com/meredithfyc1001/riverlab-crypto-lab/pull/18)。先前完整 E2E 首轮为 75/77，单独复核 2C 后累计为 76/77。5B 的五秒断言在同机的 #17 也曾复现。先前将等待设为十二秒进行诊断时，完整就绪耗时 5.396 秒，主线程最大间隔 565.4 毫秒。历史批次原始 trace 未见于该 SHA 的受版本控制文件，本目录中的失败 trace 来自本次运行。

## 本次原始提交复验

| 运行及日志 | 结果 |
| --- | --- |
| `npm ci --no-audit`，`npm-ci.log` | 安装 263 个锁定依赖 |
| `npm run build`，`build.log` | 严格类型检查及生产构建通过 |
| `playwright test tests/e2e/phase-5b.spec.ts --grep 50,000 --workers=1 --repeat-each=3`，`e2e-5b.log` | 三次均通过。50,000 根 K 线、双侧共 10 个条件。结果和全部曲线就绪分别耗时 3230、4033、3838 ms，主线程最大间隔分别 388.1、444.8、363.8 ms |
| `npm run check`，`check.log` | 格式、lint、Vitest 728/728、类型检查和构建通过。77 项 E2E 共通过 75 项。5A 风险样本准备和 5B 均在等待回测成功提示时超时。该次部分测试时段同机有 Rust 编译 |
| `npm run test:e2e`，`e2e-full-quiet.log` | Rust 工作完成后，相同提交重跑全部 77 项，77/77 通过。5B 全点曲线就绪 4710 ms，主线程间隔最大 415.8 ms |

## 超时 trace

`first-integration-timeline.json` 以 Playwright 断言开始时的单调时钟为零点。5A 的一帧在 4408.068 ms 时显示完整成功提示，5B 的一帧在 4485.062 ms 时显示相同提示。两项断言仍分别在 5011.513、5004.582 ms 返回失败。各自的目录保留 `trace.zip`、错误上下文、失败截图及解出的可见帧。上述数字是已可见的观测时刻，第一次绘制可能更早。可对照 `playwright-1.64.1-excerpts.txt` 和本地锁定依赖。Playwright 的 locator expect 初读后执行退避重试，最后以 500 ms 间隔轮询。捕获的这两项超时漏报了已出现的提示。

在第一版仅修改 5A/5B 的补丁复验中，未变动的 2C 同一断言也超时。同期 trace 中成功提示已在 4635.293 ms 清晰可见，见 `first-observer-iteration/phase-2c/`。第一版的修改、运行日志和新失败单独留存。最终本地补丁将该计时修正同时应用于 2C、5A 和 5B。

## 本地修复候选

`backtest-success-observer.patch` 调整 2C、5A 和 5B 测试观察成功提示的方式。在所点击按钮上预注册帧观察，从真实 click 开始，以页面单调时钟度量原五秒上限。观察目标必须是完整成功提示，具有可见布局。过期、隐藏或沿用旧成功提示会失败。取得本次观察后，用精确文本 locator 立刻核对可见性。现有全点曲线检查、20 秒总量和 1000 ms 主线程间隔门槛均保留。

`boundary-reproducer/` 保存六种独立页面输入、配置与日志。4700 ms 显示通过。5200 ms 才显示、错误文本、永久隐藏、4300 ms 开始阻塞主线程 950 ms 后才显示和已有旧提示均按预期失败。六个判断全部符合预期。在安装过项目锁定依赖的独立副本中，将此目录复制到 `work/assertion-reproducer`，可用与本次相同的命令复验。

```sh
CI=1 PLAYWRIGHT_CHROMIUM_EXECUTABLE=/usr/bin/chromium npx --no-install playwright test --config work/assertion-reproducer/playwright.config.ts
```

校验补丁和项目回归时可在 #18 的独立工作树执行以下命令。

```sh
git apply --check /path/to/backtest-success-observer.patch
git apply /path/to/backtest-success-observer.patch
npm ci
CI=1 PLAYWRIGHT_CHROMIUM_EXECUTABLE=/usr/bin/chromium npm run check
```

## 最终候选实测

另一份从完整 #18 SHA 建立的隔离工作树已应用最终补丁。单独执行 `npm ci` 恢复 263 个锁定依赖。完整 `npm run check` 以 0 退出，格式检查、零警告 lint、56 个文件共 728 项 Vitest、严格类型检查和生产构建均通过。Linux 系统 Chromium 以两名 Playwright worker 运行 77 项 E2E，77/77 通过，耗时 3.8 分钟。2C 从运行至全点曲线就绪 4798 ms，主线程最大间隔 468.5 ms。5B 相应为 4570 ms、447.3 ms。5A 的 200 万步风险计算耗时 7825 ms，主线程最大间隔 95.2 ms。见 `final-npm-ci.log` 与 `final-patched-check.log`。六个边界场景单列在此项目检查之外。本地候选未写入 #18。
