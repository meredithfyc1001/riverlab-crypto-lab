# GitHub Actions 计费注释

[PR #17 的 Windows ZIP 作业](https://github.com/meredithfyc1001/riverlab-crypto-lab/actions/runs/45788772852/job/140314700782) · run `45788772852`，第 4 次尝试，job `140314700782`。

用户在本次审查中提供了已登录 GitHub 作业页面的截图。页面列出 `Windows local test ZIP / Chrome + Edge`，Annotations 有 1 条错误。截图保留了以下原文。

> The job was not started because recent account payments have failed or your spending limit

页面在此之后截断，并显示 “Show more”。这证实 GitHub 以账户付款或支出限额为由拒绝启动该作业。注释并列两个原因，无法据此判定是具体哪笔付款或哪项限额，也没有证据表明 Windows 测试本身执行后失败。GitHub 作业元数据另证实 runner ID 为零且步骤列表为空。本文件记录可见截图文字，原图见本次聊天。

[PR #18 的 Windows Chrome 作业](https://github.com/meredithfyc1001/riverlab-crypto-lab/actions/runs/45938207463/job/140314719657) · run `45938207463`，第 3 次尝试，job `140314719657`。

用户另提供了该作业的注释截图和本次运行的作业总览。`Check / windows-latest / chrome` 同样出现上面的 GitHub 计费错误前缀，页面也显示 1 条错误。总览列出六个失败的前置作业，Windows ZIP 和 Verified Windows distribution 显示跳过。六个前置作业的零步骤和未分配 runner 另见 `github-baseline.json`。截图直接核实的是该 Windows Chrome 作业的计费原因。
