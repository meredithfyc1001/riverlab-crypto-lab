// scripts/phase6c/recompute.ts
import assert2 from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { DatabaseSync } from "node:sqlite";
import { isDeepStrictEqual } from "node:util";

// node_modules/@noble/hashes/_u64.js
var fromNumH = (n) => n / 2 ** 32 | 0;
var fromNumL = (n) => n >>> 0;
function setU64FromNum(view, byteOffset, n, isLE) {
  const h = fromNumH(n);
  const l = fromNumL(n);
  view.setUint32(byteOffset, isLE ? l : h, isLE);
  view.setUint32(byteOffset + 4, isLE ? h : l, isLE);
}

// node_modules/@noble/hashes/utils.js
function isBytes(a) {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in a && a.BYTES_PER_ELEMENT === 1;
}
var atitle = (title) => title ? `"${title}" ` : "";
function anumber(n, title = "") {
  if (typeof n !== "number")
    throw new TypeError(atitle(title) + "expected number, got " + typeof n);
  if (!Number.isSafeInteger(n) || n < 0)
    throw new RangeError(atitle(title) + "expected integer >= 0, got " + n);
  return n;
}
function abytes(value, length, title = "") {
  if (isBytes(value) && (length === void 0 || value.length === length))
    return value;
  if (length !== void 0)
    anumber(length, "length");
  const bytes = isBytes(value);
  const ofLen = length !== void 0 ? ` of length ${length}` : "";
  const got = bytes ? `length=${value.length}` : `type=${typeof value}`;
  const message2 = atitle(title) + "expected Uint8Array" + ofLen + ", got " + got;
  if (!bytes)
    throw new TypeError(message2);
  throw new RangeError(message2);
}
var aobject = (value, label) => {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    throw new TypeError((label === "object" ? "" : `"${label}" `) + "expected object, got type=" + typeof value);
};
var aopts = (value, label) => {
  aobject(value, label);
  const proto = Object.getPrototypeOf(value);
  if (proto !== Object.prototype && proto !== null)
    throw new TypeError(`"${label}" expected plain object`);
  if (Object.hasOwn(value, "__proto__"))
    throw new TypeError(`"${label}.__proto__" is not allowed`);
};
function aexists(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("hash was destroyed");
  if (checkFinished && instance.finished)
    throw new Error("digest() was already called");
}
function aoutput(out, instance) {
  abytes(out, void 0, "output");
  const min = instance.outputLen;
  if (!(out.length >= min)) {
    throw new RangeError('"output" expected length >= ' + min);
  }
}
function clean(...arrays) {
  for (let i = 0; i < arrays.length; i++) {
    arrays[i].fill(0);
  }
}
function createView(arr) {
  return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
function rotr(word, shift) {
  return word << 32 - shift | word >>> shift;
}
var hasHexBuiltin = /* @__PURE__ */ (() => (
  // @ts-ignore
  typeof Uint8Array.from([]).toHex === "function" && typeof Uint8Array.fromHex === "function"
))();
var hexes = /* @__PURE__ */ Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, "0"));
function bytesToHex(bytes) {
  abytes(bytes);
  if (hasHexBuiltin)
    return bytes.toHex();
  let hex = "";
  for (let i = 0; i < bytes.length; i++) {
    hex += hexes[bytes[i]];
  }
  return hex;
}
function checkOpts(defaults, opts, title = "opts") {
  aopts(defaults, "defaults");
  if (opts !== void 0)
    aopts(opts, title);
  const merged = Object.assign(/* @__PURE__ */ Object.create(null), defaults, opts);
  return merged;
}
function createHasher(hashCons, info = {}) {
  if (typeof hashCons !== "function")
    throw new TypeError('"hashCons" expected function, got type=' + typeof hashCons);
  info = checkOpts({}, info, "info");
  const hashC = (msg, opts) => hashCons(opts).update(msg).digest();
  const tmp = hashCons(void 0);
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.canXOF = tmp.canXOF;
  hashC.create = (opts) => hashCons(opts);
  Object.assign(hashC, info);
  return Object.freeze(hashC);
}
var oidNist = (suffix) => ({
  // Current NIST hashAlgs suffixes used here fit in one DER subidentifier octet.
  // Larger suffix values would need base-128 OID encoding and a different length byte.
  oid: Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2, suffix])
});

// node_modules/@noble/hashes/_md.js
function Chi(a, b, c) {
  return a & b ^ ~a & c;
}
function Maj(a, b, c) {
  return a & b ^ a & c ^ b & c;
}
var HashMD = class {
  blockLen;
  outputLen;
  canXOF = false;
  padOffset;
  isLE;
  // For partial updates less than block size
  buffer;
  view;
  finished = false;
  length = 0;
  pos = 0;
  destroyed = false;
  constructor(blockLen, outputLen, padOffset, isLE) {
    this.blockLen = blockLen;
    this.outputLen = outputLen;
    this.padOffset = padOffset;
    this.isLE = isLE;
    this.buffer = new Uint8Array(blockLen);
    this.view = createView(this.buffer);
  }
  update(data) {
    aexists(this);
    abytes(data);
    const { view, buffer, blockLen } = this;
    const len = data.length;
    let processed = false;
    for (let pos = 0; pos < len; ) {
      const take = Math.min(blockLen - this.pos, len - pos);
      if (take === blockLen) {
        const dataView = createView(data);
        for (; blockLen <= len - pos; pos += blockLen)
          this.process(dataView, pos);
        processed = true;
        continue;
      }
      buffer.set(pos === 0 && take === len ? data : data.subarray(pos, pos + take), this.pos);
      this.pos += take;
      pos += take;
      if (this.pos === blockLen) {
        this.process(view, 0);
        this.pos = 0;
        processed = true;
      }
    }
    this.length += data.length;
    if (processed)
      this.roundClean();
    return this;
  }
  digestInto(out) {
    aexists(this);
    aoutput(out, this);
    this.finished = true;
    const { buffer, view, blockLen, isLE } = this;
    let { pos } = this;
    buffer[pos++] = 128;
    buffer.fill(0, pos);
    if (this.padOffset > blockLen - pos) {
      this.process(view, 0);
      buffer.fill(0);
    }
    setU64FromNum(view, blockLen - 8, this.length * 8, isLE);
    this.process(view, 0);
    this.roundClean();
    const oview = out === buffer ? view : createView(out);
    const len = this.outputLen;
    const outLen = len / 4;
    const state = this.get();
    if (len % 4 || outLen > state.length)
      throw new Error("invalid outputLen");
    for (let i = 0; i < outLen; i++)
      oview.setUint32(4 * i, state[i], isLE);
  }
  digest() {
    const { buffer, outputLen } = this;
    this.digestInto(buffer);
    const res = buffer.slice(0, outputLen);
    this.destroy();
    return res;
  }
  _cloneIntoMeta(to) {
    const { buffer, length, finished, destroyed, pos } = this;
    to.destroyed = destroyed;
    to.finished = finished;
    to.length = length;
    to.pos = pos;
    if (pos)
      to.buffer.set(buffer);
    return to;
  }
  clone() {
    return this._cloneInto();
  }
};
var SHA256_IV = /* @__PURE__ */ Uint32Array.from([
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
]);

// node_modules/@noble/hashes/sha2.js
var SHA256_K = /* @__PURE__ */ Uint32Array.from([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]);
var SHA256_W = /* @__PURE__ */ new Uint32Array(64);
var SHA2_32B = class extends HashMD {
  // We cannot use array here since array allows indexing by variable
  // which means optimizer/compiler cannot use registers.
  // Numeric initializers matter: starting the fields as `undefined` changes
  // V8's field representation and makes sha256 3x slower (measured).
  A = 0;
  B = 0;
  C = 0;
  D = 0;
  E = 0;
  F = 0;
  G = 0;
  H = 0;
  constructor(outputLen, IV) {
    super(64, outputLen, 8, false);
    this.A = IV[0] | 0;
    this.B = IV[1] | 0;
    this.C = IV[2] | 0;
    this.D = IV[3] | 0;
    this.E = IV[4] | 0;
    this.F = IV[5] | 0;
    this.G = IV[6] | 0;
    this.H = IV[7] | 0;
  }
  get() {
    const { A, B, C, D, E, F, G, H } = this;
    return [A, B, C, D, E, F, G, H];
  }
  // prettier-ignore
  set(A, B, C, D, E, F, G, H) {
    this.A = A | 0;
    this.B = B | 0;
    this.C = C | 0;
    this.D = D | 0;
    this.E = E | 0;
    this.F = F | 0;
    this.G = G | 0;
    this.H = H | 0;
  }
  _cloneInto(to) {
    (to ||= new this.constructor()).set(...this.get());
    return this._cloneIntoMeta(to);
  }
  process(view, offset) {
    for (let i = 0; i < 16; i++, offset += 4)
      SHA256_W[i] = view.getUint32(offset, false);
    for (let i = 16; i < 64; i++) {
      const W15 = SHA256_W[i - 15];
      const W2 = SHA256_W[i - 2];
      const s0 = rotr(W15, 7) ^ rotr(W15, 18) ^ W15 >>> 3;
      const s1 = rotr(W2, 17) ^ rotr(W2, 19) ^ W2 >>> 10;
      SHA256_W[i] = s1 + SHA256_W[i - 7] + s0 + SHA256_W[i - 16] | 0;
    }
    let { A, B, C, D, E, F, G, H } = this;
    for (let i = 0; i < 64; i++) {
      const sigma1 = rotr(E, 6) ^ rotr(E, 11) ^ rotr(E, 25);
      const T1 = H + sigma1 + Chi(E, F, G) + SHA256_K[i] + SHA256_W[i] | 0;
      const sigma0 = rotr(A, 2) ^ rotr(A, 13) ^ rotr(A, 22);
      const T2 = sigma0 + Maj(A, B, C) | 0;
      H = G;
      G = F;
      F = E;
      E = D + T1 | 0;
      D = C;
      C = B;
      B = A;
      A = T1 + T2 | 0;
    }
    A = A + this.A | 0;
    B = B + this.B | 0;
    C = C + this.C | 0;
    D = D + this.D | 0;
    E = E + this.E | 0;
    F = F + this.F | 0;
    G = G + this.G | 0;
    H = H + this.H | 0;
    this.set(A, B, C, D, E, F, G, H);
  }
  roundClean() {
    clean(SHA256_W);
  }
  destroy() {
    this.destroyed = true;
    this.set(0, 0, 0, 0, 0, 0, 0, 0);
    clean(this.buffer);
  }
};
var _SHA256 = class extends SHA2_32B {
  constructor() {
    super(32, SHA256_IV);
  }
};
var sha256 = /* @__PURE__ */ createHasher(
  () => new _SHA256(),
  /* @__PURE__ */ oidNist(1)
);

// src/core/backtests/identity.ts
function canonicalJson(value) {
  const encode = (v) => {
    if (v === null || typeof v === "boolean" || typeof v === "string")
      return JSON.stringify(v);
    if (typeof v === "number" && Number.isFinite(v)) return JSON.stringify(v);
    if (Array.isArray(v)) return `[${v.map(encode).join(",")}]`;
    if (v && typeof v === "object" && Object.getPrototypeOf(v) === Object.prototype)
      return `{${Object.keys(v).sort().map(
        (k) => `${JSON.stringify(k)}:${encode(v[k])}`
      ).join(",")}}`;
    throw new Error("Identity requires finite, plain JSON values.");
  };
  return encode(value).replace(
    /[\u007f-\uffff]/g,
    (c) => `\\u${c.charCodeAt(0).toString(16).padStart(4, "0")}`
  );
}
function forEachCanonicalChunk(value, consume) {
  let ascii = "";
  const flush = () => {
    const bytes = new Uint8Array(ascii.length);
    for (let i = 0; i < ascii.length; i++) bytes[i] = ascii.charCodeAt(i);
    consume(bytes);
    ascii = "";
  };
  const escaped = /* @__PURE__ */ new Map();
  const plainAscii = /^[\x20-\x21\x23-\x5b\x5d-\x7e]*$/;
  const quote = (value2) => {
    if (plainAscii.test(value2)) return '"' + value2 + '"';
    const cached = escaped.get(value2);
    if (cached !== void 0) return cached;
    const encoded = JSON.stringify(value2).replace(
      /[\u007f-\uffff]/g,
      (c) => `\\u${c.charCodeAt(0).toString(16).padStart(4, "0")}`
    );
    if (escaped.size < 2048) escaped.set(value2, encoded);
    return encoded;
  };
  const encode = (v) => {
    if (typeof v === "string") {
      ascii += quote(v);
    } else if (v === null || typeof v === "boolean" || typeof v === "number" && Number.isFinite(v)) {
      ascii += String(v);
    } else if (Array.isArray(v)) {
      ascii += "[";
      for (let i = 0; i < v.length; i++) {
        if (i) ascii += ",";
        if (i in v) encode(v[i]);
      }
      ascii += "]";
    } else if (v && typeof v === "object" && Object.getPrototypeOf(v) === Object.prototype) {
      ascii += "{";
      const keys = Object.keys(v).sort();
      for (let i = 0; i < keys.length; i++) {
        const key = keys[i];
        if (i) ascii += ",";
        ascii += quote(key) + ":";
        encode(v[key]);
      }
      ascii += "}";
    } else {
      throw new Error("Identity requires finite, plain JSON values.");
    }
    if (ascii.length >= 64 * 1024) flush();
  };
  encode(value);
  if (ascii.length) flush();
}
function contentHash(value) {
  const hash3 = sha256.create();
  forEachCanonicalChunk(value, (bytes) => {
    hash3.update(bytes);
  });
  return Array.from(hash3.digest(), (b) => b.toString(16).padStart(2, "0")).join(
    ""
  );
}

// scripts/phase6c/historical-fields.ts
import assert from "node:assert/strict";
var hashes = {
  dataset: ["file.sha256"],
  experiment: [
    "payloadHash",
    "payload.result.manifest.runHash",
    "payload.result.manifest.dataHash",
    "payload.result.manifest.signalHash"
  ],
  rule: ["ruleHash", "recordHash"],
  replay: [
    "payloadHash",
    "payload.sourceHash",
    "payload.resultHash",
    "payload.stateHash"
  ],
  risk: [
    "payloadHash",
    "payload.source.identity.payloadHash",
    "payload.source.dataHash",
    "payload.source.runHash"
  ],
  portfolio: ["recordHash", "payloadHash"],
  shared_pool: ["recordHash", "payloadHash"],
  regime: ["reportHash", "source.payloadHash"],
  advanced: [
    "reportHash",
    "input.ruleRecord.recordHash",
    "input.ruleRecord.ruleHash"
  ]
};
var comparisonPaths = {
  dataset: [],
  rule: ["id", "rule", "ruleHash", "recordHash"],
  experiment: [
    "payload.dataset",
    "payload.result.manifest",
    "payload.result.signals",
    "payload.result.orders",
    "payload.result.fills",
    "payload.result.closes",
    "payload.result.final",
    "payload.statistics",
    "payload.statistics.curve",
    "payloadHash"
  ],
  replay: [
    "payload.datasetId",
    "payload.sourceHash",
    "payload.config",
    "payload.risk",
    "payload.cursor",
    "payload.decisions",
    "payload.notes",
    "payload.resultHash",
    "payload.stateHash",
    "payloadHash"
  ],
  risk: [
    "payload.source",
    "payload.preview",
    "payload.simulation.settings",
    "payload.simulation.paths",
    "payload.simulation.quantiles",
    "payload.simulation.bands",
    "payload.simulation",
    "payloadHash"
  ],
  portfolio: [
    "input",
    "result.alignment",
    "result.assets",
    "result.curve",
    "result.fees",
    "result.fillCount",
    "result.netPnl",
    "payloadHash",
    "recordHash"
  ],
  shared_pool: [
    "input",
    "result.alignment",
    "result.orders",
    "result.allocations",
    "result.decisions",
    "result.rebalances",
    "result.assets",
    "result.curve",
    "result.fees",
    "payloadHash",
    "recordHash"
  ],
  regime: [
    "algorithmVersion",
    "modelVersion",
    "params",
    "reference",
    "source",
    "result.labels",
    "result.runs",
    "result.summaries",
    "result.netPnl",
    "reportHash"
  ],
  advanced: [
    "versions",
    "input",
    "input.ruleRecord",
    "result.plan",
    "result.folds",
    "reportHash"
  ]
};
function field(value, path) {
  return path.split(".").reduce((parent, key) => {
    assert(
      parent !== null && typeof parent === "object" && Object.hasOwn(parent, key),
      "\u7F3A\u5C11\u5DF2\u58F0\u660E\u5B57\u6BB5 " + path
    );
    return parent[key];
  }, value);
}

// scripts/phase6c/historical-relations.ts
function datasetIdentity(d) {
  const { candles, ...metadata2 } = d;
  return contentHash({ ...JSON.parse(JSON.stringify(metadata2)), candles });
}
function relationships(kind, row, read) {
  const links = [];
  function check(kind2, id, embedded, identify, required = false) {
    const target = read(kind2, id);
    const actual = target === void 0 ? void 0 : identify(target);
    links.push({
      kind: kind2,
      id,
      identity: embedded,
      actual,
      status: actual === void 0 ? required ? "MISSING" : "DETACHED" : actual === embedded ? "MATCH" : "CONFLICT"
    });
  }
  function dataset(value) {
    const d = value;
    check(
      "dataset",
      d.id,
      datasetIdentity(d),
      (value2) => datasetIdentity(value2)
    );
  }
  function strategy(value) {
    const config = value;
    if (config?.kind === "rules" && config.rule) {
      links.push({
        kind: "embedded-rule-v" + config.rule.revision,
        status: "EMBEDDED",
        identity: contentHash(config.rule)
      });
    }
  }
  function sourceAssets(input) {
    for (const asset of field(input, "assets")) {
      dataset(asset.dataset);
      strategy(asset.strategy);
    }
  }
  function reportSource(kind2, identity, names) {
    const identify = (source) => contentHash(Object.fromEntries(names.map((k) => [k, field(source, k)])));
    check(kind2, field(identity, "id"), identify(identity), identify);
  }
  switch (kind) {
    case "experiment":
      dataset(field(row, "payload.dataset"));
      strategy(field(row, "payload.result.manifest.strategy.config"));
      break;
    case "replay":
      check(
        "dataset",
        field(row, "payload.datasetId"),
        field(row, "payload.sourceHash"),
        (value) => datasetIdentity(value),
        true
      );
      break;
    case "risk": {
      reportSource("experiment", field(row, "payload.source.identity"), [
        "id",
        "name",
        "createdUtcMs",
        "elapsedMs",
        "payloadHash"
      ]);
      dataset(field(row, "payload.source.input.dataset"));
      strategy(field(row, "payload.source.input.strategy"));
      break;
    }
    case "regime": {
      const source = field(row, "source"), sourceType = field(source, "kind");
      const sourceKind = sourceType === "single" ? "experiment" : sourceType === "portfolio" ? "portfolio" : "shared_pool";
      reportSource(sourceKind, source, [
        "id",
        "name",
        "createdUtcMs",
        "payloadHash",
        sourceType === "single" ? "elapsedMs" : "recordHash"
      ]);
      if (sourceType === "single") {
        dataset(field(source, "input.dataset"));
        strategy(field(source, "input.strategy"));
      } else sourceAssets(field(source, "input"));
      break;
    }
    case "advanced": {
      dataset(field(row, "input.dataset"));
      const rule = field(row, "input.ruleRecord");
      check(
        "rule",
        field(rule, "id"),
        contentHash(rule),
        contentHash
      );
      break;
    }
    case "portfolio":
    case "shared_pool":
      sourceAssets(field(row, "input"));
      break;
  }
  return links;
}

// src/infrastructure/database-layouts.ts
var layouts = {
  dataset: ["riverlab-crypto-lab", "datasets"],
  experiment: ["riverlab-crypto-lab-experiments", "experiments"],
  rule: ["riverlab-crypto-lab-rules", "versions"],
  replay: ["riverlab-crypto-lab-replays", "replays"],
  risk: ["riverlab-crypto-lab-risk", "studies"],
  portfolio: ["riverlab-crypto-lab-portfolios", "experiments"],
  shared_pool: ["riverlab-crypto-lab-shared-pool", "experiments"],
  regime: ["riverlab-crypto-lab-market-regime", "reports"],
  advanced: ["riverlab-crypto-lab-advanced-research", "reports"]
};

// src/infrastructure/snapshot-value.ts
var MIB = 1024 * 1024;
var textEncoder = new TextEncoder();
var textChunk = 16 * 1024;
function* quoted(value) {
  yield '"';
  for (let offset = 0; offset < value.length; ) {
    let end = Math.min(offset + textChunk, value.length);
    if (end < value.length) {
      const last = value.charCodeAt(end - 1), next = value.charCodeAt(end);
      if (last >= 55296 && last <= 56319 && next >= 56320 && next <= 57343)
        end--;
    }
    yield JSON.stringify(value.slice(offset, end)).slice(1, -1);
    offset = end;
  }
  yield '"';
}
function optionalField(kind, parent, key) {
  if (kind !== "dataset") return false;
  if (parent.length === 1 && parent[0] === "source")
    return key === "url" || key === "expectedSha256";
  return parent.length === 3 && parent[0] === "quality" && parent[1] === "issues" && typeof parent[2] === "number" && parent[2] >= 0 && parent[2] < 1e3 && ["line", "field", "raw"].includes(key);
}
function plainObject(value) {
  const proto = Object.getPrototypeOf(value);
  return proto !== null && typeof proto === "object" && Object.getPrototypeOf(proto) === null && Object.hasOwn(proto, "constructor") && Function.prototype.toString.call(proto.constructor) === Function.prototype.toString.call(Object);
}
function sharedObjects(value) {
  const seen = /* @__PURE__ */ new WeakSet(), shared = /* @__PURE__ */ new WeakSet();
  function scan(node, depth) {
    if (typeof node !== "object" || node === null) return;
    if (depth > 64) throw new Error("\u7ED3\u6784\u5316\u514B\u9686\u5C42\u6570\u8D85\u8FC7 64\u3002");
    if (seen.has(node)) {
      shared.add(node);
      return;
    }
    seen.add(node);
    if (Array.isArray(node)) {
      for (let i = 0; i < node.length; i++) {
        const d = Object.getOwnPropertyDescriptor(node, i);
        if (!d || !("value" in d)) throw new Error("\u6570\u7EC4\u542B\u7A7A\u6D1E\u6216\u8BBF\u95EE\u5668\u3002");
        scan(d.value, depth + 1);
      }
    } else if (plainObject(node)) {
      for (const key of Object.getOwnPropertyNames(node)) {
        const d = Object.getOwnPropertyDescriptor(node, key);
        if (!("value" in d) || !d.enumerable)
          throw new Error("\u5BF9\u8C61\u542B\u8BBF\u95EE\u5668\u6216\u4E0D\u53EF\u679A\u4E3E\u5C5E\u6027\u3002");
        scan(d.value, depth + 1);
      }
    }
  }
  scan(value, 0);
  return shared;
}
function projection(value, kind, details) {
  const shared = sharedObjects(value);
  const firstPath = /* @__PURE__ */ new WeakMap();
  const active = /* @__PURE__ */ new WeakSet();
  let descriptorMinimum = 0;
  const charge = (items) => {
    descriptorMinimum += items.reduce(
      (n, item) => n + String(item).length + 1,
      2
    );
    if (descriptorMinimum > 20 * MIB) throw new Error("\u514B\u9686\u63CF\u8FF0\u8D85\u8FC7 20 MiB\u3002");
  };
  const path = [];
  function refuse(reason) {
    throw new Error(
      `\u7ED3\u6784\u5316\u514B\u9686\u65E0\u6CD5\u65E0\u635F\u4FDD\u5B58\uFF08${JSON.stringify(path)}\uFF09\uFF1A${reason}\u3002`
    );
  }
  function* visit(node, capture) {
    if (path.length > 64) refuse("\u5C42\u6570\u8D85\u8FC7 64");
    if (typeof node === "string") {
      yield* quoted(node);
      return;
    }
    if (node === null || typeof node === "boolean") {
      yield String(node);
      return;
    }
    if (typeof node === "number" && Number.isFinite(node) && !Object.is(node, -0)) {
      yield JSON.stringify(node);
      return;
    }
    if (typeof node !== "object" || node === null) refuse("\u65E0\u6CD5\u8868\u793A\u7684\u503C\u6216\u6570\u503C");
    if (active.has(node)) refuse("\u5FAA\u73AF\u5BF9\u8C61\u5F15\u7528");
    if (capture && shared.has(node)) {
      const target = firstPath.get(node);
      if (target) {
        charge(path);
        charge(target);
        details.aliases.push({ path: [...path], target });
        capture = false;
      } else firstPath.set(node, [...path]);
    }
    active.add(node);
    if (Object.getOwnPropertySymbols(node).length) refuse("\u542B Symbol \u5C5E\u6027");
    if (Array.isArray(node)) {
      for (const key in node) {
        if (Object.hasOwn(node, key) && (String(Number(key)) !== key || !Number.isInteger(Number(key)) || Number(key) < 0 || Number(key) >= node.length))
          refuse("\u6570\u7EC4\u542B\u975E\u7D22\u5F15\u5C5E\u6027");
      }
      yield "[";
      for (let i = 0; i < node.length; i++) {
        if (!Object.hasOwn(node, i)) refuse("\u6570\u7EC4\u542B\u7A7A\u6D1E");
        if (i) yield ",";
        path.push(i);
        yield* visit(node[i], capture);
        path.pop();
      }
      yield "]";
      active.delete(node);
      return;
    }
    if (!plainObject(node)) refuse("\u4EC5\u652F\u6301\u666E\u901A\u5BF9\u8C61\u548C\u7A20\u5BC6\u6570\u7EC4");
    const record = node;
    const keys = Object.keys(record);
    const undefinedKeys = [];
    for (const key of keys) {
      if (["__proto__", "constructor", "prototype"].includes(key))
        refuse("\u542B\u4FDD\u7559\u952E");
      const descriptor2 = Object.getOwnPropertyDescriptor(record, key);
      if (!("value" in descriptor2)) refuse("\u5C5E\u6027\u4E0D\u662F\u6570\u636E\u5C5E\u6027");
      if (descriptor2.value === void 0) {
        if (!optionalField(kind, path, key))
          refuse(`\u4E0D\u652F\u6301\u7684 undefined \u5C5E\u6027 ${key}`);
        undefinedKeys.push(key);
      }
    }
    if (capture && undefinedKeys.length) {
      charge(keys);
      charge(path);
      charge(undefinedKeys);
      details.objects.push({ path: [...path], keys, undefinedKeys });
    }
    yield "{";
    let emitted = false;
    for (const key of keys) {
      if (record[key] === void 0) continue;
      if (emitted) yield ",";
      emitted = true;
      yield* quoted(key);
      yield ":";
      path.push(key);
      yield* visit(record[key], capture);
      path.pop();
    }
    yield "}";
    active.delete(node);
  }
  return visit(value, true);
}
function* jsonArray(values) {
  yield "[";
  for (let i = 0; i < values.length; i++) {
    if (i) yield ",";
    const value = values[i];
    if (typeof value === "string") yield* quoted(value);
    else yield String(value);
  }
  yield "]";
}
function* descriptor(details) {
  yield '{"version":1,"objects":[';
  for (const [i, item] of details.objects.entries()) {
    if (i) yield ",";
    yield '{"path":';
    yield* jsonArray(item.path);
    yield ',"keys":';
    yield* jsonArray(item.keys);
    yield ',"undefinedKeys":';
    yield* jsonArray(item.undefinedKeys);
    yield "}";
  }
  yield '],"aliases":[';
  for (const [i, item] of details.aliases.entries()) {
    if (i) yield ",";
    yield '{"path":';
    yield* jsonArray(item.path);
    yield ',"target":';
    yield* jsonArray(item.target);
    yield "}";
  }
  yield "]}";
}
async function field2(tag, tokens, limit, consume, signal) {
  const hash3 = sha256.create();
  let length = 0;
  let buffer = "";
  const flush = async () => {
    signal?.throwIfAborted();
    const bytes = textEncoder.encode(buffer);
    buffer = "";
    length += bytes.length;
    if (length > limit) throw new Error("\u5FEB\u7167\u8BB0\u5F55\u6216\u514B\u9686\u63CF\u8FF0\u8D85\u8FC7\u683C\u5F0F\u5BB9\u91CF\u9650\u5236\u3002");
    hash3.update(bytes);
    await consume?.(tag, bytes);
  };
  for (const token of tokens) {
    buffer += token;
    if (buffer.length >= 64 * 1024) await flush();
  }
  if (buffer) await flush();
  return { length, digest: bytesToHex(hash3.digest()) };
}
async function encodeSnapshotValue(kind, role, value, consume, signal) {
  const details = { objects: [], aliases: [] };
  const data = await field2(
    3,
    projection(value, kind, details),
    (role === "summary" ? 20 : 256) * MIB,
    consume,
    signal
  );
  const sidecar = await field2(
    4,
    descriptor(details),
    20 * MIB,
    consume,
    signal
  );
  return {
    projectionBytes: data.length,
    projectionSha256: data.digest,
    cloneBytes: sidecar.length,
    cloneSha256: sidecar.digest
  };
}

// src/infrastructure/snapshot-format.ts
async function fingerprintSnapshotValue(kind, role, value) {
  return encodeSnapshotValue(kind, role, value);
}
var utf8 = new TextEncoder();
var magic = utf8.encode("RLIDB001");
var domain = utf8.encode("RLIDB001/content/v1\0");

// src/infrastructure/snapshot-restore.ts
function own(parent, key) {
  if (parent === null || typeof parent !== "object" || (Array.isArray(parent) ? !Number.isSafeInteger(key) : typeof key !== "string") || !Object.hasOwn(parent, key))
    throw new Error("\u514B\u9686\u63CF\u8FF0\u7684\u8DEF\u5F84\u672A\u6307\u5411\u5DF2\u6709\u81EA\u6709\u5B57\u6BB5\u3002");
  return parent[key];
}
function restoreSnapshotValue(projectionJson, descriptorJson) {
  const root = JSON.parse(projectionJson);
  const descriptor2 = JSON.parse(descriptorJson);
  if (descriptor2.version !== 1 || !Array.isArray(descriptor2.objects) || !Array.isArray(descriptor2.aliases))
    throw new Error("\u514B\u9686\u63CF\u8FF0\u7248\u672C\u6216\u6210\u5458\u65E0\u6548\u3002");
  const at = (path) => {
    if (!Array.isArray(path) || path.length > 64)
      throw new Error("\u514B\u9686\u63CF\u8FF0\u8DEF\u5F84\u65E0\u6548\u3002");
    return path.reduce(own, root);
  };
  for (const patch of descriptor2.objects) {
    const parent = at(patch.path);
    if (!parent || typeof parent !== "object" || Array.isArray(parent))
      throw new Error("\u663E\u5F0F undefined \u7684\u7236\u5BF9\u8C61\u65E0\u6548\u3002");
    const present = new Map(Object.entries(parent));
    const missing = new Set(patch.undefinedKeys);
    for (const key of present.keys()) delete parent[key];
    for (const key of patch.keys) {
      if (!missing.has(key) && !present.has(key))
        throw new Error("\u514B\u9686\u63CF\u8FF0\u7F3A\u5C11\u539F\u5B57\u6BB5\u3002");
      Object.defineProperty(parent, key, {
        value: missing.has(key) ? void 0 : present.get(key),
        enumerable: true,
        configurable: true,
        writable: true
      });
    }
  }
  for (const alias of descriptor2.aliases) {
    const key = alias.path.at(-1);
    const parent = at(alias.path.slice(0, -1));
    if (key === void 0) throw new Error("\u5171\u4EAB\u5F15\u7528\u8DEF\u5F84\u4E3A\u7A7A\u3002");
    own(parent, key);
    const target = at(alias.target);
    if (!target || typeof target !== "object")
      throw new Error("\u5171\u4EAB\u5F15\u7528\u76EE\u6807\u65E0\u6548\u3002");
    Object.defineProperty(parent, key, {
      value: target,
      enumerable: true,
      configurable: true,
      writable: true
    });
  }
  return root;
}

// src/core/data/csv-types.ts
var fields = [
  "timestamp",
  "open",
  "high",
  "low",
  "close",
  "volume"
];
var MAX_CSV_CHARS = 10 * 1024 * 1024;
var MAX_DATA_ROWS = 5e4;

// src/core/data/dataset.ts
function summarizeDataset({
  candles: _candles,
  ...summary
}) {
  void _candles;
  return summary;
}
var boundedText = (v, max) => typeof v === "string" && v.length > 0 && v.length <= max;
var integer = (v, max = Number.MAX_SAFE_INTEGER) => Number.isSafeInteger(v) && Number(v) >= 0 && Number(v) <= max;
var hash = (v) => typeof v === "string" && /^[a-f0-9]{64}$/.test(v);
function fail(message2) {
  throw new Error(`\u6570\u636E\u96C6\u635F\u574F\u6216\u7248\u672C\u4E0D\u652F\u6301\uFF1A${message2}\uFF1B\u672A\u4FEE\u590D\u3002`);
}
function assertDatasetSummary(value) {
  const d = value;
  if (!d || d.schemaVersion !== 1 || !boundedText(d.id, 100) || !boundedText(d.name, 160) || !boundedText(d.symbol, 80) || !integer(d.createdUtcMs, 41024448e5) || d.warningsAcknowledged !== true)
    fail("\u8EAB\u4EFD/\u7248\u672C/\u786E\u8BA4\u4FE1\u606F\u65E0\u6548");
  if (!d.source || !["historical", "synthetic", "error-fixture", "user-unverified"].includes(
    d.source.kind
  ) || !boundedText(d.source.label, 300) || !boundedText(d.source.note, 3e3) || d.source.url !== void 0 && (!boundedText(d.source.url, 2e3) || !/^https:\/\//.test(d.source.url)) || d.source.expectedSha256 !== void 0 && !hash(d.source.expectedSha256))
    fail("\u6765\u6E90\u4FE1\u606F\u65E0\u6548");
  if (!d.file || !boundedText(d.file.name, 300) || !integer(d.file.bytes, 10 * 1024 * 1024) || !hash(d.file.sha256) || d.file.parserVersion !== "csv-v1" || d.source.expectedSha256 && d.source.expectedSha256 !== d.file.sha256)
    fail("\u6587\u4EF6\u8EAB\u4EFD\u65E0\u6548");
  const q = d.quality;
  if (!q || !integer(q.intervalMs, 31536e6) || !q.intervalMs || !["ms", "us", "iso"].includes(q.timeUnit) || !integer(q.validRows, MAX_DATA_ROWS) || q.validRows < 1 || !q.range || !integer(q.range.startUtcMs, 41024448e5) || !integer(q.range.endUtcMs, 41024448e5) || q.range.endUtcMs < q.range.startUtcMs || q.totalRows !== q.validRows || !integer(q.blankLines) || !integer(q.gapCount) || !integer(q.missingCandles) || !integer(q.warningCount) || !Array.isArray(q.issues) || q.issues.length > 1e3 || !q.issueCounts || q.issueCounts.COVERAGE_UNVERIFIED !== 1 || typeof q.issueDetailsTruncated !== "boolean")
    fail("\u8D28\u91CF\u4FE1\u606F\u65E0\u6548");
  if (!d.parsing || ![",", ";", "	"].includes(d.parsing.delimiter) || typeof d.parsing.hasHeader !== "boolean" || !["auto", "ms", "us", "iso"].includes(d.parsing.timeUnit) || d.parsing.intervalMs !== q.intervalMs || d.parsing.timeUnit !== "auto" && d.parsing.timeUnit !== q.timeUnit || !d.parsing.mapping)
    fail("\u89E3\u6790\u7EA6\u5B9A\u65E0\u6548");
  const mapped = Object.values(d.parsing.mapping);
  if (mapped.length !== 6 || new Set(mapped).size !== 6 || mapped.some((v) => !integer(v, 63)) || !["timestamp", "open", "high", "low", "close", "volume"].every(
    (k) => k in d.parsing.mapping
  ))
    fail("\u5B57\u6BB5\u6620\u5C04\u65E0\u6548");
  let warningTotal = 0;
  for (const [code, count] of Object.entries(q.issueCounts)) {
    if (!/^[A-Z_]{1,60}$/.test(code) || !integer(count) || count === 0)
      fail("\u8B66\u544A\u8BA1\u6570\u65E0\u6548");
    warningTotal += count;
  }
  if (warningTotal !== q.warningCount || q.issues.length !== Math.min(1e3, q.warningCount) || q.issueDetailsTruncated !== q.warningCount > 1e3)
    fail("\u8B66\u544A\u603B\u6570\u4E0D\u4E00\u81F4");
  for (const issue of q.issues)
    if (!issue || issue.severity !== "warning" || !boundedText(issue.code, 60) || !boundedText(issue.message, 3e3) || !q.issueCounts[issue.code])
      fail("\u8B66\u544A\u660E\u7EC6\u65E0\u6548");
}
function assertDataset(value) {
  assertDatasetSummary(value);
  const d = value;
  const q = d.quality;
  if (!Array.isArray(d.candles) || q.validRows !== d.candles.length)
    fail("\u8D28\u91CF\u4FE1\u606F\u65E0\u6548");
  let gapCount = 0, missing = 0;
  for (let i = 0; i < d.candles.length; i++) {
    const c = d.candles[i];
    if (!c || !integer(c.timestampUtcMs, 41024448e5) || ![c.open, c.high, c.low, c.close].every(
      (v) => typeof v === "number" && Number.isFinite(v) && v > 0
    ) || typeof c.volume !== "number" || !Number.isFinite(c.volume) || c.volume < 0 || c.low > Math.min(c.open, c.close) || c.high < Math.max(c.open, c.close) || c.low > c.high)
      fail(`\u7B2C ${i + 1} \u6839\u4EF7\u683C/\u91CF/UTC \u65F6\u95F4\u975E\u6CD5`);
    if (i) {
      const delta = c.timestampUtcMs - d.candles[i - 1].timestampUtcMs;
      if (delta <= 0 || delta % q.intervalMs !== 0)
        fail(`\u7B2C ${i + 1} \u6839\u91CD\u590D\u3001\u964D\u5E8F\u6216\u5468\u671F\u4E0D\u7B26`);
      if (delta > q.intervalMs) {
        gapCount++;
        missing += delta / q.intervalMs - 1;
      }
    }
  }
  if (q.gapCount !== gapCount || q.missingCandles !== missing || gapCount > 0 && q.issueCounts.MISSING_CANDLES !== 1 || !q.range || q.range.startUtcMs !== d.candles[0].timestampUtcMs || q.range.endUtcMs !== d.candles.at(-1).timestampUtcMs)
    fail("\u8303\u56F4\u6216\u7F3A\u53E3\u4E0D\u4E00\u81F4");
}

// src/core/data/snapshot-fields.ts
function validateSnapshotFields(d) {
  const only = (value, allowed) => {
    if (Object.keys(value).some((key) => !allowed.includes(key)))
      throw new Error("\u5B9E\u9A8C\u6570\u636E\u5FEB\u7167\u542B\u6709\u672A\u77E5\u5B57\u6BB5\u3002");
  };
  only(d, [
    "schemaVersion",
    "id",
    "name",
    "symbol",
    "createdUtcMs",
    "source",
    "file",
    "parsing",
    "quality",
    "warningsAcknowledged",
    "candles"
  ]);
  only(d.source, ["kind", "label", "note", "url", "expectedSha256"]);
  only(d.file, ["name", "bytes", "sha256", "parserVersion"]);
  only(d.parsing, [
    "delimiter",
    "hasHeader",
    "mapping",
    "timeUnit",
    "intervalMs"
  ]);
  only(d.quality, [
    "totalRows",
    "validRows",
    "blankLines",
    "timeUnit",
    "intervalMs",
    "range",
    "gapCount",
    "missingCandles",
    "warningCount",
    "issues",
    "issueCounts",
    "issueDetailsTruncated"
  ]);
  only(d.quality.range, ["startUtcMs", "endUtcMs"]);
  for (const issue of d.quality.issues) {
    only(issue, ["severity", "code", "message", "line", "field", "raw"]);
    if (issue.field !== void 0 && !fields.includes(issue.field) || issue.line !== void 0 && (!Number.isSafeInteger(issue.line) || issue.line < 1) || issue.raw !== void 0 && (typeof issue.raw !== "string" || issue.raw.length > 240))
      throw new Error("\u5B9E\u9A8C\u6570\u636E\u8D28\u91CF\u660E\u7EC6\u65E0\u6548\u3002");
  }
  const candleFields = [
    "timestampUtcMs",
    "open",
    "high",
    "low",
    "close",
    "volume"
  ];
  for (const candle of d.candles) only(candle, candleFields);
}

// src/core/math/index.ts
var SCALE = 10n ** 18n;
var BPS = 10000n;
var INPUT_LIMIT = 10n ** 48n;
var ACCOUNTING_LIMIT = 10n ** 96n;
var ceilDiv = (a, b) => (a + b - 1n) / b;
var unitCache = /* @__PURE__ */ new Map();
function readUnits(value) {
  if (typeof value !== "string" || value.length > 128)
    throw new Error("Decimal must be a string of at most 128 characters.");
  const cached = unitCache.get(value);
  if (cached !== void 0) return cached;
  const m = /^(\d+)(?:\.(\d+))?(?:e([+-]?\d{1,3}))?$/i.exec(value);
  if (!m) throw new Error(`Invalid nonnegative decimal: ${value}`);
  const digits = BigInt(m[1] + (m[2] ?? ""));
  const shift = 18 + Number(m[3] ?? 0) - (m[2]?.length ?? 0);
  const units = shift >= 0 ? digits * 10n ** BigInt(shift) : digits / 10n ** BigInt(-shift);
  if (shift < 0 && digits % 10n ** BigInt(-shift) !== 0n)
    throw new Error(`Decimal exceeds 18 places: ${value}`);
  if (unitCache.size >= 4096) unitCache.clear();
  unitCache.set(value, units);
  return units;
}
function parseDecimal(value) {
  const units = readUnits(value);
  if (units >= INPUT_LIMIT) throw new Error("Decimal must be less than 1e30.");
  return units;
}
var formattedUnits = /* @__PURE__ */ new Map();
function decimal(units) {
  if (units === 0n) return "0";
  if (units < 0n) return `-${decimal(-units)}`;
  const cached = formattedUnits.get(units);
  if (cached !== void 0) return cached;
  const whole = units / SCALE;
  const remainder = units % SCALE;
  const text3 = remainder === 0n ? String(whole) : `${whole}.${remainder.toString().padStart(18, "0").replace(/0+$/, "")}`;
  if (text3.length <= 128) {
    if (formattedUnits.size >= 4096) formattedUnits.clear();
    formattedUnits.set(units, text3);
  }
  return text3;
}
function integerSqrt(value) {
  if (value < 2n) return value;
  let root = 1n << BigInt(Math.ceil(value.toString(2).length / 2));
  for (; ; ) {
    const next = (root + value / root) / 2n;
    if (next >= root) return root;
    root = next;
  }
}

// src/core/backtests/config.ts
var DEFAULT_CONFIG = Object.freeze({
  initialCash: "1000",
  feeBps: 10,
  buySlippageBps: 10,
  sellSlippageBps: 10,
  quantityDecimals: 8,
  minNotional: "0"
});
function normalizeConfig(input = {}) {
  if (!input || typeof input !== "object" || Object.getPrototypeOf(input) !== Object.prototype || Array.isArray(input) || Object.keys(input).some((k) => !Object.hasOwn(DEFAULT_CONFIG, k)))
    throw new Error("Unknown or invalid backtest configuration.");
  const config = { ...DEFAULT_CONFIG, ...input };
  for (const n of [
    config.feeBps,
    config.buySlippageBps,
    config.sellSlippageBps
  ])
    if (!Number.isInteger(n) || n < 0 || n >= 1e4)
      throw new Error("Basis points must be integers in 0..9999.");
  if (!Number.isInteger(config.quantityDecimals) || config.quantityDecimals < 0 || config.quantityDecimals > 18)
    throw new Error("Quantity precision must be an integer in 0..18.");
  config.initialCash = decimal(parseDecimal(config.initialCash));
  config.minNotional = decimal(parseDecimal(config.minNotional));
  return config;
}

// src/core/backtests/execution.ts
function executeAtReference(balance, open, intent, config) {
  const buy = intent.side === "buy";
  const price = buy ? ceilDiv(open * (BPS + BigInt(config.buySlippageBps)), BPS) : open * (BPS - BigInt(config.sellSlippageBps)) / BPS;
  if (price === 0n) return { rejected: "price-underflow" };
  const step = 10n ** BigInt(18 - config.quantityDecimals);
  const amounts = (quantity2) => {
    const notional2 = buy ? ceilDiv(price * quantity2, SCALE) : price * quantity2 / SCALE;
    return { notional: notional2, fee: ceilDiv(notional2 * BigInt(config.feeBps), BPS) };
  };
  let quantity;
  if (intent.quantity !== "all") {
    const requested = typeof intent.quantity === "bigint" ? intent.quantity : parseDecimal(intent.quantity);
    if (requested < 0n) throw new Error("Negative order quantity.");
    quantity = requested / step * step;
  } else if (!buy) quantity = balance.quantity;
  else {
    let lo = 0n, hi = balance.cash * SCALE / price / step;
    while (lo < hi) {
      const mid = (lo + hi + 1n) / 2n;
      const { notional: notional2, fee: fee2 } = amounts(mid * step);
      if (notional2 + fee2 <= balance.cash) lo = mid;
      else hi = mid - 1n;
    }
    quantity = lo * step;
  }
  if (quantity === 0n) return { rejected: "zero-quantity" };
  if (quantity >= ACCOUNTING_LIMIT)
    throw new Error("Accounting quantity exceeds 1e78; run blocked.");
  const { notional, fee } = amounts(quantity);
  if (notional === 0n) return { rejected: "zero-notional" };
  if (notional < parseDecimal(config.minNotional))
    return { rejected: "below-min-notional" };
  if (buy && notional + fee > balance.cash)
    return { rejected: "insufficient-cash" };
  if (!buy && quantity > balance.quantity)
    return { rejected: "insufficient-position" };
  return { price, quantity, notional, fee };
}

// src/core/strategies/rules.ts
var RULE_STRATEGY_VERSION = "causal-declarative-rules-v1";
var fail2 = (message2) => {
  throw new Error(`\u89C4\u5219\u65E0\u6548\uFF1A${message2}`);
};
function object(value, keys, path) {
  if (!value || Object.getPrototypeOf(value) !== Object.prototype || Object.keys(value).length !== keys.length || keys.some((k) => !Object.hasOwn(value, k)))
    return fail2(`${path} \u5B57\u6BB5\u7F3A\u5C11\u3001\u672A\u77E5\u6216\u7C7B\u578B\u9519\u8BEF\u3002`);
  return value;
}
var period = (n) => typeof n === "number" && Number.isInteger(n) && n >= 1 && n <= 5e4;
var comparison = (v) => ["gt", "gte", "lt", "lte"].includes(v);
function normalizeRule(value) {
  const r = object(value, ["schemaVersion", "revision", "buy", "sell"], "\u7B56\u7565");
  if (r.schemaVersion !== 1) fail2("\u53EA\u652F\u6301 schemaVersion=1\uFF0C\u672A\u8FC1\u79FB\u3002");
  if (typeof r.revision !== "number" || !Number.isSafeInteger(r.revision) || r.revision < 1 || r.revision > 1e6)
    fail2("revision \u5FC5\u987B\u4E3A1\u20131,000,000\u6574\u6570\u3002");
  function group(value2, side) {
    const g = object(value2, ["enabled", "operator", "conditions"], side);
    if (typeof g.enabled !== "boolean" || !["AND", "OR"].includes(g.operator) || !Array.isArray(g.conditions) || g.conditions.length < 1 || g.conditions.length > 5)
      return fail2(`${side} \u9700\u8981\u5E03\u5C14\u542F\u7528\u72B6\u6001\u3001AND/OR\u53CA1\u20135\u6761\u6761\u4EF6\u3002`);
    const conditions = Array.from(g.conditions, (value3, i) => {
      const kind = value3?.kind;
      const keys = kind === "cross" ? ["average", "fastPeriod", "slowPeriod", "direction"] : kind === "price-ma" ? ["average", "period", "operator"] : kind === "rsi" ? ["period", "operator", "threshold"] : kind === "breakout" ? ["lookback", "direction"] : fail2("\u672A\u77E5\u6761\u4EF6\u7C7B\u578B\u3002");
      const c = object(
        value3,
        ["kind", "enabled", ...keys],
        `${side}\u6761\u4EF6${i + 1}`
      );
      if (typeof c.enabled !== "boolean") fail2("enabled \u5FC5\u987B\u4E3A\u5E03\u5C14\u503C\u3002");
      if (kind === "cross" || kind === "price-ma") {
        if (!["MA", "EMA"].includes(c.average))
          fail2("\u5747\u7EBF\u5FC5\u987B\u4E3AMA/EMA\u3002");
      }
      if (kind === "cross" || kind === "breakout") {
        if (!["above", "below"].includes(c.direction))
          fail2("\u65B9\u5411\u5FC5\u987B\u4E3Aabove/below\u3002");
      }
      if (kind === "cross" && (!period(c.fastPeriod) || !period(c.slowPeriod) || c.fastPeriod >= c.slowPeriod))
        fail2("\u4EA4\u53C9\u5468\u671F\u5FC5\u987B\u4E3A1\u201350,000\u6574\u6570\uFF0C\u5FEB\u7EBF\u5C0F\u4E8E\u6162\u7EBF\u3002");
      if ((kind === "price-ma" || kind === "rsi") && (!period(c.period) || !comparison(c.operator)))
        fail2("\u5468\u671F\u5FC5\u987B\u4E3A1\u201350,000\u6574\u6570\uFF0C\u6BD4\u8F83\u7B26\u53F7\u5FC5\u987B\u660E\u786E\u3002");
      if (kind === "rsi" && (typeof c.threshold !== "number" || !Number.isFinite(c.threshold) || c.threshold < 0 || c.threshold > 100))
        fail2("RSI\u9608\u503C\u5FC5\u987B\u4E3A0\u2013100\u6709\u9650\u6570\u5B57\u3002");
      if (kind === "breakout" && !period(c.lookback))
        fail2("\u7A81\u7834\u56DE\u770B\u5FC5\u987B\u4E3A1\u201350,000\u6574\u6570\u3002");
      return { ...c };
    });
    if (g.enabled && !conditions.some((c) => c.enabled))
      fail2(`${side}\u81F3\u5C11\u542F\u7528\u4E00\u6761\u6761\u4EF6\u3002`);
    return {
      enabled: g.enabled,
      operator: g.operator,
      conditions
    };
  }
  const buy = group(r.buy, "\u4E70\u5165"), sell = group(r.sell, "\u5356\u51FA");
  if (!buy.enabled && !sell.enabled) fail2("\u81F3\u5C11\u542F\u7528\u4E00\u4FA7\u89C4\u5219\u3002");
  return { schemaVersion: 1, revision: r.revision, buy, sell };
}
var blend = (a, b, w) => b >= a ? a + (b - a) * w : b + (a - b) * (1 - w);
function average(kind, n) {
  let count = 0, mean = 0;
  let sum2 = 0n;
  const ring = [];
  let lastTime;
  let value = null;
  return (close, units, time) => {
    if (lastTime === time) return value;
    lastTime = time;
    if (kind === "MA") {
      const slot = count % n;
      sum2 += units - (ring[slot] ?? 0n);
      ring[slot] = units;
    } else
      mean = count < n ? blend(mean, close, 1 / (count + 1)) : blend(mean, close, 2 / (n + 1));
    count++;
    value = count < n ? null : kind === "MA" ? sum2 : mean;
    return value;
  };
}
function compare(a, b, op) {
  return op === "gt" ? a > b : op === "gte" ? a >= b : op === "lt" ? a < b : a <= b;
}
function condition(c, getAverage) {
  if (c.kind === "cross" || c.kind === "price-ma") {
    const slowPeriod = c.kind === "cross" ? c.slowPeriod : c.period;
    const slow = getAverage(c.average, slowPeriod);
    const fast = c.kind === "cross" ? getAverage(c.average, c.fastPeriod) : null;
    const slowWeight = BigInt(slowPeriod);
    const fastWeight = c.kind === "cross" ? BigInt(c.fastPeriod) : 1n;
    let previous;
    return (bar, units) => {
      const s = slow(bar.close, units, bar.timestampUtcMs), f = fast?.(bar.close, units, bar.timestampUtcMs);
      if (s === null || fast && f == null) return null;
      if (c.kind === "price-ma")
        return compare(
          c.average === "MA" ? units * slowWeight : bar.close,
          s,
          c.operator
        );
      const a = c.average === "MA" ? f * slowWeight : f;
      const b = c.average === "MA" ? s * fastWeight : s;
      const next = a < b ? -1 : a > b ? 1 : 0;
      const result = previous === void 0 ? null : c.direction === "above" ? previous <= 0 && next > 0 : previous >= 0 && next < 0;
      previous = next;
      return result;
    };
  }
  if (c.kind === "rsi") {
    let count2 = 0, previous = 0, gain = 0, loss = 0;
    return (bar) => {
      if (count2) {
        const delta = bar.close - previous, up = Math.max(delta, 0), down = Math.max(-delta, 0);
        gain = count2 <= c.period ? blend(gain, up, 1 / count2) : gain * ((c.period - 1) / c.period) + up / c.period;
        loss = count2 <= c.period ? blend(loss, down, 1 / count2) : loss * ((c.period - 1) / c.period) + down / c.period;
      }
      previous = bar.close;
      count2++;
      if (count2 <= c.period) return null;
      const rsi = gain === 0 && loss === 0 ? 50 : loss === 0 ? 100 : gain === 0 ? 0 : 100 / (1 + loss / gain);
      return compare(rsi, c.threshold, c.operator);
    };
  }
  const queue = [];
  let count = 0, head = 0;
  return (bar, units) => {
    while (head < queue.length && queue[head].index < count - c.lookback)
      head++;
    const result = count < c.lookback ? null : c.direction === "above" ? units > queue[head].price : units < queue[head].price;
    const price = parseDecimal(
      String(c.direction === "above" ? bar.high : bar.low)
    );
    while (queue.length > head && (c.direction === "above" ? queue.at(-1).price <= price : queue.at(-1).price >= price))
      queue.pop();
    queue.push({ index: count++, price });
    if (head > 1024) {
      queue.splice(0, head);
      head = 0;
    }
    return result;
  };
}
function createRuleStrategy(value, intervalMs) {
  const rule = normalizeRule(value);
  if (!Number.isSafeInteger(intervalMs) || intervalMs <= 0 || intervalMs > 31536e6)
    fail2("\u975E\u6CD5\u5468\u671F\u3002");
  for (const g of [rule.buy, rule.sell]) {
    g.conditions.forEach(Object.freeze);
    Object.freeze(g.conditions);
    Object.freeze(g);
  }
  Object.freeze(rule);
  const averages = /* @__PURE__ */ new Map();
  const getAverage = (kind, period3) => {
    const key = kind + ":" + period3;
    let next = averages.get(key);
    if (!next) {
      next = average(kind, period3);
      averages.set(key, next);
    }
    return next;
  };
  function group(g) {
    const evaluators = g.conditions.filter((c) => c.enabled).map((c) => condition(c, getAverage));
    return (bar, units) => {
      if (!g.enabled) return false;
      const values = evaluators.map((evaluate) => evaluate(bar, units));
      if (values.includes(null)) return null;
      return g.operator === "AND" ? values.every(Boolean) : values.some(Boolean);
    };
  }
  const buy = group(rule.buy), sell = group(rule.sell);
  let count = 0, previousTime, previousBuy = false, previousSell = false;
  return Object.freeze({
    config: Object.freeze({ kind: "rules", rule }),
    version: RULE_STRATEGY_VERSION,
    onClose(bar) {
      if (count >= 5e4 || !bar || !Number.isSafeInteger(bar.timestampUtcMs) || bar.timestampUtcMs < 0 || bar.timestampUtcMs + intervalMs > 41024448e5 || previousTime !== void 0 && bar.timestampUtcMs - previousTime !== intervalMs || ![bar.open, bar.high, bar.low, bar.close].every(
        (v) => Number.isFinite(v) && v > 0
      ) || !Number.isFinite(bar.volume) || bar.volume < 0 || bar.low > Math.min(bar.open, bar.close) || bar.high < Math.max(bar.open, bar.close))
        fail2("\u53EA\u63A5\u6536\u5408\u6CD5\u8FDE\u7EED\u7684\u5DF2\u5B8C\u6210K\u7EBF\u3002");
      const prices = [bar.open, bar.high, bar.low, bar.close].map(
        (v) => parseDecimal(String(v))
      );
      if (prices.some((v) => v === 0n)) fail2("\u4EF7\u683C\u4E0B\u6EA2\u3002");
      previousTime = bar.timestampUtcMs;
      count++;
      const b = buy(bar, prices[3]), s = sell(bar, prices[3]);
      if (b === null || s === null)
        return { action: "hold", reason: "rules-warmup" };
      const buyEdge = b && !previousBuy, sellEdge = s && !previousSell;
      previousBuy = b;
      previousSell = s;
      if (b && s) return { action: "hold", reason: "rules-conflict" };
      if (buyEdge) return { action: "buy", reason: "rules-buy" };
      if (sellEdge) return { action: "sell", reason: "rules-sell" };
      return {
        action: "hold",
        reason: b || s ? "rules-repeat" : "rules-no-match"
      };
    }
  });
}

// src/core/strategies/engine.ts
var STRATEGY_VERSION = "causal-close-ma-rsi-breakout-v1";
var period2 = (n) => Number.isInteger(n) && n >= 1 && n <= 5e4;
function normalizeStrategy(input) {
  if (!input || Object.getPrototypeOf(input) !== Object.prototype)
    throw new Error("Invalid strategy configuration.");
  if (input.kind === "rules") {
    if (Object.keys(input).length !== 2 || !Object.hasOwn(input, "rule"))
      throw new Error("Unknown rule strategy parameter.");
    return { kind: "rules", rule: normalizeRule(input.rule) };
  }
  let config;
  switch (input.kind) {
    case "ma":
      config = { fastPeriod: 10, slowPeriod: 30, ...input };
      if (!period2(config.fastPeriod) || !period2(config.slowPeriod) || config.fastPeriod >= config.slowPeriod)
        throw new Error("MA periods require 1 <= fast < slow <= 50000.");
      break;
    case "rsi":
      config = { period: 14, lower: 30, upper: 70, ...input };
      if (!period2(config.period) || !Number.isFinite(config.lower) || !Number.isFinite(config.upper) || config.lower < 0 || config.lower >= config.upper || config.upper > 100)
        throw new Error(
          "RSI requires period 1..50000 and 0 <= lower < upper <= 100."
        );
      break;
    case "breakout":
      config = { lookback: 20, ...input };
      if (!period2(config.lookback))
        throw new Error("Breakout lookback requires 1..50000.");
      break;
    default:
      throw new Error("Unknown strategy kind.");
  }
  const keys = input.kind === "ma" ? ["kind", "fastPeriod", "slowPeriod"] : input.kind === "rsi" ? ["kind", "period", "lower", "upper"] : ["kind", "lookback"];
  if (Object.keys(input).some((k) => !keys.includes(k)))
    throw new Error("Unknown strategy parameter.");
  return config;
}
var blend2 = (a, b, w) => b >= a ? a + (b - a) * w : b + (a - b) * (1 - w);
var decision = (action, reason) => ({ action, reason });
function createStrategy(input, intervalMs) {
  const config = Object.freeze(normalizeStrategy(input));
  if (config.kind === "rules")
    return createRuleStrategy(config.rule, intervalMs);
  if (!Number.isSafeInteger(intervalMs) || intervalMs <= 0 || intervalMs > 31536e6)
    throw new Error("Invalid strategy interval.");
  let count = 0, previousTime, previousClose = 0;
  let fastSum = 0n, slowSum = 0n, previousDifference;
  const fast = [], slow = [];
  let gain = 0, loss = 0;
  const highs = [], lows = [];
  let highHead = 0, lowHead = 0;
  return Object.freeze({
    config,
    version: STRATEGY_VERSION,
    onClose(c) {
      if (count >= 5e4 || !c || !Number.isSafeInteger(c.timestampUtcMs) || c.timestampUtcMs < 0 || c.timestampUtcMs + intervalMs > 41024448e5 || previousTime !== void 0 && c.timestampUtcMs - previousTime !== intervalMs || ![c.open, c.high, c.low, c.close].every(
        (v) => Number.isFinite(v) && v > 0
      ) || !Number.isFinite(c.volume) || c.volume < 0 || c.low > Math.min(c.open, c.close) || c.high < Math.max(c.open, c.close))
        throw new Error("Invalid or noncontiguous completed strategy candle.");
      const [open, high, low, close] = [c.open, c.high, c.low, c.close].map(
        (v) => parseDecimal(String(v))
      );
      if ([open, high, low, close].some((v) => v === 0n))
        throw new Error("Strategy price underflow.");
      const i = count;
      let result = decision("hold", "warmup");
      if (config.kind === "ma") {
        const f = i % config.fastPeriod, s = i % config.slowPeriod;
        fastSum += close - (fast[f] ?? 0n);
        fast[f] = close;
        slowSum += close - (slow[s] ?? 0n);
        slow[s] = close;
        if (i + 1 >= config.slowPeriod) {
          const difference = fastSum * BigInt(config.slowPeriod) - slowSum * BigInt(config.fastPeriod);
          if (previousDifference !== void 0)
            result = previousDifference <= 0n && difference > 0n ? decision("buy", "ma-cross-up") : previousDifference >= 0n && difference < 0n ? decision("sell", "ma-cross-down") : decision("hold", "ma-no-cross");
          previousDifference = difference;
        }
      } else if (config.kind === "rsi") {
        if (i > 0) {
          const delta = c.close - previousClose, up = Math.max(delta, 0), down = Math.max(-delta, 0);
          if (i <= config.period) {
            gain = blend2(gain, up, 1 / i);
            loss = blend2(loss, down, 1 / i);
          } else {
            gain = gain * ((config.period - 1) / config.period) + up / config.period;
            loss = loss * ((config.period - 1) / config.period) + down / config.period;
          }
          if (i >= config.period) {
            const rsi = gain === 0 && loss === 0 ? 50 : loss === 0 ? 100 : gain === 0 ? 0 : 100 / (1 + loss / gain);
            result = rsi <= config.lower ? decision("buy", "rsi-lower") : rsi >= config.upper ? decision("sell", "rsi-upper") : decision("hold", "rsi-middle");
          }
        }
      } else {
        while (highHead < highs.length && highs[highHead].index < i - config.lookback)
          highHead++;
        while (lowHead < lows.length && lows[lowHead].index < i - config.lookback)
          lowHead++;
        if (i >= config.lookback)
          result = close > highs[highHead].price ? decision("buy", "breakout-up") : close < lows[lowHead].price ? decision("sell", "breakout-down") : decision("hold", "breakout-inside");
        while (highs.length > highHead && highs.at(-1).price <= high)
          highs.pop();
        while (lows.length > lowHead && lows.at(-1).price >= low) lows.pop();
        highs.push({ index: i, price: high });
        lows.push({ index: i, price: low });
      }
      previousClose = c.close;
      previousTime = c.timestampUtcMs;
      count++;
      return result;
    }
  });
}

// src/core/risk/protection.ts
function normalizeRisk(input = {}) {
  if (!input || Object.getPrototypeOf(input) !== Object.prototype || Object.keys(input).some(
    (k) => !["stopLossBps", "takeProfitBps"].includes(k)
  ))
    throw new Error("Invalid risk configuration.");
  const result = {};
  for (const key of ["stopLossBps", "takeProfitBps"]) {
    if (!Object.hasOwn(input, key)) continue;
    const n = input[key];
    if (typeof n !== "number" || !Number.isInteger(n) || n < 1 || n > 9999)
      throw new Error(
        "Protection basis points require integers in 1..9999; omit to disable."
      );
    result[key] = n;
  }
  return result;
}
function entryProtection(entry, config) {
  config = normalizeRisk(config);
  if (entry <= 0n) throw new Error("Positive entry price required.");
  const stop = config.stopLossBps === void 0 ? null : entry * (BPS - BigInt(config.stopLossBps)) / BPS;
  const take = config.takeProfitBps === void 0 ? null : ceilDiv(entry * (BPS + BigInt(config.takeProfitBps)), BPS);
  if (stop === 0n) return null;
  return {
    entryPrice: decimal(entry),
    stopPrice: stop === null ? null : decimal(stop),
    takePrice: take === null ? null : decimal(take)
  };
}
function protectionFor(entry, config) {
  const protection = entryProtection(entry, config);
  if (!protection) throw new Error("Stop price underflow; run blocked.");
  return protection;
}
function triggerAtOpen(protection, open, barOpenUtcMs, barCloseUtcMs) {
  const stop = protection.stopPrice === null ? null : readUnits(protection.stopPrice), take = protection.takePrice === null ? null : readUnits(protection.takePrice);
  if (stop !== null && open <= stop)
    return {
      ...protection,
      phase: "open",
      kind: "stop-loss",
      assumption: "observed-open",
      barOpenUtcMs,
      barCloseUtcMs,
      referencePrice: decimal(open)
    };
  if (take !== null && open >= take)
    return {
      ...protection,
      phase: "open",
      kind: "take-profit",
      assumption: "observed-open",
      barOpenUtcMs,
      barCloseUtcMs,
      referencePrice: decimal(take)
    };
}
function triggerIntrabar(protection, high, low, barOpenUtcMs, barCloseUtcMs) {
  const stop = protection.stopPrice === null ? null : readUnits(protection.stopPrice), take = protection.takePrice === null ? null : readUnits(protection.takePrice);
  const hitStop = stop !== null && low <= stop, hitTake = take !== null && high >= take;
  if (!hitStop && !hitTake) return;
  return {
    ...protection,
    phase: "intrabar",
    kind: hitStop ? "stop-loss" : "take-profit",
    assumption: hitStop && hitTake ? "ambiguous-stop-first" : "threshold-touch-order-unknown",
    barOpenUtcMs,
    barCloseUtcMs,
    referencePrice: decimal(hitStop ? stop : take)
  };
}

// src/core/backtests/ledger.ts
function snapshot(balance, markPrice) {
  const marketValue = balance.quantity * markPrice / SCALE;
  if ([
    balance.cash,
    balance.quantity,
    marketValue,
    balance.cash + marketValue
  ].some((v) => v < 0n || v >= ACCOUNTING_LIMIT))
    throw new Error(
      "Accounting range exceeded: nonnegative values below 1e78 required; run blocked."
    );
  return {
    cash: decimal(balance.cash),
    position: { quantity: decimal(balance.quantity) },
    markPrice: decimal(markPrice),
    marketValue: decimal(marketValue),
    equity: decimal(balance.cash + marketValue)
  };
}
function ledgerAuditor(initialCash, config) {
  let cash = parseDecimal(initialCash), quantity = 0n;
  if (decimal(cash) !== config.initialCash)
    throw new Error("Ledger initial cash mismatch.");
  let buyNotional = 0n, sellNotional = 0n, fees = 0n, buyQuantity = 0n, sellQuantity = 0n;
  const seen = /* @__PURE__ */ new Set();
  const equal = (actual, expected) => {
    if (JSON.stringify(actual) !== JSON.stringify(expected))
      throw new Error("Ledger reconciliation failed.");
  };
  let previousIndex = -1;
  let previousTime = -1;
  let previousWasOpenSignal = false;
  let previousSide;
  let sequence = 0;
  return (f) => {
    sequence++;
    const trigger = f.trigger;
    const intrabar = trigger?.phase === "intrabar";
    if (!Number.isSafeInteger(f.candleIndex) || f.candleIndex < 1 || f.sequence !== sequence || seen.has(f.orderId) || f.candleIndex < previousIndex || f.candleIndex === previousIndex && !(trigger && previousWasOpenSignal && (intrabar || previousSide === "buy")) || !["buy", "sell"].includes(f.side))
      throw new Error("Ledger event order failed.");
    if (trigger) {
      if (f.orderId !== `risk-${f.candleIndex}` || f.signalCandleIndex !== null || f.side !== "sell" || !["open", "intrabar"].includes(trigger.phase) || !["stop-loss", "take-profit"].includes(trigger.kind) || f.reason !== trigger.kind || trigger.referencePrice !== f.referencePrice || !Number.isSafeInteger(trigger.barOpenUtcMs) || !Number.isSafeInteger(trigger.barCloseUtcMs) || trigger.barOpenUtcMs < 0 || trigger.barCloseUtcMs <= trigger.barOpenUtcMs || (intrabar ? f.timestampUtcMs !== null || !["threshold-touch-order-unknown", "ambiguous-stop-first"].includes(
        trigger.assumption
      ) : f.timestampUtcMs !== trigger.barOpenUtcMs || trigger.assumption !== "observed-open") || trigger.assumption === "ambiguous-stop-first" && trigger.kind !== "stop-loss")
        throw new Error("Ledger risk event failed.");
      const entry = readUnits(trigger.entryPrice);
      const stop = trigger.stopPrice === null ? null : readUnits(trigger.stopPrice);
      const take = trigger.takePrice === null ? null : readUnits(trigger.takePrice);
      const ref = readUnits(trigger.referencePrice);
      if (entry === 0n || stop !== null && (stop === 0n || stop >= entry) || take !== null && take <= entry || (trigger.kind === "stop-loss" ? stop === null || (intrabar ? ref !== stop : ref > stop) : take === null || ref !== take))
        throw new Error("Ledger protection price failed.");
    } else if (f.orderId !== `order-${f.signalCandleIndex}` || f.signalCandleIndex !== f.candleIndex - 1 || !Number.isSafeInteger(f.timestampUtcMs) || f.timestampUtcMs === null || f.timestampUtcMs < 0)
      throw new Error("Ledger signal event failed.");
    const eventStart = trigger ? trigger.barOpenUtcMs : f.timestampUtcMs;
    if (f.candleIndex > previousIndex && eventStart <= previousTime)
      throw new Error("Ledger event time failed.");
    seen.add(f.orderId);
    previousWasOpenSignal = !trigger;
    previousSide = f.side;
    previousIndex = f.candleIndex;
    previousTime = eventStart;
    const open = readUnits(f.referencePrice), price = readUnits(f.price), qty = readUnits(f.quantity);
    if (open === 0n || qty === 0n || trigger && qty !== quantity || qty % 10n ** BigInt(18 - config.quantityDecimals) !== 0n)
      throw new Error("Ledger price/quantity failed.");
    const expectedPrice = f.side === "buy" ? ceilDiv(open * (BPS + BigInt(config.buySlippageBps)), BPS) : open * (BPS - BigInt(config.sellSlippageBps)) / BPS;
    if (price !== expectedPrice || price === 0n)
      throw new Error("Ledger fill price failed.");
    const notional = f.side === "buy" ? ceilDiv(price * qty, SCALE) : price * qty / SCALE;
    const fee = ceilDiv(notional * BigInt(config.feeBps), BPS);
    if (notional === 0n || notional < parseDecimal(config.minNotional))
      throw new Error("Ledger notional failed.");
    equal(f.notional, decimal(notional));
    equal(f.fee, decimal(fee));
    const before = snapshot({ cash, quantity }, open);
    const beforeEquity = cash + quantity * open / SCALE;
    equal(f.before, before);
    const sign = f.side === "buy" ? 1n : -1n;
    cash -= sign * notional + fee;
    quantity += sign * qty;
    fees += fee;
    if (f.side === "buy") {
      buyNotional += notional;
      buyQuantity += qty;
    } else {
      sellNotional += notional;
      sellQuantity += qty;
    }
    if (cash < 0n || quantity < 0n || cash !== parseDecimal(initialCash) - buyNotional + sellNotional - fees || quantity !== buyQuantity - sellQuantity)
      throw new Error("Ledger conservation failed.");
    const after = snapshot({ cash, quantity }, open);
    equal(f.after, after);
    equal(f.delta, {
      cash: decimal(-sign * notional - fee),
      quantity: decimal(sign * qty),
      equity: decimal(cash + quantity * open / SCALE - beforeEquity)
    });
    equal(f.totals, {
      buyNotional: decimal(buyNotional),
      sellNotional: decimal(sellNotional),
      fees: decimal(fees),
      buyQuantity: decimal(buyQuantity),
      sellQuantity: decimal(sellQuantity)
    });
  };
}

// src/core/backtests/engine.ts
var ALGORITHM_VERSION = "spot-long-protected-next-open-v2";
var CONVERSION_VERSION = "number-shortest-decimal-fixed18-v1";
var RUN_ASSUMPTIONS = Object.freeze([
  "virtual-USDT-single-symbol-spot-long-only-no-leverage",
  "caller-declares-all-candles-completed",
  "strategy-stream-completed-candle-only-or-unverified-scripted-signals",
  "existing-risk-open-before-signal-intrabar-after-open-orders",
  "new-protection-marketable-at-open-exits-at-open",
  "ambiguous-intrabar-stop-first-time-unknown",
  "gap-stop-at-open-gap-take-at-threshold-no-improvement",
  "protective-trigger-market-sell-with-adverse-slippage",
  "protection-from-actual-entry-price-no-fee-basis-no-pyramiding",
  "completed-close-signal-next-open-fill",
  "strict-no-gaps-no-sorting-no-repair",
  "unlimited-liquidity-no-order-book-volume-ignored",
  "no-partial-fills",
  "adverse-two-sided-slippage-not-clamped-to-high-low",
  "quote-currency-fees-ceil-after-notional-rounding",
  "fixed18-buy-ceil-sell-floor-quantity-floor-mark-floor",
  "no-final-liquidation-close-mark-excludes-liquidation-costs",
  "source-number-precision-not-original-csv-decimal-precision",
  "coverage-and-source-authenticity-unverified"
]);
function normalizeSignals(signals, length) {
  if (!Array.isArray(signals) || signals.length > length)
    throw new Error("Invalid fixed signals.");
  let previous = -1;
  return Array.from(signals, (s) => {
    if (!s || !Number.isInteger(s.candleIndex) || s.candleIndex <= previous || s.candleIndex >= length || typeof s.reason !== "string" || !s.reason.length || s.reason.length > 500)
      throw new Error(
        "Signals require increasing, unique in-range indices and reasons."
      );
    previous = s.candleIndex;
    if (s.action === "hold") {
      if (Object.keys(s).some(
        (k) => !["action", "candleIndex", "reason"].includes(k)
      ))
        throw new Error("Hold cannot specify a quantity or unknown fields.");
      return { candleIndex: s.candleIndex, action: s.action, reason: s.reason };
    }
    if (!["buy", "sell"].includes(s.action) || Object.keys(s).some(
      (k) => !["action", "candleIndex", "reason", "quantity"].includes(k)
    ))
      throw new Error("Invalid signal action/fields.");
    return {
      candleIndex: s.candleIndex,
      action: s.action,
      quantity: s.quantity === "all" ? "all" : decimal(parseDecimal(s.quantity)),
      reason: s.reason
    };
  });
}
function createBacktestSession(input, interactive = false) {
  const { dataset: d, completedThroughUtcMs } = input;
  if (interactive && (input.strategy !== void 0 || input.signals?.length))
    throw new Error("Interactive sessions require empty scripted signals.");
  assertDataset(d);
  if (!Number.isSafeInteger(completedThroughUtcMs) || completedThroughUtcMs < 0 || completedThroughUtcMs > 41024448e5)
    throw new Error("Invalid completed-through UTC milliseconds.");
  const intervalMs = d.quality.intervalMs;
  const tape = d.candles.map((c, i) => {
    if (c.timestampUtcMs + intervalMs > completedThroughUtcMs)
      throw new Error("Uncompleted candle blocks the run.");
    if (i && c.timestampUtcMs - d.candles[i - 1].timestampUtcMs !== intervalMs)
      throw new Error("Data gap blocks the run.");
    const prices = [c.open, c.high, c.low, c.close].map(
      (v) => parseDecimal(String(v))
    );
    if (prices.some((p) => p === 0n)) throw new Error("Price underflow.");
    return {
      timestampUtcMs: c.timestampUtcMs,
      open: decimal(prices[0]),
      high: decimal(prices[1]),
      low: decimal(prices[2]),
      close: decimal(prices[3]),
      volume: String(c.volume)
    };
  });
  const config = normalizeConfig(input.config);
  if (input.strategy !== void 0 && input.signals !== void 0)
    throw new Error("Choose strategy or fixed signals, never both.");
  const strategy = input.strategy === void 0 ? void 0 : createStrategy(input.strategy, intervalMs);
  const risk = normalizeRisk(input.risk);
  const protectedRun = Object.keys(risk).length > 0;
  const signals = strategy ? [] : normalizeSignals(input.signals, tape.length);
  const dataHash = contentHash({ symbol: d.symbol, intervalMs, candles: tape });
  const signalHash = contentHash(signals);
  const manifest = {
    algorithmVersion: ALGORITHM_VERSION,
    conversionVersion: CONVERSION_VERSION,
    dataHash,
    signalHash,
    runHash: contentHash({
      algorithmVersion: ALGORITHM_VERSION,
      conversionVersion: CONVERSION_VERSION,
      dataHash,
      signalHash,
      config,
      completedThroughUtcMs,
      strategy: strategy ? { config: strategy.config, version: strategy.version } : null,
      risk
    }),
    sourceFileSha256: d.file.sha256,
    source: JSON.parse(JSON.stringify(d.source)),
    quality: JSON.parse(JSON.stringify(d.quality)),
    symbol: d.symbol,
    intervalMs,
    completedThroughUtcMs,
    config,
    signals,
    strategy: strategy ? { config: strategy.config, version: strategy.version } : null,
    risk,
    assumptions: RUN_ASSUMPTIONS
  };
  const result = {
    manifest,
    signals: [],
    orders: [],
    fills: [],
    closes: [],
    final: snapshot(
      { cash: parseDecimal(config.initialCash), quantity: 0n },
      parseDecimal(tape[0].open)
    )
  };
  let cash = parseDecimal(config.initialCash), quantity = 0n;
  let buyNotional = 0n, sellNotional = 0n, fees = 0n, buyQuantity = 0n, sellQuantity = 0n;
  let pending;
  let nextSignal = 0;
  const audit = ledgerAuditor(config.initialCash, config);
  let protection;
  const execute = (intent, i, reference, time) => {
    const mark2 = readUnits(reference);
    const blocked = !intent.trigger && (strategy || protectedRun) && intent.side === "buy" && quantity > 0n ? "position-already-open" : !intent.trigger && strategy && intent.side === "sell" && quantity === 0n ? "position-already-flat" : void 0;
    const execution = blocked ? { rejected: blocked } : executeAtReference({ cash, quantity }, mark2, intent, config);
    if ("rejected" in execution) {
      result.orders.push({
        intent,
        status: "rejected",
        reason: execution.rejected,
        resolvedUtcMs: time
      });
      return;
    }
    const { price, quantity: qty, notional, fee } = execution;
    const before = snapshot({ cash, quantity }, mark2);
    const beforeEquity = cash + quantity * mark2 / SCALE;
    const sign = intent.side === "buy" ? 1n : -1n;
    cash -= sign * notional + fee;
    quantity += sign * qty;
    fees += fee;
    if (intent.side === "buy") {
      buyNotional += notional;
      buyQuantity += qty;
    } else {
      sellNotional += notional;
      sellQuantity += qty;
    }
    const fill = {
      sequence: result.fills.length + 1,
      orderId: intent.id,
      side: intent.side,
      reason: intent.reason,
      signalCandleIndex: intent.signalCandleIndex,
      candleIndex: i,
      timestampUtcMs: time,
      ...intent.trigger ? { trigger: intent.trigger } : {},
      referencePrice: reference,
      price: decimal(price),
      quantity: decimal(qty),
      notional: decimal(notional),
      fee: decimal(fee),
      before,
      after: snapshot({ cash, quantity }, mark2),
      delta: {
        cash: decimal(-sign * notional - fee),
        quantity: decimal(sign * qty),
        equity: decimal(cash + quantity * mark2 / SCALE - beforeEquity)
      },
      totals: {
        buyNotional: decimal(buyNotional),
        sellNotional: decimal(sellNotional),
        fees: decimal(fees),
        buyQuantity: decimal(buyQuantity),
        sellQuantity: decimal(sellQuantity)
      }
    };
    audit(fill);
    result.fills.push(fill);
    result.orders.push({ intent, status: "filled", resolvedUtcMs: time });
    if (quantity === 0n) protection = void 0;
    else if (intent.side === "buy" && protectedRun)
      protection = protectionFor(price, risk);
  };
  const executeRisk = (trigger, i) => {
    const time = trigger.phase === "open" ? trigger.barOpenUtcMs : null;
    execute(
      {
        id: `risk-${i}`,
        side: "sell",
        quantity: "all",
        reason: trigger.kind,
        signalCandleIndex: null,
        generatedUtcMs: time,
        targetCandleIndex: i,
        trigger
      },
      i,
      trigger.referencePrice,
      time
    );
  };
  let cursor = 0;
  let completed = false;
  const advance = () => {
    if (completed || cursor >= tape.length) throw new Error("No next candle.");
    const i = cursor++;
    const c = tape[i], open = parseDecimal(c.open);
    const end = c.timestampUtcMs + intervalMs;
    const gap = protection && triggerAtOpen(protection, open, c.timestampUtcMs, end);
    if (gap) {
      executeRisk(gap, i);
      if (pending)
        result.orders.push({
          intent: pending,
          status: "cancelled",
          reason: "risk-priority",
          resolvedUtcMs: c.timestampUtcMs
        });
      pending = void 0;
    } else {
      if (pending) execute(pending, i, c.open, c.timestampUtcMs);
      pending = void 0;
      const activated = protection && triggerAtOpen(protection, open, c.timestampUtcMs, end);
      if (activated) executeRisk(activated, i);
      else {
        const touch = protection && triggerIntrabar(
          protection,
          parseDecimal(c.high),
          parseDecimal(c.low),
          c.timestampUtcMs,
          end
        );
        if (touch) executeRisk(touch, i);
      }
    }
    const closeTime = c.timestampUtcMs + intervalMs;
    result.closes.push({
      candleIndex: i,
      timestampUtcMs: closeTime,
      account: snapshot({ cash, quantity }, parseDecimal(c.close))
    });
    if (strategy) {
      const decision2 = strategy.onClose(Object.freeze({ ...d.candles[i] }));
      signals.push(
        decision2.action === "hold" ? { candleIndex: i, ...decision2, action: "hold" } : {
          candleIndex: i,
          ...decision2,
          action: decision2.action,
          quantity: "all"
        }
      );
    }
    const s = signals[nextSignal];
    if (s?.candleIndex === i) {
      nextSignal++;
      result.signals.push({ signal: s, generatedUtcMs: closeTime });
      if (s.action !== "hold")
        pending = {
          id: `order-${i}`,
          side: s.action,
          quantity: s.quantity,
          reason: s.reason,
          signalCandleIndex: i,
          generatedUtcMs: closeTime,
          targetCandleIndex: i + 1
        };
    }
    result.final = result.closes.at(-1).account;
    return result.closes.at(-1);
  };
  const finish = () => {
    if (completed) return result;
    if (cursor !== tape.length)
      throw new Error("Cannot finish before the last candle.");
    completed = true;
    if (pending)
      result.orders.push({
        intent: pending,
        status: "expired",
        reason: "no-next-candle",
        resolvedUtcMs: pending.generatedUtcMs
      });
    manifest.signalHash = contentHash(signals);
    manifest.runHash = contentHash({
      algorithmVersion: ALGORITHM_VERSION,
      conversionVersion: CONVERSION_VERSION,
      dataHash,
      signalHash: manifest.signalHash,
      config,
      completedThroughUtcMs,
      strategy: manifest.strategy,
      risk
    });
    result.final = result.closes.at(-1).account;
    pending = void 0;
    return result;
  };
  return {
    advance,
    finish,
    submit(signal) {
      if (!interactive || completed || cursor < 1 || signal.candleIndex !== cursor - 1 || signals.at(-1)?.candleIndex === signal.candleIndex)
        throw new Error(
          "Only one decision at the current revealed close is allowed."
        );
      const s = normalizeSignals([signal], tape.length)[0];
      if (s.action === "hold")
        throw new Error("Interactive hold requires no order.");
      signals.push(s);
      nextSignal++;
      const closeTime = d.candles[cursor - 1].timestampUtcMs + intervalMs;
      result.signals.push({ signal: s, generatedUtcMs: closeTime });
      pending = {
        id: "order-" + s.candleIndex,
        side: s.action,
        quantity: s.quantity,
        reason: s.reason,
        signalCandleIndex: s.candleIndex,
        generatedUtcMs: closeTime,
        targetCandleIndex: cursor
      };
    },
    get cursor() {
      return cursor;
    },
    get pending() {
      return pending ?? null;
    },
    get result() {
      return result;
    }
  };
}
function runBacktest(input) {
  const session = createBacktestSession(input);
  while (session.cursor < input.dataset.candles.length) session.advance();
  return session.finish();
}

// src/core/statistics/index.ts
var STATISTICS_VERSION = "statistics-v1";
var YEAR_MS = 365 * 24 * 60 * 60 * 1e3;
var na = (reason) => ({ value: null, reason });
var available = (value) => ({ value, reason: null });
function fraction(n, d) {
  if (d <= 0n) throw new Error("Ratio denominator must be positive.");
  return decimal(n * 10n ** 12n / d * 10n ** 6n);
}
var METRIC_DEFINITIONS = Object.freeze([
  "\u51C0\u76C8\u4E8F=\u672B\u6536\u76D8\u6743\u76CA\u2212\u521D\u59CB\u672C\u91D1\uFF1B\u6743\u76CA=\u73B0\u91D1+\u6309\u6536\u76D8\u4EF7\u5411\u4E0B\u4F30\u503C\u7684\u6301\u4ED3\u5E02\u503C\uFF1B\u4E0D\u5F3A\u5236\u672B\u5C3E\u5E73\u4ED3\u3002",
  "\u6210\u672C\u57FA\u7840\u542B\u4E70\u624B\u7EED\u8D39\uFF1B\u90E8\u5206\u9000\u51FA\u6309\u6570\u91CF\u6BD4\u4F8B\u5411\u4E0B\u5206\u914D\u6210\u672C\uFF0C\u6700\u540E\u5E73\u4ED3\u5206\u914D\u4F59\u6570\uFF1B\u5DF2\u5B9E\u73B0+\u6D6E\u52A8=\u51C0\u76C8\u4E8F\u3002\u6ED1\u70B9\u5DF2\u542B\u5728\u6210\u4EA4\u540D\u4E49\u989D\uFF0C\u4E0D\u91CD\u590D\u6263\u9664\u3002",
  "\u5B8C\u6210\u4EA4\u6613=\u7A7A\u4ED3\u81F3\u518D\u6B21\u7A7A\u4ED3\u7684\u5B8C\u6574\u5468\u671F\uFF1B\u80DC\u7387\u4EC5\u51C0\u76C8\u5229\u5468\u671F/\u5B8C\u6210\u5468\u671F\uFF08\u542B\u5E73\u624B\uFF09\uFF1B\u5229\u6DA6\u56E0\u5B50\u4EC5\u5B8C\u6210\u5468\u671F\u76C8\u5229\u603B\u548C/\u4E8F\u635F\u7EDD\u5BF9\u603B\u548C\uFF1B\u65E0\u4EA4\u6613\u6216\u65E0\u4E8F\u635F\u4E3ANA\u3002",
  "\u56DE\u64A4\u6309\u6BCF\u6839\u6536\u76D8\u6743\u76CA\u4E0E\u542B\u521D\u59CB\u951A\u70B9\u7684\u5386\u53F2\u5CF0\u503C\u8BA1\u7B97\uFF1B\u6700\u957F\u6301\u7EED\u65F6\u95F4\u5305\u62EC\u672B\u5C3E\u672A\u6062\u590D\u533A\u95F4\uFF1B\u4E0D\u4EE3\u8868\u6839\u5185\u6700\u5927\u98CE\u9669\u3002",
  "\u66B4\u9732\u4E3A\u6301\u4ED3\u8986\u76D6K\u7EBF\u533A\u95F4\u4E0A\u754C\uFF0C\u6839\u5185\u9000\u51FA\u8BA1\u6574\u6839\uFF0C\u5F00\u76D8\u6E05\u4ED3\u4E14\u672A\u91CD\u65B0\u4E70\u5165\u7684\u6839\u4E0D\u8BA1\uFF1B\u672A\u77E5\u6839\u5185\u65F6\u95F4\u4E0D\u4F2A\u9020\u7CBE\u786E\u66B4\u9732\u3002",
  "\u4E70\u5165\u6301\u6709\u9996\u6839\u5F00\u76D8\u4E70\u5165\uFF0C\u521D\u59CB\u672C\u91D1\u3001\u4E70\u6ED1\u70B9\u3001\u624B\u7EED\u8D39\u3001\u7CBE\u5EA6\u548C\u6700\u5C0F\u540D\u4E49\u989D\u76F8\u540C\uFF0C\u65E0\u4FDD\u62A4\uFF0C\u672B\u6536\u76D8\u4F30\u503C\u4E0D\u6E05\u4ED3\uFF0C\u4E0D\u6263\u5356\u6210\u672C\uFF1B\u62D2\u5355NA\u3002",
  "\u91D1\u989D18\u4F4DBigInt\u89C4\u8303\u5B57\u7B26\u4E32\uFF1B\u65E0\u91CF\u7EB2\u6BD4\u4F8B\u5411\u96F6\u622A\u65AD12\u4F4D\u3002\u5E74\u5316CAGR\u4EC5>=365\u5929\u4E14>=252\u6839\u3001\u9996\u672B\u6743\u76CA>0\uFF0C\u7528365\u5929\u5E74\u53CANumber\u8FD1\u4F3C\u5E42\uFF1B\u5426\u5219NA\u4E0E\u539F\u56E0\u3002"
]);
function allocateSaleCost(cost, quantity, sold) {
  if (sold > quantity || quantity === 0n)
    throw new Error("Invalid cost basis quantity.");
  return sold === quantity ? cost : cost * sold / quantity;
}
function calculateStatistics(r, firstOpen) {
  const { closes, fills, manifest: m } = r;
  if (!closes.length)
    throw new Error("\u7EDF\u8BA1\u9700\u8981\u6709\u6548\u6536\u76D8\u5FEB\u7167\uFF0C\u7A7A\u6837\u672C\u4E0D\u80FD\u751F\u6210\u6307\u6807\u3002");
  const initial = parseDecimal(m.config.initialCash);
  const start = closes[0].timestampUtcMs - m.intervalMs;
  const end = closes.at(-1).timestampUtcMs;
  const duration = end - start;
  if (!(duration > 0)) throw new Error("Invalid statistics time range.");
  let cost = 0n, quantity = 0n, realized = 0n, fees = 0n, episode = 0n, entry = 0;
  const completedTrades = [];
  const buyBars = /* @__PURE__ */ new Set();
  for (const f of fills) {
    const qty = readUnits(f.quantity), fee = readUnits(f.fee), notional = readUnits(f.notional);
    fees += fee;
    if (f.side === "buy") {
      if (quantity === 0n) {
        entry = f.candleIndex;
        episode = 0n;
      }
      cost += notional + fee;
      quantity += qty;
      buyBars.add(f.candleIndex);
    } else {
      const allocated = allocateSaleCost(cost, quantity, qty);
      const pnl = notional - fee - allocated;
      realized += pnl;
      episode += pnl;
      cost -= allocated;
      quantity -= qty;
      if (quantity === 0n)
        completedTrades.push({
          entryCandleIndex: entry,
          exitCandleIndex: f.candleIndex,
          netPnl: decimal(episode)
        });
    }
  }
  const finalEquity = readUnits(r.final.equity);
  const net = finalEquity - initial;
  const unrealized = readUnits(r.final.marketValue) - cost;
  if (realized + unrealized !== net || quantity !== readUnits(r.final.position.quantity))
    throw new Error("\u7EDF\u8BA1\u4E0E\u8D26\u672C\u7EC8\u503C\u4E0D\u4E00\u81F4\u3002");
  let wins = 0, gains = 0n, losses = 0n;
  for (const t of completedTrades) {
    const p = t.netPnl.startsWith("-") ? -readUnits(t.netPnl.slice(1)) : readUnits(t.netPnl);
    if (p > 0n) {
      wins++;
      gains += p;
    } else losses -= p;
  }
  const passive = executeAtReference(
    { cash: initial, quantity: 0n },
    parseDecimal(firstOpen),
    {
      id: "benchmark",
      side: "buy",
      quantity: "all",
      reason: "passive-first-open",
      signalCandleIndex: null,
      generatedUtcMs: start,
      targetCandleIndex: 0
    },
    m.config
  );
  const benchmarkFailure = "rejected" in passive ? `\u57FA\u51C6\u4E70\u5165\u88AB\u62D2\u7EDD\uFF1A${passive.rejected}` : null;
  const passiveCash = "rejected" in passive ? initial : initial - passive.notional - passive.fee;
  const passiveQty = "rejected" in passive ? 0n : passive.quantity;
  const intrabarSellBars = new Set(
    fills.filter((f) => f.side === "sell" && f.trigger?.phase === "intrabar").map((f) => f.candleIndex)
  );
  let peak = initial, peakTime = start, longest = 0, ongoing = 0, maxN = 0n, maxD = 0n, maxAmount = 0n;
  let exposedMs = 0;
  const curve = [
    {
      timestampUtcMs: start,
      equity: decimal(initial),
      drawdown: initial > 0n ? available("0") : na("\u5CF0\u503C\u6743\u76CA\u4E3A0"),
      benchmarkEquity: benchmarkFailure ? null : decimal(initial)
    }
  ];
  let benchmarkFinal = initial;
  for (const c of closes) {
    const equity = readUnits(c.account.equity);
    if (equity >= peak) {
      if (ongoing) longest = Math.max(longest, c.timestampUtcMs - peakTime);
      peak = equity;
      peakTime = c.timestampUtcMs;
      ongoing = 0;
    } else {
      ongoing = c.timestampUtcMs - peakTime;
      longest = Math.max(longest, ongoing);
    }
    const drawdown = peak - equity;
    if (peak > 0n && (maxD === 0n || drawdown * maxD > maxN * peak)) {
      maxN = drawdown;
      maxD = peak;
      maxAmount = drawdown;
    }
    const fs = fillsByBarExposure(c.candleIndex);
    if (readUnits(c.account.position.quantity) > 0n || buyBars.has(c.candleIndex) || fs)
      exposedMs += m.intervalMs;
    benchmarkFinal = passiveCash + passiveQty * readUnits(c.account.markPrice) / SCALE;
    if (benchmarkFinal >= ACCOUNTING_LIMIT)
      throw new Error("Benchmark derived accounting value exceeds limit.");
    curve.push({
      timestampUtcMs: c.timestampUtcMs,
      equity: c.account.equity,
      drawdown: peak > 0n ? available(fraction(drawdown, peak)) : na("\u5CF0\u503C\u6743\u76CA\u4E3A0"),
      benchmarkEquity: benchmarkFailure ? null : decimal(benchmarkFinal)
    });
  }
  function fillsByBarExposure(index) {
    return intrabarSellBars.has(index);
  }
  let annualizedReturn;
  if (duration < YEAR_MS || closes.length < 252)
    annualizedReturn = na("\u9700\u8981\u81F3\u5C11365\u5929\u4E14252\u6839\u6709\u6548\u6536\u76D8\u6837\u672C");
  else if (initial <= 0n || finalEquity <= 0n)
    annualizedReturn = na("\u5E74\u5316\u9700\u8981\u521D\u59CB\u548C\u672B\u6743\u76CA\u5747\u5927\u4E8E0");
  else {
    const value = Math.expm1(
      Math.log(Number(finalEquity) / Number(initial)) * YEAR_MS / duration
    );
    annualizedReturn = Number.isFinite(value) && Math.abs(value) < 1e21 ? available(value.toFixed(12)) : na("\u5E74\u5316\u8D85\u51FA\u53EF\u53EF\u9760\u8868\u793A\u8303\u56F4");
  }
  const rate = (n) => initial > 0n ? available(fraction(n, initial)) : na("\u521D\u59CB\u672C\u91D1\u4E3A0");
  return {
    version: STATISTICS_VERSION,
    netPnl: decimal(net),
    totalReturn: rate(net),
    realizedPnl: decimal(realized),
    unrealizedPnl: decimal(unrealized),
    remainingCostBasis: decimal(cost),
    fees: decimal(fees),
    completedTrades,
    winRate: completedTrades.length ? available(fraction(BigInt(wins), BigInt(completedTrades.length))) : na("\u6CA1\u6709\u5DF2\u5B8C\u6210\u4EA4\u6613"),
    profitFactor: !completedTrades.length ? na("\u6CA1\u6709\u5DF2\u5B8C\u6210\u4EA4\u6613") : losses > 0n ? available(fraction(gains, losses)) : na("\u5DF2\u5B8C\u6210\u4EA4\u6613\u6CA1\u6709\u51C0\u4E8F\u635F\uFF0C\u5206\u6BCD\u4E3A0"),
    maxDrawdown: maxD > 0n ? available(fraction(maxN, maxD)) : na("\u6CA1\u6709\u6B63\u5CF0\u503C\u6743\u76CA"),
    maxDrawdownAmount: decimal(maxAmount),
    maxDrawdownDurationMs: longest,
    ongoingDrawdownMs: ongoing,
    exposedMs,
    exposureFraction: fraction(BigInt(exposedMs), BigInt(duration)),
    annualizedReturn,
    benchmark: {
      return: benchmarkFailure ? na(benchmarkFailure) : rate(benchmarkFinal - initial),
      netPnl: benchmarkFailure ? na(benchmarkFailure) : available(decimal(benchmarkFinal - initial)),
      fee: "rejected" in passive ? "0" : decimal(passive.fee),
      quantity: decimal(passiveQty),
      cash: decimal(passiveCash),
      finalEquity: benchmarkFailure ? na(benchmarkFailure) : available(decimal(benchmarkFinal)),
      assumption: "\u540C\u533A\u95F4/\u672C\u91D1\uFF1B\u9996\u5F00\u76D8\u4E70\u5165\uFF0C\u6CBF\u7528\u4E70\u6ED1\u70B9/\u8D39/\u7CBE\u5EA6/\u6700\u5C0F\u989D\uFF1B\u65E0\u4FDD\u62A4\uFF1B\u672B\u6536\u76D8\u5E02\u503C\u8BA1\u91CF\u3001\u4E0D\u5F3A\u5236\u5E73\u4ED3\u3001\u4E0D\u6263\u5356\u6210\u672C\u3002"
    },
    curve
  };
}

// src/core/experiments/index.ts
var DISCLAIMER = "\u4EC5\u4F9B\u5B66\u4E60\u7814\u7A76\uFF0C\u5386\u53F2\u8868\u73B0\u4E0D\u4EE3\u8868\u672A\u6765\u8868\u73B0";
function runExperiment(input) {
  const result = runBacktest(input);
  const { candles, ...metadata2 } = input.dataset;
  const dataset = {
    ...JSON.parse(JSON.stringify(metadata2)),
    candles: candles.map((c) => ({ ...c }))
  };
  return {
    dataset,
    result,
    statistics: calculateStatistics(result, String(candles[0].open)),
    definitions: METRIC_DEFINITIONS,
    disclaimer: DISCLAIMER
  };
}
function sealExperiment(payload, metadata2) {
  return {
    schemaVersion: 1,
    ...metadata2,
    payloadHash: contentHash(payload),
    payload
  };
}
function summarizeExperiment(e) {
  return {
    id: e.id,
    name: e.name,
    createdUtcMs: e.createdUtcMs,
    payloadHash: e.payloadHash,
    symbol: e.payload.dataset.symbol,
    runHash: e.payload.result.manifest.runHash,
    strategy: e.payload.result.manifest.strategy.config.kind
  };
}
function assertExperimentMetadata(e) {
  if (!e || typeof e.id !== "string" || !e.id.length || e.id.length > 100 || typeof e.name !== "string" || !e.name.trim() || e.name.length > 160 || !Number.isSafeInteger(e.createdUtcMs) || e.createdUtcMs < 0 || e.createdUtcMs > 41024448e5 || !Number.isFinite(e.elapsedMs) || e.elapsedMs < 0)
    throw new Error("\u8EAB\u4EFD\u3001\u683C\u5F0F\u6216\u6821\u9A8C\u548C\u4E0D\u7B26");
}
function verifyExperiment(value, observeReplay) {
  const e = value;
  try {
    assertExperimentMetadata(e);
    if (e.schemaVersion !== 1 || !e.payload || contentHash(e.payload) !== e.payloadHash)
      throw new Error("\u8EAB\u4EFD\u3001\u683C\u5F0F\u6216\u6821\u9A8C\u548C\u4E0D\u7B26");
    const { result, dataset, statistics } = e.payload, m = result.manifest;
    if (m.algorithmVersion !== ALGORITHM_VERSION || statistics.version !== STATISTICS_VERSION || !m.strategy)
      throw new Error("\u7B97\u6CD5\u7248\u672C\u4E0D\u652F\u6301");
    const actual = runExperiment({
      dataset,
      config: m.config,
      risk: m.risk,
      strategy: m.strategy.config,
      completedThroughUtcMs: m.completedThroughUtcMs
    });
    const payloadHash = contentHash(actual);
    if (payloadHash !== e.payloadHash) throw new Error("\u91CD\u7B97\u7ED3\u679C\u4E0D\u4E00\u81F4");
    observeReplay?.({ ...e, payload: actual, payloadHash });
    return e;
  } catch (error) {
    throw new Error(
      `\u5B9E\u9A8C\u8BB0\u5F55\u635F\u574F\u6216\u7248\u672C\u4E0D\u652F\u6301\uFF1A${error instanceof Error ? error.message : "\u65E0\u6548\u8BB0\u5F55"}\uFF1B\u672A\u4FEE\u590D\u3002`,
      { cause: error }
    );
  }
}

// src/core/research/index.ts
var LIMITS = Object.freeze({
  candidates: 25,
  folds: 20,
  runs: 100,
  barEvaluations: 1e6
});
var RESEARCH_ASSUMPTIONS = Object.freeze([
  ...RUN_ASSUMPTIONS,
  "\u5019\u9009\u53C2\u6570\u5728\u6279\u6B21\u5F00\u59CB\u524D\u9501\u5B9A\uFF0C\u8BAD\u7EC3\u4E0E\u6D4B\u8BD5\u5747\u8FD0\u884C\u6240\u6709\u5019\u9009\uFF0C\u4E0D\u81EA\u52A8\u9009\u4F18\u3002",
  "\u6240\u6709\u7A97\u53E3\u72EC\u7ACB\uFF1A\u540C\u4E00\u521D\u59CB\u672C\u91D1\u3001\u7A7A\u4ED3\u3001\u6307\u6807\u51B7\u542F\u52A8\uFF1B\u4E0D\u8DE8\u8FB9\u754C\u4F20\u9012\u4FE1\u53F7\u3001\u4ED3\u4F4D\u6216\u9884\u70ED\u3002",
  "\u6EDA\u52A8\u4E3A\u56FA\u5B9A\u957F\u5EA6\u8BAD\u7EC3\u7A97\u5411\u524D\u79FB\u52A8\uFF0C\u6D4B\u8BD5\u7A97\u4E0D\u91CD\u53E0\uFF1B\u5C3E\u90E8\u4E0D\u8DB3\u5B8C\u6574\u6D4B\u8BD5\u7A97\u660E\u786E\u5217\u4E3A\u672A\u8BC4\u4F30\u3002",
  "\u8BAD\u7EC3/\u6D4B\u8BD5\u6536\u76CA\u4E0D\u62FC\u63A5\u3001\u4E0D\u590D\u5229\u3001\u4E0D\u81EA\u52A8\u6C47\u603B\u6210\u4E00\u6761\u6295\u8D44\u66F2\u7EBF\u3002",
  "\u70ED\u529B\u56FE\u4E3A\u4E8B\u5148\u58F0\u660E\u7684\u6709\u9650\u7F51\u683C\u63CF\u8FF0\uFF1B\u53CD\u590D\u67E5\u770B\u6D4B\u8BD5\u7ED3\u679C\u518D\u8C03\u53C2\u4F1A\u6C61\u67D3\u6837\u672C\u5916\u8BC1\u636E\u3002",
  "\u4EC5\u5F53\u524D\u5185\u5B58\u4FDD\u7559\u7814\u7A76\u7ED3\u679C\uFF1B\u5BFC\u51FA\u542B\u539F\u6570\u636E\u5FEB\u7167\u548C\u5168\u90E8\u53E3\u5F84\u7684JSON\uFF0C\u91CD\u65B0\u5BFC\u5165\u4F1A\u6821\u9A8C\u5E76\u91CD\u7B97\u3002"
]);
function integer2(value, min, max) {
  if (!Number.isSafeInteger(value) || value < min || value > max)
    throw new Error("\u7A97\u53E3/\u8BA1\u6570\u5FC5\u987B\u4E3A\u8303\u56F4\u5185\u6574\u6570\u3002");
}
function planWindows(length, evaluation) {
  integer2(length, 2, 5e4);
  if (!evaluation || typeof evaluation !== "object")
    throw new Error("\u7F3A\u5C11\u8BC4\u4F30\u65B9\u5F0F\u3002");
  const allowed = evaluation.kind === "full" ? ["kind"] : evaluation.kind === "split" ? ["kind", "trainBars"] : ["kind", "trainBars", "testBars"];
  if (Object.keys(evaluation).some((k) => !allowed.includes(k)))
    throw new Error("\u672A\u77E5\u8BC4\u4F30\u5B57\u6BB5\u3002");
  if (evaluation.kind === "full")
    return [{ fold: 0, role: "full", start: 0, end: length }];
  if (evaluation.kind !== "split" && evaluation.kind !== "rolling")
    throw new Error("\u672A\u77E5\u8BC4\u4F30\u65B9\u5F0F\u3002");
  integer2(evaluation.trainBars, 2, length - 2);
  if (evaluation.kind === "split")
    return [
      { fold: 0, role: "train", start: 0, end: evaluation.trainBars },
      { fold: 0, role: "test", start: evaluation.trainBars, end: length }
    ];
  integer2(evaluation.testBars, 2, length - evaluation.trainBars);
  const folds = Math.floor(
    (length - evaluation.trainBars) / evaluation.testBars
  );
  integer2(folds, 1, LIMITS.folds);
  return Array.from({ length: folds }, (_, fold) => {
    const start = fold * evaluation.testBars;
    return [
      {
        fold,
        role: "train",
        start,
        end: start + evaluation.trainBars
      },
      {
        fold,
        role: "test",
        start: start + evaluation.trainBars,
        end: start + evaluation.trainBars + evaluation.testBars
      }
    ];
  }).flat();
}
function windowDataset(dataset, window2) {
  const candles = dataset.candles.slice(window2.start, window2.end);
  return {
    ...dataset,
    id: "range-" + contentHash([dataset.id, window2.start, window2.end]),
    name: dataset.name.slice(0, 120) + " [" + window2.start + ":" + window2.end + "]",
    quality: {
      ...dataset.quality,
      totalRows: candles.length,
      validRows: candles.length,
      blankLines: 0,
      range: {
        startUtcMs: candles[0].timestampUtcMs,
        endUtcMs: candles.at(-1).timestampUtcMs
      }
    },
    candles
  };
}

// src/core/rule-library/index.ts
var RULE_JSON_LIMIT = 128 * 1024;
function sealRule(rule, metadata2) {
  const normalized = normalizeRule(rule);
  const body = {
    format: "riverlab-strategy-rule",
    schemaVersion: 1,
    id: `${metadata2.familyId}@${normalized.revision}`,
    familyId: metadata2.familyId,
    name: metadata2.name,
    createdUtcMs: metadata2.createdUtcMs,
    rule: normalized,
    ruleHash: contentHash(normalized)
  };
  const record = { ...body, recordHash: contentHash(body) };
  return verifyRuleRecord(record);
}
function verifyRuleRecord(value) {
  const r = value;
  const keys = [
    "format",
    "schemaVersion",
    "id",
    "familyId",
    "name",
    "createdUtcMs",
    "rule",
    "ruleHash",
    "recordHash"
  ];
  if (!r || Object.getPrototypeOf(r) !== Object.prototype || Object.keys(r).length !== keys.length || keys.some((k) => !Object.hasOwn(r, k)) || r.format !== "riverlab-strategy-rule" || r.schemaVersion !== 1 || typeof r.familyId !== "string" || !/^[a-zA-Z0-9_-]{1,80}$/.test(r.familyId) || typeof r.name !== "string" || !r.name.trim() || r.name.length > 160 || !Number.isSafeInteger(r.createdUtcMs) || r.createdUtcMs < 0 || r.createdUtcMs > 41024448e5)
    throw new Error("\u7B56\u7565\u7248\u672C\u683C\u5F0F/\u5B57\u6BB5/\u8EAB\u4EFD\u65E0\u6548\uFF0C\u672A\u8FC1\u79FB\u6216\u4FEE\u590D\u3002");
  const rule = normalizeRule(r.rule);
  const { recordHash, ...body } = r;
  if (r.id !== `${r.familyId}@${rule.revision}` || r.ruleHash !== contentHash(rule) || recordHash !== contentHash(body))
    throw new Error("\u7B56\u7565\u7248\u672C\u6821\u9A8C\u548C\u4E0D\u7B26\uFF0C\u672A\u4FEE\u590D\u3002");
  return { ...r, rule };
}

// src/core/portfolio/alignment.ts
var MAX_PORTFOLIO_BARS = 1e4;
var LAST_UTC_MS = 41024448e5;
var HUNDRED_PERCENT = 100n * SCALE;
function requireFields(value, required, optional = []) {
  if (!value || Object.getPrototypeOf(value) !== Object.prototype || required.some((key) => !Object.hasOwn(value, key)) || Object.keys(value).some(
    (key) => !required.includes(key) && !optional.includes(key)
  ))
    throw new Error("\u7EC4\u5408\u5FEB\u7167\u5B57\u6BB5\u7F3A\u5931\u6216\u542B\u6709\u672A\u77E5\u5B57\u6BB5\u3002");
}
function canonicalSymbol(symbol, quote) {
  const text3 = symbol.trim().toUpperCase();
  const separated = /^([A-Z0-9]{1,32})[/-]([A-Z0-9]{1,32})$/.exec(text3);
  const base = separated ? separated[1] : text3.endsWith(quote) ? text3.slice(0, -quote.length) : "";
  if (separated && separated[2] !== quote || !/^[A-Z0-9]{1,32}$/.test(base) || base === quote)
    throw new Error(
      `\u4EA4\u6613\u5BF9 ${symbol} \u4E0E\u62A5\u4EF7\u8D27\u5E01 ${quote} \u4E0D\u4E00\u81F4\u6216\u683C\u5F0F\u4E0D\u660E\u786E\u3002`
    );
  return `${base}/${quote}`;
}
function utc(value) {
  return Number.isSafeInteger(value) && value >= 0 && value <= LAST_UTC_MS;
}
function previewAlignment(datasets, quoteCurrency, startUtcMs, endUtcMs) {
  if (!Array.isArray(datasets) || datasets.length < 2 || datasets.length > 5)
    throw new Error("\u8BF7\u9009\u62E9 2\u20135 \u4E2A\u4E0D\u540C\u4EA4\u6613\u5BF9\u3002");
  const quote = typeof quoteCurrency === "string" ? quoteCurrency.trim().toUpperCase() : "";
  if (!/^[A-Z0-9]{1,32}$/.test(quote))
    throw new Error("\u8BF7\u660E\u786E\u586B\u5199\u7EDF\u4E00\u62A5\u4EF7\u8D27\u5E01\u3002");
  const ids = /* @__PURE__ */ new Set();
  const symbols = /* @__PURE__ */ new Set();
  const intervalMs = datasets[0]?.quality?.intervalMs;
  if (!intervalMs || !Number.isSafeInteger(intervalMs) || intervalMs <= 0)
    throw new Error("K \u7EBF\u5468\u671F\u5FC5\u987B\u4E3A\u5DF2\u786E\u8BA4\u7684\u6B63\u6574\u6570\u6BEB\u79D2\u3002");
  let totalSourceBars = 0;
  const sources = datasets.map((d) => {
    if (!d || typeof d.id !== "string" || typeof d.symbol !== "string")
      throw new Error("\u6570\u636E\u96C6\u8EAB\u4EFD\u4E0D\u5B8C\u6574\u3002");
    const symbol = canonicalSymbol(d.symbol, quote);
    if (ids.has(d.id) || symbols.has(symbol))
      throw new Error(`\u91CD\u590D\u6570\u636E\u96C6\u6216\u4EA4\u6613\u5BF9\uFF1A${symbol}\u3002`);
    ids.add(d.id);
    symbols.add(symbol);
    const quality = d.quality;
    if (!quality || quality.intervalMs !== intervalMs)
      throw new Error("\u6240\u6709\u8D44\u4EA7\u7684 K \u7EBF\u5468\u671F\u5FC5\u987B\u76F8\u540C\u3002");
    if (quality.gapCount || quality.missingCandles)
      throw new Error(`${symbol} \u539F\u59CB\u6570\u636E\u5B58\u5728\u7F3A\u53E3\uFF0C\u4E0D\u80FD\u8FD0\u884C\u7EC4\u5408\u3002`);
    const range = quality.range;
    if (!range || !utc(range.startUtcMs) || !utc(range.endUtcMs) || !Number.isSafeInteger(quality.validRows) || quality.validRows < 1 || range.endUtcMs - range.startUtcMs !== (quality.validRows - 1) * intervalMs)
      throw new Error(`${symbol} \u7684\u8986\u76D6\u8303\u56F4\u6216\u884C\u6570\u4E0D\u4E00\u81F4\u3002`);
    totalSourceBars += quality.validRows;
    return {
      symbol,
      sourceStartUtcMs: range.startUtcMs,
      sourceEndUtcMs: range.endUtcMs
    };
  });
  if (totalSourceBars > MAX_PORTFOLIO_BARS)
    throw new Error(
      `\u6240\u6709\u539F\u59CB\u5FEB\u7167\u5408\u8BA1\u6700\u591A ${MAX_PORTFOLIO_BARS} \u6839\uFF08\u5305\u542B\u622A\u53D6\u533A\u95F4\u5916\u7684\u6570\u636E\uFF09\u3002`
    );
  const commonStartUtcMs = Math.max(...sources.map((s) => s.sourceStartUtcMs));
  const commonEndUtcMs = Math.min(...sources.map((s) => s.sourceEndUtcMs));
  if (commonStartUtcMs > commonEndUtcMs)
    throw new Error("\u6240\u9009\u6570\u636E\u96C6\u6CA1\u6709\u5171\u540C\u5386\u53F2\u533A\u95F4\u3002");
  const start = startUtcMs === void 0 ? commonStartUtcMs : startUtcMs;
  const end = endUtcMs === void 0 ? commonEndUtcMs : endUtcMs;
  if (!utc(start) || !utc(end) || start < commonStartUtcMs || end > commonEndUtcMs || end < start || end + intervalMs > LAST_UTC_MS)
    throw new Error("\u786E\u8BA4\u533A\u95F4\u5FC5\u987B\u4F4D\u4E8E\u5171\u540C\u5386\u53F2\u533A\u95F4\u5185\uFF0C\u9996\u672B\u6839\u80FD\u591F\u5B8C\u6574\u6536\u76D8\u3002");
  const assets = sources.map((s) => {
    const beforeCount = (start - s.sourceStartUtcMs) / intervalMs;
    const afterCount = (s.sourceEndUtcMs - end) / intervalMs;
    if (!Number.isInteger(beforeCount) || !Number.isInteger(afterCount))
      throw new Error(`${s.symbol} \u7684 UTC \u5F00\u76D8\u65F6\u95F4\u672A\u4E25\u683C\u5BF9\u9F50\u3002`);
    return {
      ...s,
      beforeCount,
      afterCount,
      beforeRange: beforeCount ? { startUtcMs: s.sourceStartUtcMs, endUtcMs: start - intervalMs } : null,
      afterRange: afterCount ? { startUtcMs: end + intervalMs, endUtcMs: s.sourceEndUtcMs } : null
    };
  });
  return {
    quoteCurrency: quote,
    intervalMs,
    commonStartUtcMs,
    commonEndUtcMs,
    startUtcMs: start,
    endUtcMs: end,
    barCount: (end - start) / intervalMs + 1,
    totalSourceBars,
    assets
  };
}
function allocate(input, coverage) {
  const capital = parseDecimal(input.initialCash);
  if (capital === 0n) throw new Error("\u7EC4\u5408\u521D\u59CB\u672C\u91D1\u5FC5\u987B\u5927\u4E8E\u96F6\u3002");
  const weights = input.assets.map((a) => parseDecimal(a.weightPercent));
  if (weights.some((w) => w <= 0n) || weights.reduce((sum2, w) => sum2 + w, 0n) !== HUNDRED_PERCENT)
    throw new Error("\u6BCF\u4E2A\u5E01\u79CD\u7684\u521D\u59CB\u6743\u91CD\u987B\u4E3A\u6B63\uFF0C\u6743\u91CD\u603B\u548C\u5FC5\u987B\u7CBE\u786E\u7B49\u4E8E 100%\u3002");
  const numerators = weights.map((w) => capital * w);
  const cash = numerators.map((n) => n / HUNDRED_PERCENT);
  const residual = capital - cash.reduce((sum2, n) => sum2 + n, 0n);
  const priority = numerators.map((n, i) => ({
    index: i,
    symbol: coverage[i].symbol,
    remainder: n % HUNDRED_PERCENT
  })).sort((a, b) => {
    if (a.remainder !== b.remainder)
      return a.remainder > b.remainder ? -1 : 1;
    return a.symbol < b.symbol ? -1 : 1;
  });
  for (let i = 0; i < Number(residual); i++) cash[priority[i].index]++;
  const empty = cash.findIndex((amount) => amount === 0n);
  if (empty !== -1)
    throw new Error(
      `${coverage[empty].symbol} \u7684\u5206\u914D\u91D1\u989D\u53D6\u6574\u540E\u4E3A\u96F6\uFF0C\u8BF7\u589E\u52A0\u672C\u91D1\u6216\u8C03\u6574\u6743\u91CD\u3002`
    );
  return cash.map(decimal);
}
function alignPortfolioSources(input) {
  if (input.rangeConfirmed !== true)
    throw new Error("\u8BF7\u660E\u786E\u786E\u8BA4\u5171\u540C\u533A\u95F4\uFF0C\u786E\u8BA4\u540E\u624D\u80FD\u8FD0\u884C\u3002");
  if (!Array.isArray(input.assets) || input.assets.length < 2 || input.assets.length > 5)
    throw new Error("\u7EC4\u5408\u5FC5\u987B\u5305\u542B 2\u20135 \u4E2A\u4E0D\u540C\u4EA4\u6613\u5BF9\u3002");
  let bars = 0;
  for (const a of input.assets) {
    if (!Array.isArray(a.dataset?.candles))
      throw new Error("\u7F3A\u5C11\u5B8C\u6574\u6570\u636E\u5FEB\u7167\u3002");
    bars += a.dataset.candles.length;
  }
  if (bars > MAX_PORTFOLIO_BARS)
    throw new Error(`\u6240\u6709\u539F\u59CB\u5FEB\u7167\u5408\u8BA1\u6700\u591A ${MAX_PORTFOLIO_BARS} \u6839\u3002`);
  for (const { dataset } of input.assets) {
    assertDataset(dataset);
    validateSnapshotFields(dataset);
  }
  if (!utc(input.startUtcMs) || !utc(input.endUtcMs))
    throw new Error("\u5FC5\u987B\u660E\u786E\u786E\u8BA4\u533A\u95F4\u7684 UTC \u6BEB\u79D2\u8D77\u6B62\u65F6\u95F4\u3002");
  const alignment = previewAlignment(
    input.assets.map((a) => a.dataset),
    input.quoteCurrency,
    input.startUtcMs,
    input.endUtcMs
  );
  if (!utc(input.completedThroughUtcMs) || input.endUtcMs + alignment.intervalMs > input.completedThroughUtcMs)
    throw new Error("\u6240\u9009\u533A\u95F4\u5305\u542B\u672A\u5B8C\u6210\u6536\u76D8\u7684 K \u7EBF\u3002");
  return alignment;
}
function executionConfig(costs, initialCash) {
  requireFields(costs, [
    "feeBps",
    "buySlippageBps",
    "sellSlippageBps",
    "quantityDecimals",
    "minNotional"
  ]);
  return normalizeConfig({ ...costs, initialCash });
}
function assetStrategy(asset, symbol) {
  const strategy = normalizeStrategy(asset.strategy);
  if (strategy.kind === "rules") {
    const record = verifyRuleRecord(asset.ruleRecord);
    if (canonicalJson(strategy.rule) !== canonicalJson(record.rule))
      throw new Error(`${symbol} \u7B56\u7565\u4E0E\u4FDD\u5B58\u7684\u89C4\u5219\u7248\u672C\u4E0D\u4E00\u81F4\u3002`);
  } else if (Object.hasOwn(asset, "ruleRecord"))
    throw new Error("\u5185\u7F6E\u7B56\u7565\u4E0D\u80FD\u9644\u52A0\u89C4\u5219\u7248\u672C\u3002");
  return strategy;
}
function preparePortfolio(input) {
  requireFields(input, [
    "initialCash",
    "quoteCurrency",
    "startUtcMs",
    "endUtcMs",
    "completedThroughUtcMs",
    "rangeConfirmed",
    "assets"
  ]);
  const alignment = alignPortfolioSources(input);
  for (const a of input.assets) {
    requireFields(
      a,
      ["dataset", "weightPercent", "strategy", "costs", "risk"],
      ["ruleRecord"]
    );
  }
  const allocations = allocate(input, alignment.assets);
  const assets = input.assets.map((asset, i) => {
    const cover = alignment.assets[i];
    const initialCash = allocations[i];
    const config = executionConfig(asset.costs, initialCash);
    const strategy = assetStrategy(asset, cover.symbol);
    return {
      symbol: cover.symbol,
      weightPercent: decimal(parseDecimal(asset.weightPercent)),
      initialCash,
      strategy,
      config,
      risk: normalizeRisk(asset.risk),
      dataset: windowDataset(asset.dataset, {
        fold: 0,
        role: "full",
        start: cover.beforeCount,
        end: asset.dataset.candles.length - cover.afterCount
      })
    };
  });
  return { alignment, assets };
}

// src/core/portfolio/report-common.ts
var MAX_PORTFOLIO_REPORT_BYTES = 32 * 1024 * 1024;
var PORTFOLIO_WORKING_BUDGET_BYTES = 256 * 1024 * 1024;
function assertPortfolioMemoryBudget(value, allowUndefined = false) {
  let bytes = MAX_PORTFOLIO_REPORT_BYTES * 4;
  function charge(n) {
    bytes += 2 * n;
    if (bytes > PORTFOLIO_WORKING_BUDGET_BYTES)
      throw new Error("\u7EC4\u5408\u4F30\u7B97\u5DE5\u4F5C\u5185\u5B58\u8D85\u8FC7 256 MiB\u3002");
  }
  function visit(node, depth) {
    if (depth > 40) throw new Error("\u7EC4\u5408\u62A5\u544A\u5D4C\u5957\u8FC7\u6DF1\u3002");
    if (typeof node === "string") {
      charge(32 + node.length * 2);
      if (node.length > 4096) throw new Error("\u7EC4\u5408\u62A5\u544A\u5B57\u6BB5\u8FC7\u957F\u3002");
    } else if (Array.isArray(node)) {
      charge(32 + node.length * 8);
      if (Object.keys(node).length !== node.length)
        throw new Error("\u7EC4\u5408\u62A5\u544A\u542B\u7A00\u758F\u6570\u7EC4\u6216\u989D\u5916\u6570\u7EC4\u5B57\u6BB5\u3002");
      for (let i = 0; i < node.length; i++) {
        if (!Object.hasOwn(node, i)) throw new Error("\u7EC4\u5408\u62A5\u544A\u542B\u7A00\u758F\u6570\u7EC4\u3002");
        visit(node[i], depth + 1);
      }
    } else if (node !== null && typeof node === "object") {
      if (Object.getPrototypeOf(node) !== Object.prototype)
        throw new Error("\u7EC4\u5408\u62A5\u544A\u53EA\u80FD\u5305\u542B\u666E\u901A JSON \u5BF9\u8C61\u3002");
      charge(64);
      for (const key of Object.keys(node)) {
        charge(16 + 2 * key.length);
        if (key.length > 256) throw new Error("\u7EC4\u5408\u62A5\u544A\u952E\u540D\u8FC7\u957F\u3002");
        visit(node[key], depth + 1);
      }
    } else if (node === null || typeof node === "boolean" || typeof node === "number" && Number.isFinite(node) || allowUndefined && node === void 0)
      charge(16);
    else throw new Error("\u7EC4\u5408\u62A5\u544A\u5305\u542B\u975E JSON \u503C\u3002");
  }
  visit(value, 0);
}
var digestPattern = /^[a-f0-9]{64}$/;
function assertMetadata(m) {
  if (!m || typeof m.id !== "string" || !m.id.trim() || m.id.length > 100 || typeof m.name !== "string" || !m.name.trim() || m.name.length > 160 || !Number.isSafeInteger(m.createdUtcMs) || m.createdUtcMs < 0 || m.createdUtcMs > 41024448e5)
    throw new Error("\u7EC4\u5408\u5B9E\u9A8C\u8EAB\u4EFD\u3001\u540D\u79F0\u6216\u65F6\u95F4\u65E0\u6548\u3002");
}
function digestPortfolioPayload(input, result, headerWithEmptyHashes) {
  assertPortfolioMemoryBudget({ input, result });
  let bytes = canonicalJson(headerWithEmptyHashes).length - 1;
  const hash3 = sha256.create();
  forEachCanonicalChunk({ input, result }, (chunk) => {
    bytes += chunk.length;
    if (bytes > MAX_PORTFOLIO_REPORT_BYTES)
      throw new Error("\u7EC4\u5408\u62A5\u544A\u8D85\u8FC7 32 MiB \u9884\u7B97\uFF0C\u8BF7\u7F29\u77ED\u56DE\u6D4B\u533A\u95F4\u6216\u51CF\u5C11\u6570\u636E\u91CF\u3002");
    hash3.update(chunk);
  });
  return Array.from(hash3.digest(), (n) => n.toString(16).padStart(2, "0")).join(
    ""
  );
}
function checkSource(input, observedUtcMs) {
  if (!input || !Number.isSafeInteger(observedUtcMs) || !Number.isSafeInteger(input.completedThroughUtcMs) || input.completedThroughUtcMs > observedUtcMs)
    throw new Error("\u7EC4\u5408\u6536\u76D8\u786E\u8BA4\u65F6\u95F4\u65E0\u6548\u6216\u665A\u4E8E\u5F53\u524D\u65F6\u95F4\u3002");
  if (!Array.isArray(input.assets) || input.assets.length < 2 || input.assets.length > 5)
    throw new Error("\u7EC4\u5408\u9700\u8981 2\u20135 \u4E2A\u8D44\u4EA7\u3002");
  let rows = 0;
  for (const asset of input.assets) {
    if (!Array.isArray(asset?.dataset?.candles))
      throw new Error("\u7EC4\u5408\u884C\u60C5\u5FEB\u7167\u635F\u574F\u3002");
    rows += asset.dataset.candles.length;
    if (rows > MAX_PORTFOLIO_BARS)
      throw new Error("\u6240\u6709\u6E90\u6570\u636E\u5408\u8BA1\u6700\u591A 10,000 \u6839\u3002");
    assertDataset(asset.dataset);
    validateSnapshotFields(asset.dataset);
  }
}
function summarizePortfolio(e) {
  const { id, name, createdUtcMs, payloadHash } = e;
  return {
    id,
    name,
    createdUtcMs,
    payloadHash,
    symbols: e.input.assets.map((a) => a.dataset.symbol)
  };
}
function assertPortfolioSummary(s) {
  assertMetadata(s);
  if (typeof s.payloadHash !== "string" || !digestPattern.test(s.payloadHash) || !Array.isArray(s.symbols) || s.symbols.length < 2 || s.symbols.length > 5 || Array.from(s.symbols).some(
    (v) => typeof v !== "string" || !v.trim() || v.length > 80
  ) || new Set(s.symbols).size !== s.symbols.length)
    throw new Error("\u7EC4\u5408\u6458\u8981\u635F\u574F\u3002");
}

// src/core/market-regime/ledger.ts
function ledgerAttribution(marks) {
  const changes = marks.map(() => ({
    fills: 0,
    fees: 0n,
    realized: 0n,
    cost: 0n,
    openPositions: 0,
    intrabar: false
  }));
  const holdings = /* @__PURE__ */ new Map();
  let fees = 0n, fills = 0;
  function apply(symbol, index, fill) {
    const bar = changes[index];
    const holding = holdings.get(symbol) ?? { quantity: 0n, cost: 0n };
    const quantity = readUnits(fill.quantity);
    const notional = readUnits(fill.notional);
    const fee = readUnits(fill.fee);
    const oldCost = holding.cost;
    const oldQuantity = holding.quantity;
    if (fill.side === "buy") {
      holding.quantity += quantity;
      holding.cost += notional + fee;
    } else {
      const allocated = allocateSaleCost(oldCost, oldQuantity, quantity);
      holding.quantity -= quantity;
      holding.cost -= allocated;
      bar.realized += notional - fee - allocated;
    }
    bar.openPositions += Number(holding.quantity > 0n) - Number(oldQuantity > 0n);
    bar.intrabar ||= fill.side === "buy" || fill.trigger?.phase === "intrabar";
    bar.cost += holding.cost - oldCost;
    bar.fees += fee;
    bar.fills++;
    fees += fee;
    fills++;
    holdings.set(symbol, holding);
  }
  function finish(expectedFees, expectedFills, statistics) {
    if (decimal(fees) !== expectedFees || fills !== expectedFills)
      throw new Error("\u6210\u4EA4\u6B21\u6570\u6216\u8D39\u7528\u4E0E\u539F\u5B9E\u9A8C\u4E0D\u4E00\u81F4\u3002");
    let previousMarket = 0n, positions = 0, realized = 0n, unrealized = 0n;
    const bars = marks.map((point, i) => {
      const bar = changes[i];
      const market = readUnits(point.marketValue);
      const unrealizedDelta = market - previousMarket - bar.cost;
      previousMarket = market;
      positions += bar.openPositions;
      realized += bar.realized;
      unrealized += unrealizedDelta;
      return {
        closeUtcMs: point.timestampUtcMs,
        equity: point.equity,
        realizedDelta: decimal(bar.realized),
        unrealizedDelta: decimal(unrealizedDelta),
        fills: bar.fills,
        fees: decimal(bar.fees),
        exposed: positions > 0 || bar.intrabar
      };
    });
    if (statistics) {
      const sum2 = (field3) => statistics.reduce((total, s) => total + signed(s[field3]), 0n);
      if (realized !== sum2("realizedPnl") || unrealized !== sum2("unrealizedPnl"))
        throw new Error("\u5DF2\u5B9E\u73B0\u53CA\u6D6E\u52A8\u76C8\u4E8F\u4E0E\u539F\u5B9E\u9A8C\u4E0D\u4E00\u81F4\u3002");
    }
    return bars;
  }
  return { apply, finish };
}
function signed(text3) {
  return text3.startsWith("-") ? -readUnits(text3.slice(1)) : readUnits(text3);
}
function singleBars(result, statistics) {
  const ledger = ledgerAttribution(
    result.closes.map((c) => ({
      timestampUtcMs: c.timestampUtcMs,
      equity: c.account.equity,
      marketValue: c.account.marketValue
    }))
  );
  for (const f of result.fills)
    ledger.apply(result.manifest.symbol, f.candleIndex, f);
  const bars = ledger.finish(statistics.fees, result.fills.length, [
    statistics
  ]);
  if (bars.reduce(
    (ms, b) => ms + (b.exposed ? result.manifest.intervalMs : 0),
    0
  ) !== statistics.exposedMs)
    throw new Error("\u6301\u4ED3\u66B4\u9732\u4E0E\u539F\u5B9E\u9A8C\u4E0D\u4E00\u81F4\u3002");
  return bars;
}
function portfolioBars(result) {
  const ledger = ledgerAttribution(result.curve.slice(1));
  for (const a of result.assets)
    for (const f of a.result.fills) ledger.apply(a.symbol, f.candleIndex, f);
  return ledger.finish(
    result.fees,
    result.fillCount,
    result.assets.map((a) => a.statistics)
  );
}
function sharedBars(result) {
  const ledger = ledgerAttribution(result.curve.slice(1));
  for (const f of result.orders)
    if (f.status === "filled") ledger.apply(f.symbol, f.barIndex, f);
  return ledger.finish(result.fees, result.fillCount);
}

// src/core/market-regime/model.ts
var REGIME_MODEL_VERSION = "historical-close-return-bps-v1";
var REGIME_ATTRIBUTION_VERSION = "previous-close-equity-v1";
var REGIMES = ["BULL", "BEAR", "SIDEWAYS", "UNKNOWN"];
var DEFAULT_REGIME_PARAMS = Object.freeze({
  lookback: 20,
  thresholdBps: 500
});
function assertRegimeParams(params) {
  if (!params || typeof params !== "object" || Object.getPrototypeOf(params) !== Object.prototype || Object.keys(params).length !== 2 || !Object.hasOwn(params, "lookback") || !Object.hasOwn(params, "thresholdBps") || !Number.isInteger(params.lookback) || params.lookback < 1 || params.lookback > MAX_DATA_ROWS || !Number.isInteger(params.thresholdBps) || params.thresholdBps < 1 || params.thresholdBps > 1e4)
    throw new Error(
      "\u56DE\u770B\u5468\u671F\u987B\u4E3A 1\u201350,000 \u6839\uFF0C\u8D8B\u52BF\u9608\u503C\u987B\u4E3A 1\u201310,000 \u4E2A\u6574\u6570\u57FA\u70B9\u3002"
    );
}
function classifyRegimes(candles, intervalMs, completedThroughUtcMs, params) {
  assertRegimeParams(params);
  if (!Array.isArray(candles) || !candles.length || candles.length > MAX_DATA_ROWS || !Number.isSafeInteger(intervalMs) || intervalMs <= 0 || !Number.isSafeInteger(completedThroughUtcMs) || completedThroughUtcMs < 0)
    throw new Error("\u884C\u60C5\u6570\u91CF\u3001\u5468\u671F\u6216\u6536\u76D8\u786E\u8BA4\u65F6\u95F4\u65E0\u6548\u3002");
  const { lookback, thresholdBps } = params;
  const threshold = BigInt(thresholdBps);
  const past = [];
  const labels = [];
  for (const [i, candle] of candles.entries()) {
    const openTime = candle.timestampUtcMs;
    if (!Number.isSafeInteger(openTime) || openTime < 0 || openTime + intervalMs > completedThroughUtcMs || i > 0 && openTime - candles[i - 1].timestampUtcMs !== intervalMs)
      throw new Error("\u884C\u60C5\u672A\u5B8C\u6210\u3001\u6709\u7F3A\u53E3\u6216 UTC \u65F6\u95F4\u9519\u4F4D\uFF0C\u65E0\u6CD5\u8BA1\u7B97\u5E02\u573A\u72B6\u6001\u3002");
    const close = parseDecimal(String(candle.close));
    if (close <= 0n) throw new Error("\u72B6\u6001\u8BC6\u522B\u9700\u8981\u6B63\u7684\u5DF2\u5B8C\u6210\u6536\u76D8\u4EF7\u3002");
    const slot = i % lookback;
    let label = "UNKNOWN";
    if (i >= lookback) {
      const base = past[slot];
      const difference = (close - base) * BPS;
      const boundary = base * threshold;
      if (difference > boundary) label = "BULL";
      else if (difference < -boundary) label = "BEAR";
      else label = "SIDEWAYS";
    }
    labels.push(label);
    past[slot] = close;
  }
  return labels;
}
var RETURN_SCALE = 10n ** 12n;
var toFraction = (scaled) => decimal(scaled * 10n ** 6n);
function distribution(values) {
  const count = values.length;
  if (!count)
    return {
      count,
      min: null,
      median: null,
      max: null,
      mean: null,
      volatility: null
    };
  values.sort((a, b) => a < b ? -1 : a > b ? 1 : 0);
  let sum2 = 0n;
  let sumSquares = 0n;
  for (const value of values) {
    sum2 += value;
    sumSquares += value * value;
  }
  const n = BigInt(count);
  const middle = Math.floor(count / 2);
  const median = count % 2 ? values[middle] : (values[middle - 1] + values[middle]) / 2n;
  return {
    count,
    min: toFraction(values[0]),
    max: toFraction(values[count - 1]),
    mean: toFraction(sum2 / n),
    median: toFraction(median),
    volatility: count < 2 ? null : toFraction(integerSqrt(n * sumSquares - sum2 * sum2) / n)
  };
}
function signedAmount(value) {
  return value.startsWith("-") ? -readUnits(value.slice(1)) : readUnits(value);
}
function bucket(state) {
  return {
    state,
    bars: 0,
    occurrences: 0,
    exposedMs: 0,
    fills: 0,
    netPnl: 0n,
    realizedDelta: 0n,
    unrealizedDelta: 0n,
    fees: 0n,
    periodReturns: [],
    assetReturns: []
  };
}
function analyzeRegimes(input, params) {
  const { candles, intervalMs, bars } = input;
  const labels = classifyRegimes(
    candles,
    intervalMs,
    input.completedThroughUtcMs,
    params
  );
  if (bars.length !== candles.length)
    throw new Error("\u884C\u60C5\u4E0E\u6743\u76CA\u8D26\u672C\u957F\u5EA6\u4E0D\u4E00\u81F4\u3002");
  const groups = {
    BULL: bucket("BULL"),
    BEAR: bucket("BEAR"),
    SIDEWAYS: bucket("SIDEWAYS"),
    UNKNOWN: bucket("UNKNOWN")
  };
  const runs = [];
  const initial = readUnits(input.initialCash);
  let previousEquity = initial;
  let previousPrice = parseDecimal(String(candles[0].open));
  if (previousPrice <= 0n) throw new Error("\u9996\u6839\u5F00\u76D8\u4EF7\u5FC5\u987B\u4E3A\u6B63\u3002");
  let runStartEquity = initial;
  for (const [i, bar] of bars.entries()) {
    const candle = candles[i];
    if (candle.timestampUtcMs + intervalMs !== bar.closeUtcMs)
      throw new Error("\u884C\u60C5\u4E0E\u6743\u76CA\u6536\u76D8\u65F6\u523B\u9519\u4F4D\u3002");
    const state = i > 0 ? labels[i - 1] : "UNKNOWN";
    const group = groups[state];
    const equity = readUnits(bar.equity);
    const delta = equity - previousEquity;
    const realized = signedAmount(bar.realizedDelta);
    const unrealized = signedAmount(bar.unrealizedDelta);
    if (delta !== realized + unrealized)
      throw new Error("\u9010\u6839\u6743\u76CA\u53D8\u5316\u4E0E\u5DF2\u5B9E\u73B0\u3001\u6D6E\u52A8\u76C8\u4E8F\u53D8\u5316\u4E0D\u5B88\u6052\u3002");
    if (!Number.isSafeInteger(bar.fills) || bar.fills < 0 || typeof bar.exposed !== "boolean")
      throw new Error("\u6210\u4EA4\u6570\u91CF\u6216\u6301\u4ED3\u66B4\u9732\u65E0\u6548\u3002");
    group.bars++;
    group.netPnl += delta;
    group.realizedDelta += realized;
    group.unrealizedDelta += unrealized;
    group.fills += bar.fills;
    group.fees += readUnits(bar.fees);
    if (bar.exposed) group.exposedMs += intervalMs;
    if (previousEquity > 0n)
      group.periodReturns.push(delta * RETURN_SCALE / previousEquity);
    const price = parseDecimal(String(candle.close));
    group.assetReturns.push(
      (price - previousPrice) * RETURN_SCALE / previousPrice
    );
    if (runs.at(-1)?.state !== state) {
      group.occurrences++;
      runStartEquity = previousEquity;
      runs.push({
        state,
        startUtcMs: candle.timestampUtcMs,
        endUtcMs: bar.closeUtcMs,
        bars: 0,
        startEquity: decimal(previousEquity),
        endEquity: bar.equity,
        netPnl: "0",
        returnFraction: null
      });
    }
    const run = runs[runs.length - 1];
    run.bars++;
    run.endUtcMs = bar.closeUtcMs;
    run.endEquity = bar.equity;
    run.netPnl = decimal(equity - runStartEquity);
    run.returnFraction = runStartEquity > 0n ? fraction(equity - runStartEquity, runStartEquity) : null;
    previousEquity = equity;
    previousPrice = price;
  }
  const expected = signedAmount(input.netPnl);
  if (previousEquity - initial !== expected || Object.values(groups).reduce((sum2, g) => sum2 + g.netPnl, 0n) !== expected)
    throw new Error("\u5E02\u573A\u72B6\u6001\u8D21\u732E\u4E4B\u548C\u4E0E\u539F\u5B9E\u9A8C\u603B\u51C0\u76C8\u4E8F\u4E0D\u5B88\u6052\u3002");
  const summaries = REGIMES.map((state) => {
    const g = groups[state];
    const durationMs = g.bars * intervalMs;
    return {
      state,
      bars: g.bars,
      durationMs,
      timeFraction: fraction(BigInt(g.bars), BigInt(bars.length)),
      occurrences: g.occurrences,
      netPnl: decimal(g.netPnl),
      realizedDelta: decimal(g.realizedDelta),
      unrealizedDelta: decimal(g.unrealizedDelta),
      fills: g.fills,
      fees: decimal(g.fees),
      exposedMs: g.exposedMs,
      exposureFraction: durationMs ? fraction(BigInt(g.exposedMs), BigInt(durationMs)) : null,
      periodReturns: distribution(g.periodReturns),
      assetReturns: distribution(g.assetReturns)
    };
  });
  return {
    labels,
    runs,
    summaries,
    switches: runs.length - 1,
    netPnl: decimal(expected)
  };
}

// src/core/risk-analysis/rng.ts
var RNG_VERSION = "pcg32-xsh-rr-stream54-rejection-v1";
var MASK64 = (1n << 64n) - 1n;
function pcg32(seed) {
  if (!Number.isSafeInteger(seed) || seed < 0 || seed > 4294967295)
    throw new Error("\u79CD\u5B50\u5FC5\u987B\u4E3A0\u20134294967295\u6574\u6570\u3002");
  let state = 0n;
  function next() {
    const old = state;
    state = old * 6364136223846793005n + 109n & MASK64;
    const x = Number((old >> 18n ^ old) >> 27n & 0xffffffffn);
    const rotation = Number(old >> 59n);
    return (x >>> rotation | x << (-rotation & 31)) >>> 0;
  }
  next();
  state = state + BigInt(seed) & MASK64;
  next();
  return {
    next,
    bounded(bound) {
      if (!Number.isSafeInteger(bound) || bound < 1 || bound > 5e4)
        throw new Error("\u62BD\u6837\u8303\u56F4\u5FC5\u987B\u4E3A1\u201350000\u6574\u6570\u3002");
      const threshold = 4294967296 % bound;
      let word;
      do {
        word = next();
      } while (word < threshold);
      return word % bound;
    }
  };
}

// src/core/advanced-research/plan.ts
var ADVANCED_LIMITS = Object.freeze({
  axes: 4,
  combinations: 1024,
  candidates: 64,
  folds: 20,
  runs: 200,
  bars: 1e6
});
function parameterTargets(rule) {
  const targets = [];
  for (const side of ["buy", "sell"]) {
    if (!rule[side].enabled) continue;
    for (const [condition2, entry] of rule[side].conditions.entries()) {
      if (!entry.enabled) continue;
      const add = (field3, value) => {
        targets.push({ side, condition: condition2, field: field3, value });
      };
      switch (entry.kind) {
        case "cross":
          add("fastPeriod", entry.fastPeriod);
          add("slowPeriod", entry.slowPeriod);
          break;
        case "rsi":
          add("period", entry.period);
          add("threshold", entry.threshold);
          break;
        case "price-ma":
          add("period", entry.period);
          break;
        case "breakout":
          add("lookback", entry.lookback);
          break;
      }
    }
  }
  return targets;
}
function signedUnits(value) {
  return value.startsWith("-") ? -readUnits(value.slice(1)) : readUnits(value);
}
var metrics = [
  "totalReturn",
  "maxDrawdown",
  "profitFactor",
  "completedTrades"
];
function validateSettings(settings) {
  requireFields(settings, [
    "ruleRecord",
    "config",
    "risk",
    "axes",
    "search",
    "filters",
    "sort",
    "evaluation",
    "regime"
  ]);
  verifyRuleRecord(settings.ruleRecord);
  requireFields(settings.config, [
    "initialCash",
    "buySlippageBps",
    "sellSlippageBps",
    "feeBps",
    "quantityDecimals",
    "minNotional"
  ]);
  if (normalizeConfig(settings.config).initialCash === "0")
    throw new Error("\u7814\u7A76\u7684\u521D\u59CB\u672C\u91D1\u987B\u4E3A\u6B63\u3002");
  normalizeRisk(settings.risk);
  assertRegimeParams(settings.regime);
  requireFields(settings.filters, [
    "minReturn",
    "maxDrawdown",
    "minProfitFactor",
    "minTrades"
  ]);
  const { minReturn, maxDrawdown, minProfitFactor, minTrades } = settings.filters;
  if (!Number.isSafeInteger(minTrades) || minTrades < 0 || minTrades > 5e4)
    throw new Error("\u6700\u5C11\u5B8C\u6210\u4EA4\u6613\u6B21\u6570\u987B\u4E3A 0\u201350,000 \u6574\u6570\u3002");
  for (const limit of [minReturn, maxDrawdown, minProfitFactor]) {
    if (limit !== null && (typeof limit !== "string" || !/^-?\d{1,96}(\.\d{1,18})?$/.test(limit)))
      throw new Error("\u7B5B\u9009\u9608\u503C\u987B\u4E3A\u6709\u754C\u5341\u8FDB\u5236\u5B57\u7B26\u4E32\uFF0C\u6216\u7559\u7A7A\u3002");
  }
  if (maxDrawdown !== null && (signedUnits(maxDrawdown) < 0n || signedUnits(maxDrawdown) > SCALE))
    throw new Error("\u6700\u5927\u56DE\u64A4\u6BD4\u4F8B\u987B\u5728 0 \u81F3 1 \u4E4B\u95F4\u3002");
  if (minProfitFactor !== null && signedUnits(minProfitFactor) < 0n)
    throw new Error("\u6700\u5C0F\u5229\u6DA6\u56E0\u5B50\u987B\u4E3A\u975E\u8D1F\u503C\u3002");
  if (!Array.isArray(settings.sort) || !settings.sort.length || settings.sort.length > metrics.length || new Set(settings.sort).size !== settings.sort.length || settings.sort.some((key) => !metrics.includes(key)))
    throw new Error("\u8BF7\u660E\u786E\u9009\u62E9\u4E0D\u91CD\u590D\u7684\u6392\u5E8F\u6307\u6807\u53CA\u4F18\u5148\u7EA7\u3002");
  if (settings.search?.kind === "grid")
    requireFields(settings.search, ["kind"]);
  else if (settings.search?.kind === "random") {
    requireFields(settings.search, ["kind", "seed", "count"]);
    if (!Number.isSafeInteger(settings.search.seed) || settings.search.seed < 0 || settings.search.seed > 4294967295)
      throw new Error("\u79CD\u5B50\u987B\u4E3A 0\u20134294967295 \u6574\u6570\u3002");
    if (!Number.isInteger(settings.search.count) || settings.search.count < 1 || settings.search.count > ADVANCED_LIMITS.candidates)
      throw new Error("\u968F\u673A\u62BD\u6837\u6570\u91CF\u987B\u4E3A 1\u201364 \u6574\u6570\u3002");
  } else throw new Error("\u4E0D\u652F\u6301\u7684\u641C\u7D22\u65B9\u5F0F\u3002");
  if (settings.evaluation?.kind !== "split" && settings.evaluation?.kind !== "rolling")
    throw new Error("\u8BF7\u4F7F\u7528\u6309\u65F6\u95F4\u62C6\u5206\u6216\u6EDA\u52A8\u8BAD\u7EC3/\u6D4B\u8BD5\u3002");
}
function axisValues(axis) {
  const threshold = axis.field === "threshold";
  if (![axis.min, axis.max, axis.step].every(
    (x) => typeof x === "number" && Number.isFinite(x) && (threshold || Number.isInteger(x))
  ) || axis.min < (threshold ? 0 : 1) || axis.max > (threshold ? 100 : 5e4) || axis.max < axis.min || axis.step <= 0)
    throw new Error(
      "\u53C2\u6570\u8303\u56F4\u6216\u6B65\u957F\u65E0\u6548\u3002\u5468\u671F\u987B\u4E3A\u6B63\u6574\u6570\uFF0CRSI \u9608\u503C\u987B\u5728 0\u2013100 \u5185\u3002"
    );
  const lo = parseDecimal(String(axis.min)), hi = parseDecimal(String(axis.max)), step = parseDecimal(String(axis.step));
  const count = (hi - lo) / step + 1n;
  if (count > BigInt(ADVANCED_LIMITS.combinations))
    throw new Error("\u53C2\u6570\u7F51\u683C\u8D85\u8FC7\u679A\u4E3E\u9884\u7B97\u3002");
  const values = /* @__PURE__ */ new Set();
  for (let units = lo; units <= hi; units += step)
    values.add(Number(decimal(units)));
  return [...values];
}
function warmupBars(rule) {
  return Math.max(
    ...[rule.buy, rule.sell].filter((group) => group.enabled).flatMap(
      (group) => group.conditions.filter((entry) => entry.enabled).map((entry) => {
        switch (entry.kind) {
          case "price-ma":
            return entry.period;
          case "rsi":
            return entry.period + 1;
          case "cross":
            return entry.slowPeriod + 1;
          case "breakout":
            return entry.lookback + 1;
        }
      })
    )
  );
}
function enumerate(settings) {
  const { axes, ruleRecord, search } = settings;
  if (!Array.isArray(axes) || axes.length > ADVANCED_LIMITS.axes)
    throw new Error("\u6BCF\u6B21\u6700\u591A\u641C\u7D22 4 \u4E2A\u53C2\u6570\u8F74\u3002");
  const available2 = parameterTargets(ruleRecord.rule);
  const targets = /* @__PURE__ */ new Set();
  const dimensions = axes.map((axis) => {
    requireFields(axis, ["side", "condition", "field", "min", "max", "step"]);
    if (!available2.some(
      (t) => t.side === axis.side && t.condition === axis.condition && t.field === axis.field
    ))
      throw new Error("\u641C\u7D22\u8F74\u987B\u5BF9\u5E94\u5DF2\u542F\u7528\u89C4\u5219\u7684\u6570\u503C\u53C2\u6570\u3002");
    const key = [axis.side, axis.condition, axis.field].join(".");
    if (targets.has(key)) throw new Error("\u540C\u4E00\u89C4\u5219\u53C2\u6570\u91CD\u590D\u6307\u5B9A\u8303\u56F4\u3002");
    targets.add(key);
    return axisValues(axis);
  });
  const combinations = dimensions.reduce((n, values) => n * values.length, 1);
  if (combinations > ADVANCED_LIMITS.combinations)
    throw new Error("\u7F51\u683C\u7EC4\u5408\u8D85\u8FC7 1,024 \u4E2A\u679A\u4E3E\u9884\u7B97\u3002");
  const candidates = [], invalid = [];
  for (let id = 0; id < combinations; id++) {
    let rank2 = id;
    const values = dimensions.map(() => 0);
    for (let i = dimensions.length - 1; i >= 0; i--) {
      values[i] = dimensions[i][rank2 % dimensions[i].length];
      rank2 = Math.floor(rank2 / dimensions[i].length);
    }
    const rule = normalizeRule(ruleRecord.rule);
    for (const [i, axis] of axes.entries())
      Object.assign(rule[axis.side].conditions[axis.condition], {
        [axis.field]: values[i]
      });
    try {
      const valid = normalizeRule(rule);
      candidates.push({
        id,
        values,
        rule: valid,
        warmupBars: warmupBars(valid)
      });
    } catch (error) {
      invalid.push({
        values,
        reason: error instanceof Error ? error.message : "\u89C4\u5219\u53C2\u6570\u7EC4\u5408\u65E0\u6548\u3002"
      });
    }
  }
  if (search.kind === "random") {
    if (search.count > candidates.length)
      throw new Error("\u968F\u673A\u62BD\u6837\u6570\u91CF\u8D85\u8FC7\u6709\u6548\u4E14\u4E92\u5F02\u7684\u53C2\u6570\u7EC4\u5408\u6570\u3002");
    const rng = pcg32(search.seed);
    for (let i = 0; i < search.count; i++) {
      const j = i + rng.bounded(candidates.length - i);
      [candidates[i], candidates[j]] = [candidates[j], candidates[i]];
    }
    candidates.length = search.count;
    candidates.sort((a, b) => a.id - b.id);
  }
  if (candidates.length > ADVANCED_LIMITS.candidates)
    throw new Error(
      "\u5B9E\u9645\u5019\u9009\u8D85\u8FC7 64 \u4E2A\uFF0C\u8BF7\u51CF\u5C0F\u8303\u56F4\u6216\u9009\u7528\u56FA\u5B9A\u79CD\u5B50\u7684\u6709\u754C\u968F\u673A\u62BD\u6837\u3002"
    );
  return { candidates, invalid, combinations };
}
function previewAdvanced(settings, bars) {
  validateSettings(settings);
  const windows = planWindows(bars, settings.evaluation);
  const search = enumerate(settings);
  const costs = windows.map(
    (w) => w.role === "train" ? search.candidates.length : Math.min(1, search.candidates.length)
  );
  const runs = costs.reduce((sum2, n) => sum2 + n, 0);
  const evaluations = windows.reduce(
    (sum2, w, i) => sum2 + costs[i] * (w.end - w.start),
    0
  );
  if (runs > ADVANCED_LIMITS.runs || evaluations > ADVANCED_LIMITS.bars)
    throw new Error(
      "\u7814\u7A76\u8D44\u6E90\u9884\u7B97\u8D85\u9650\uFF0C\u6BCF\u6279\u6700\u591A 200 \u6B21\u5B50\u8FD0\u884C\u30011,000,000 \u6839 K \u7EBF\u6C42\u503C\u3002"
    );
  return {
    ...search,
    windows,
    trailingBars: bars - windows.at(-1).end,
    runs,
    bars: evaluations
  };
}
function prepareAdvanced(input) {
  requireFields(input, [
    "dataset",
    "completedThroughUtcMs",
    "ruleRecord",
    "config",
    "risk",
    "axes",
    "search",
    "filters",
    "sort",
    "evaluation",
    "regime"
  ]);
  const { dataset, completedThroughUtcMs, ...settings } = input;
  assertDataset(dataset);
  validateSnapshotFields(dataset);
  if (dataset.quality.gapCount || dataset.quality.missingCandles)
    throw new Error("\u884C\u60C5\u5B58\u5728\u7F3A\u53E3\uFF0C\u4E0D\u80FD\u5F00\u59CB\u7814\u7A76\u3002");
  const end = dataset.candles.at(-1).timestampUtcMs + dataset.quality.intervalMs;
  if (!Number.isSafeInteger(completedThroughUtcMs) || completedThroughUtcMs < end || completedThroughUtcMs > 41024448e5)
    throw new Error("\u884C\u60C5\u6536\u76D8\u65F6\u95F4\u672A\u786E\u8BA4\u3002");
  for (const c of dataset.candles) {
    for (const price of [c.open, c.high, c.low, c.close])
      if (parseDecimal(String(price)) <= 0n)
        throw new Error("\u884C\u60C5\u4EF7\u683C\u8D85\u51FA\u7CBE\u5EA6\u8303\u56F4\u3002");
  }
  return previewAdvanced(settings, dataset.candles.length);
}

// src/core/advanced-research/index.ts
var ADVANCED_VERSION = "rule-search-walk-forward-v1";
var ADVANCED_VERSIONS = Object.freeze({
  optimization: ADVANCED_VERSION,
  random: RNG_VERSION,
  engine: ALGORITHM_VERSION,
  conversion: CONVERSION_VERSION,
  strategy: RULE_STRATEGY_VERSION,
  statistics: STATISTICS_VERSION,
  regime: REGIME_MODEL_VERSION,
  attribution: REGIME_ATTRIBUTION_VERSION
});
function trainingRejections(metrics2, filters) {
  const reasons = [];
  const constraints = [
    ["\u6536\u76CA\u7387", metrics2.totalReturn, filters.minReturn, "min"],
    ["\u6700\u5927\u56DE\u64A4", metrics2.maxDrawdown, filters.maxDrawdown, "max"],
    ["\u5229\u6DA6\u56E0\u5B50", metrics2.profitFactor, filters.minProfitFactor, "min"]
  ];
  for (const [label, value, threshold, direction] of constraints) {
    if (threshold === null) continue;
    if (value === null) reasons.push(label + "\u4E3A NA\uFF0C\u672A\u901A\u8FC7\u7B5B\u9009\u3002");
    else {
      const actual = signedUnits(value), limit = signedUnits(threshold);
      if (direction === "min" ? actual < limit : actual > limit)
        reasons.push(label + "\u672A\u6EE1\u8DB3\u8BAD\u7EC3\u7B5B\u9009\u9608\u503C " + threshold + "\u3002");
    }
  }
  if (metrics2.completedTrades < filters.minTrades)
    reasons.push("\u5B8C\u6210\u4EA4\u6613\u6B21\u6570\u5C11\u4E8E " + filters.minTrades + "\u3002");
  return reasons;
}
function evaluateCandidate(input, candidate2, window2) {
  const dataset = windowDataset(input.dataset, window2);
  const endUtcMs = dataset.candles.at(-1).timestampUtcMs + dataset.quality.intervalMs;
  const identity = {
    candidateId: candidate2.id,
    window: window2,
    startUtcMs: dataset.candles[0].timestampUtcMs,
    endUtcMs
  };
  try {
    const result = runBacktest({
      dataset,
      completedThroughUtcMs: endUtcMs,
      config: input.config,
      risk: input.risk,
      strategy: { kind: "rules", rule: candidate2.rule }
    });
    const statistics = calculateStatistics(
      result,
      String(dataset.candles[0].open)
    );
    const metrics2 = {
      totalReturn: statistics.totalReturn.value,
      maxDrawdown: statistics.maxDrawdown.value,
      profitFactor: statistics.profitFactor.value,
      completedTrades: statistics.completedTrades.length,
      netPnl: statistics.netPnl,
      finalEquity: result.final.equity
    };
    const regimes = analyzeRegimes(
      {
        candles: dataset.candles,
        intervalMs: result.manifest.intervalMs,
        completedThroughUtcMs: endUtcMs,
        initialCash: result.manifest.config.initialCash,
        netPnl: statistics.netPnl,
        bars: singleBars(result, statistics)
      },
      input.regime
    ).summaries;
    return {
      ...identity,
      metrics: metrics2,
      regimes,
      runHash: result.manifest.runHash,
      reasons: window2.role === "train" ? trainingRejections(metrics2, input.filters) : []
    };
  } catch (error) {
    return {
      ...identity,
      metrics: null,
      regimes: null,
      runHash: null,
      reasons: [error instanceof Error ? error.message : "\u5019\u9009\u8FD0\u884C\u5931\u8D25\u3002"]
    };
  }
}
function rankTraining(input, train) {
  const reference = train[0]?.window;
  if (train.some(
    (row) => row.window.role !== "train" || row.window.fold !== reference.fold || row.window.start !== reference.start || row.window.end !== reference.end
  ) || new Set(train.map((row) => row.candidateId)).size !== train.length)
    throw new Error("\u8BAD\u7EC3\u9009\u4F18\u53EA\u5141\u8BB8\u540C\u4E00\u8BAD\u7EC3\u7A97\u53E3\u7684\u4E92\u5F02\u5019\u9009\u3002");
  return [...train].sort((a, b) => {
    const status = (row) => row.metrics === null ? 2 : row.reasons.length ? 1 : 0;
    const statusDifference = status(a) - status(b);
    if (statusDifference) return statusDifference;
    if (a.metrics && b.metrics) {
      for (const key of input.sort) {
        const av = a.metrics[key], bv = b.metrics[key];
        if (av === bv) continue;
        if (av === null) return 1;
        if (bv === null) return -1;
        const left = signedUnits(String(av)), right = signedUnits(String(bv));
        if (left !== right)
          return (left < right ? -1 : 1) * (key === "maxDrawdown" ? 1 : -1);
      }
    }
    return a.candidateId - b.candidateId;
  });
}
function selectTraining(sorted) {
  if (sorted.some((row) => row.window.role !== "train"))
    throw new Error("\u6D4B\u8BD5\u7ED3\u679C\u4E0D\u80FD\u7528\u4E8E\u9009\u62E9\u53C2\u6570\u3002");
  return sorted.find((row) => row.metrics !== null && !row.reasons.length)?.candidateId ?? null;
}
function runAdvanced(input) {
  const plan = prepareAdvanced(input);
  const folds = [];
  for (let i = 0; i < plan.windows.length; i += 2) {
    const train = rankTraining(
      input,
      plan.candidates.map(
        (candidate3) => evaluateCandidate(input, candidate3, plan.windows[i])
      )
    );
    const selectedId = selectTraining(train);
    const candidate2 = plan.candidates.find((c) => c.id === selectedId);
    const test = candidate2 ? evaluateCandidate(input, candidate2, plan.windows[i + 1]) : null;
    folds.push({ train, selectedId, test });
  }
  return { plan, folds };
}

// src/core/advanced-research/report.ts
var FORMAT = "riverlab-advanced-research";
var MAX_ADVANCED_REPORT_BYTES = MAX_PORTFOLIO_REPORT_BYTES;
function checkObserved(input, observedUtcMs) {
  if (!Number.isSafeInteger(observedUtcMs) || !Number.isSafeInteger(input?.completedThroughUtcMs) || input.completedThroughUtcMs > observedUtcMs)
    throw new Error("\u9AD8\u7EA7\u7814\u7A76\u7684\u6536\u76D8\u786E\u8BA4\u65F6\u95F4\u65E0\u6548\u6216\u665A\u4E8E\u5F53\u524D\u65F6\u95F4\u3002");
}
function reportDigest(body) {
  assertPortfolioMemoryBudget(body);
  const hash3 = sha256.create();
  let bytes = ',"reportHash":""'.length + 64;
  forEachCanonicalChunk(body, (chunk) => {
    bytes += chunk.length;
    if (bytes > MAX_ADVANCED_REPORT_BYTES)
      throw new Error("\u9AD8\u7EA7\u7814\u7A76\u62A5\u544A\u8D85\u8FC7 32 MiB\u3002");
    hash3.update(chunk);
  });
  return Array.from(hash3.digest(), (b) => b.toString(16).padStart(2, "0")).join(
    ""
  );
}
function sealAdvancedReport(input, result, metadata2) {
  assertMetadata(metadata2);
  const body = {
    format: FORMAT,
    schemaVersion: 1,
    algorithmVersion: ADVANCED_VERSION,
    versions: ADVANCED_VERSIONS,
    disclaimer: DISCLAIMER,
    id: metadata2.id,
    name: metadata2.name,
    createdUtcMs: metadata2.createdUtcMs,
    input,
    result
  };
  return { ...body, reportHash: reportDigest(body) };
}
function verifyAdvancedReport(value, observedUtcMs) {
  const report = value;
  if (report?.format !== FORMAT || report.schemaVersion !== 1 || report.algorithmVersion !== ADVANCED_VERSION)
    throw new Error("\u9AD8\u7EA7\u7814\u7A76\u62A5\u544A\u683C\u5F0F\u6216\u7248\u672C\u4E0D\u652F\u6301\u3002");
  assertMetadata(report);
  checkObserved(report.input, observedUtcMs);
  const { reportHash, ...body } = report;
  if (typeof reportHash !== "string" || !digestPattern.test(reportHash) || reportDigest(body) !== reportHash)
    throw new Error("\u9AD8\u7EA7\u7814\u7A76\u62A5\u544A Hash \u4E0D\u7B26\u3002");
  assertDataset(report.input.dataset);
  validateSnapshotFields(report.input.dataset);
  const rebuilt = sealAdvancedReport(
    report.input,
    runAdvanced(report.input),
    report
  );
  if (rebuilt.reportHash !== reportHash)
    throw new Error("\u9AD8\u7EA7\u7814\u7A76\u62A5\u544A\u4E0E\u5B8C\u6574\u91CD\u7B97\u7ED3\u679C\u4E0D\u7B26\u3002");
  return rebuilt;
}

// src/core/portfolio/correlation.ts
var RETURN_SCALE2 = 10n ** 96n;
var COEFFICIENT_SCALE = 10n ** 12n;
function moments(closes) {
  let previous = readUnits(closes[0].account.markPrice);
  let sum2 = 0n;
  let sumSquares = 0n;
  const returns = [];
  for (let i = 1; i < closes.length; i++) {
    const current = readUnits(closes[i].account.markPrice);
    const value = (current - previous) * RETURN_SCALE2 / previous;
    returns.push(value);
    sum2 += value;
    sumSquares += value * value;
    previous = current;
  }
  return {
    returns,
    sum: sum2,
    variance: BigInt(returns.length) * sumSquares - sum2 * sum2
  };
}
function marketCorrelations(closes) {
  const data = closes.map(moments);
  const sampleCount = data[0].returns.length;
  const matrix = data.map(() => []);
  for (let i = 0; i < data.length; i++) {
    for (let j = i; j < data.length; j++) {
      const left = data[i], right = data[j];
      let metric;
      if (sampleCount < 2) {
        metric = {
          value: null,
          reason: "\u81F3\u5C11\u9700\u8981\u4E24\u9879\u5BF9\u9F50\u7684\u6536\u76D8\u6536\u76CA\uFF08\u4E09\u6839K\u7EBF\uFF09"
        };
      } else if (left.variance === 0n || right.variance === 0n) {
        metric = { value: null, reason: "\u5BF9\u9F50\u6536\u76CA\u5E8F\u5217\u5B58\u5728\u96F6\u65B9\u5DEE" };
      } else {
        let products = 0n;
        for (let k = 0; k < sampleCount; k++)
          products += left.returns[k] * right.returns[k];
        const covariance = BigInt(sampleCount) * products - left.sum * right.sum;
        const scaled = covariance * COEFFICIENT_SCALE;
        const magnitude = integerSqrt(
          scaled * scaled / (left.variance * right.variance)
        );
        metric = {
          value: fraction(
            covariance < 0n ? -magnitude : magnitude,
            COEFFICIENT_SCALE
          ),
          reason: null
        };
      }
      matrix[i][j] = metric;
      matrix[j][i] = metric;
    }
  }
  return matrix;
}

// src/core/portfolio/index.ts
var PORTFOLIO_VERSION = "independent-spot-portfolio-v1";
var PORTFOLIO_ASSUMPTIONS = Object.freeze([
  "\u5404\u5B50\u8D26\u6237\u4EE5\u76F8\u540C\u62A5\u4EF7\u8D27\u5E01\u72EC\u7ACB\u8BB0\u8D26\uFF0C\u4E00\u5355\u4F4D\u5F15\u64CE\u62A5\u4EF7\u5355\u4F4D\u7B49\u4E8E\u4E00\u5355\u4F4D\u7EC4\u5408\u62A5\u4EF7\u8D27\u5E01\uFF0C\u65E0\u6C47\u5151\u3002",
  "\u9996\u6839\u5F00\u76D8\u524D\u6309\u6743\u91CD\u5206\u914D\u73B0\u91D1\uFF0C\u5411\u4E0B\u53D6\u6574\u81F318\u4F4D\uFF0C\u518D\u6309\u4F59\u6570\u964D\u5E8F\u9010\u4E2A\u5206\u914D\u6700\u5C0F\u5355\u4F4D\u3002\u4F59\u6570\u76F8\u540C\u65F6\u6309\u89C4\u8303\u4EA4\u6613\u5BF9ASCII\u5347\u5E8F\u5206\u914D\u3002\u4EFB\u4E00\u5B50\u8D26\u6237\u5B9E\u9645\u5206\u5F97\u96F6\u5219\u62D2\u7EDD\u8FD0\u884C\u3002",
  "\u5404\u5B50\u8D26\u6237\u521D\u59CB\u7A7A\u4ED3\uFF0C\u7B56\u7565\u4ECE\u786E\u8BA4\u533A\u95F4\u9996\u6839\u72EC\u7ACB\u51B7\u542F\u52A8\uFF0C\u671F\u95F4\u65E0\u8C03\u4ED3\u6216\u8D26\u6237\u95F4\u8F6C\u79FB\u3002",
  "\u7EC4\u5408\u6536\u76D8\u6743\u76CA\u7B49\u4E8E\u5B50\u8D26\u6237\u6536\u76D8\u6743\u76CA\u4E4B\u548C\u3002\u5B9E\u9645\u5B50\u8D26\u6237\u6743\u91CD\u542B\u5176\u73B0\u91D1\uFF0C\u6301\u4ED3\u6743\u91CD\u53EA\u8BA1\u5176\u6301\u4ED3\u5E02\u503C\uFF0C\u4E24\u8005\u5747\u4EE5\u7EC4\u5408\u6743\u76CA\u4E3A\u5206\u6BCD\u3002",
  "\u5404\u5B50\u8D26\u6237\u7684\u6536\u76CA\u8D21\u732E\u4E3A\u5176\u51C0\u76C8\u4E8F\u9664\u4EE5\u7EC4\u5408\u521D\u59CB\u672C\u91D1\uFF0C\u8D39\u7528\u5360\u6BD4\u4E3A\u5176\u624B\u7EED\u8D39\u9664\u4EE5\u7EC4\u5408\u624B\u7EED\u8D39\u3002\u6BD4\u7387\u5411\u96F6\u622A\u65AD12\u4F4D\u3002",
  "\u6700\u5927\u56DE\u64A4\u53D6\u542B\u521D\u59CB\u672C\u91D1\u951A\u70B9\u7684\u7EC4\u5408\u6536\u76D8\u6743\u76CA\u76F8\u5BF9\u5386\u53F2\u6700\u9AD8\u70B9\u7684\u6700\u5927\u8DCC\u5E45\u3002",
  "\u4E70\u5165\u6301\u6709\u57FA\u51C6\u91C7\u7528\u76F8\u540C\u672C\u91D1\u5206\u914D\u3002\u5404\u5B50\u8D26\u6237\u6309\u5404\u81EA\u624B\u7EED\u8D39\u3001\u4E70\u6ED1\u70B9\u3001\u6570\u91CF\u7CBE\u5EA6\u548C\u6700\u5C0F\u540D\u4E49\u989D\u5728\u9996\u6839\u5F00\u76D8\u4E70\u5165\u3002\u672B\u6536\u76D8\u4F30\u503C\uFF0C\u65E0\u671F\u672B\u5356\u51FA\u8D39\u7528\u3002\u4EFB\u4E00\u5B50\u8D26\u6237\u57FA\u51C6\u62D2\u5355\u5219\u7EC4\u5408\u57FA\u51C6\u4E3ANA\u3002",
  "\u8D44\u4EA7\u76F8\u5173\u6027\u4E3A\u540C\u4E00UTC\u65F6\u95F4\u8F74\u4E0A\u76F8\u90BB\u6807\u7684\u6536\u76D8\u4EF7\u7B80\u5355\u6536\u76CA\u7684Pearson\u7CFB\u6570\u3002\u81F3\u5C11\u9700\u8981\u4E24\u9879\u6536\u76CA\uFF0C\u96F6\u65B9\u5DEE\u4E3ANA\u3002\u6536\u76CA\u5411\u96F6\u622A\u65AD\u81F396\u4F4D\u5C0F\u6570\uFF0C\u7CFB\u6570\u5411\u96F6\u622A\u65AD\u81F312\u4F4D\u3002"
]);
var ratio = (num, den, zeroReason = "\u7EC4\u5408\u6743\u76CA\u4E3A\u96F6\uFF0C\u6743\u91CD\u65E0\u5B9A\u4E49") => den > 0n ? { value: fraction(num, den), reason: null } : { value: null, reason: zeroReason };
function checkedAmount(units) {
  if (units < 0n || units >= ACCOUNTING_LIMIT)
    throw new Error("\u7EC4\u5408\u8D26\u672C\u503C\u5FC5\u987B\u975E\u8D1F\u4E14\u5C0F\u4E8E10^78\u3002");
  return decimal(units);
}
function runPortfolio(input) {
  const { alignment, assets: prepared } = preparePortfolio(input);
  const initial = parseDecimal(input.initialCash);
  const children = prepared.map((asset) => {
    const result = runBacktest({
      dataset: asset.dataset,
      config: asset.config,
      strategy: asset.strategy,
      risk: asset.risk,
      completedThroughUtcMs: input.completedThroughUtcMs
    });
    const statistics = calculateStatistics(
      result,
      String(asset.dataset.candles[0].open)
    );
    return {
      symbol: asset.symbol,
      weightPercent: asset.weightPercent,
      initialCash: asset.initialCash,
      result,
      statistics,
      netPnl: statistics.netPnl,
      fees: statistics.fees
    };
  });
  if (children.reduce((sum2, child) => sum2 + readUnits(child.initialCash), 0n) !== initial)
    throw new Error("\u5B50\u8D26\u6237\u521D\u59CB\u8D44\u91D1\u603B\u548C\u4E0D\u7B49\u4E8E\u7EC4\u5408\u672C\u91D1\u3002");
  const rejectedBenchmarks = children.flatMap(
    ({ symbol, statistics }) => statistics.benchmark.finalEquity.reason ? [symbol + " " + statistics.benchmark.finalEquity.reason] : []
  );
  const benchmarkReason = rejectedBenchmarks.length ? rejectedBenchmarks.join("\uFF1B") : null;
  let peak = initial;
  let worstDrop = 0n;
  let worstPeak = initial;
  let equity = initial;
  let benchmark = initial;
  const curve = [
    {
      timestampUtcMs: alignment.startUtcMs,
      cash: decimal(initial),
      marketValue: "0",
      equity: decimal(initial),
      benchmarkEquity: benchmarkReason ? null : decimal(initial)
    }
  ];
  for (let i = 0; i < alignment.barCount; i++) {
    const timestampUtcMs = alignment.startUtcMs + (i + 1) * alignment.intervalMs;
    let cash = 0n, market = 0n;
    equity = 0n;
    benchmark = 0n;
    for (const child of children) {
      const close = child.result.closes[i];
      if (close.timestampUtcMs !== timestampUtcMs)
        throw new Error("\u5B50\u8D26\u6237\u6536\u76D8\u65F6\u95F4\u4E0E\u7EC4\u5408UTC\u65F6\u95F4\u8F74\u4E0D\u4E00\u81F4\u3002");
      cash += readUnits(close.account.cash);
      market += readUnits(close.account.marketValue);
      equity += readUnits(close.account.equity);
      if (!benchmarkReason)
        benchmark += readUnits(child.statistics.curve[i + 1].benchmarkEquity);
    }
    if (cash + market !== equity)
      throw new Error("\u7EC4\u5408\u73B0\u91D1\u52A0\u6301\u4ED3\u5E02\u503C\u4E0E\u5B50\u8D26\u6237\u6743\u76CA\u548C\u4E0D\u4E00\u81F4\u3002");
    if (equity > peak) peak = equity;
    const drop = peak - equity;
    if (drop * worstPeak > worstDrop * peak) {
      worstDrop = drop;
      worstPeak = peak;
    }
    curve.push({
      timestampUtcMs,
      cash: checkedAmount(cash),
      marketValue: checkedAmount(market),
      equity: checkedAmount(equity),
      benchmarkEquity: benchmarkReason ? null : checkedAmount(benchmark)
    });
  }
  const fees = children.reduce((sum2, child) => sum2 + readUnits(child.fees), 0n);
  return {
    version: PORTFOLIO_VERSION,
    assumptions: PORTFOLIO_ASSUMPTIONS,
    alignment,
    quoteCurrency: alignment.quoteCurrency,
    initialCash: decimal(initial),
    assets: children.map((child) => ({
      ...child,
      equityWeight: ratio(readUnits(child.result.final.equity), equity),
      holdingWeight: ratio(readUnits(child.result.final.marketValue), equity),
      returnContribution: ratio(
        readUnits(child.result.final.equity) - readUnits(child.initialCash),
        initial
      ),
      feeShare: ratio(
        readUnits(child.fees),
        fees,
        "\u7EC4\u5408\u624B\u7EED\u8D39\u4E3A\u96F6\uFF0C\u8D39\u7528\u5360\u6BD4\u65E0\u5B9A\u4E49"
      )
    })),
    curve,
    totalReturn: ratio(equity - initial, initial),
    maxDrawdown: ratio(worstDrop, worstPeak),
    netPnl: decimal(equity - initial),
    fees: checkedAmount(fees),
    fillCount: children.reduce(
      (sum2, child) => sum2 + child.result.fills.length,
      0
    ),
    benchmarkReturn: benchmarkReason ? { value: null, reason: benchmarkReason } : ratio(benchmark - initial, initial),
    benchmarkReason,
    correlations: marketCorrelations(children.map((c) => c.result.closes)),
    correlationSamples: alignment.barCount - 1
  };
}

// src/core/portfolio/report.ts
var FORMAT2 = "riverlab-portfolio-experiment";
var VERSION = 1;
function header({ id, name, createdUtcMs }, payloadHash) {
  return {
    format: FORMAT2,
    schemaVersion: VERSION,
    id,
    name,
    createdUtcMs,
    payloadHash
  };
}
function digestPayload(input, result, metadata2) {
  const zero = "0".repeat(64);
  return digestPortfolioPayload(input, result, {
    ...header(metadata2, zero),
    recordHash: zero
  });
}
function createPortfolioExperiment(input, metadata2, observedUtcMs) {
  assertMetadata(metadata2);
  assertPortfolioMemoryBudget(input, true);
  checkSource(input, observedUtcMs);
  const snapshot2 = {
    ...input,
    assets: input.assets.map((asset) => {
      const { candles, ...datasetMetadata } = asset.dataset;
      return {
        ...asset,
        dataset: { ...JSON.parse(JSON.stringify(datasetMetadata)), candles }
      };
    })
  };
  const result = runPortfolio(snapshot2);
  const body = header(metadata2, digestPayload(snapshot2, result, metadata2));
  return { ...body, recordHash: contentHash(body), input: snapshot2, result };
}
function verifyPortfolioExperiment(value, observedUtcMs, observeReplay) {
  const record = value;
  if (!record || record.format !== FORMAT2 || record.schemaVersion !== VERSION)
    throw new Error("\u7EC4\u5408\u5B9E\u9A8C\u683C\u5F0F\u6216\u7248\u672C\u4E0D\u652F\u6301\u3002");
  const keys = [
    "format",
    "schemaVersion",
    "id",
    "name",
    "createdUtcMs",
    "payloadHash",
    "recordHash",
    "input",
    "result"
  ];
  if (Object.keys(record).length !== keys.length || keys.some((k) => !Object.hasOwn(record, k)))
    throw new Error("\u7EC4\u5408\u5B9E\u9A8C\u7F3A\u5C11\u5B57\u6BB5\u6216\u542B\u672A\u77E5\u5B57\u6BB5\u3002");
  assertMetadata(record);
  if (record.result?.version !== PORTFOLIO_VERSION)
    throw new Error("\u7EC4\u5408\u7B97\u6CD5\u7248\u672C\u4E0D\u652F\u6301\u3002");
  if (!Array.isArray(record.result.assets) || record.result.assets.length < 2 || record.result.assets.length > 5)
    throw new Error("\u7EC4\u5408\u5B9E\u9A8C\u5B50\u8D26\u6237\u6570\u91CF\u65E0\u6548\u3002");
  for (const asset of record.result.assets) {
    const manifest = asset?.result?.manifest;
    const strategy = manifest?.strategy;
    if (manifest?.algorithmVersion !== ALGORITHM_VERSION || manifest.conversionVersion !== CONVERSION_VERSION || asset.statistics?.version !== STATISTICS_VERSION || !strategy || strategy.version !== (strategy.config?.kind === "rules" ? RULE_STRATEGY_VERSION : STRATEGY_VERSION))
      throw new Error("\u7EC4\u5408\u5B50\u8D26\u6237\u5F15\u64CE\u3001\u7B56\u7565\u6216\u7EDF\u8BA1\u7248\u672C\u4E0D\u652F\u6301\u3002");
  }
  checkSource(record.input, observedUtcMs);
  if (!digestPattern.test(record.payloadHash) || !digestPattern.test(record.recordHash) || contentHash(header(record, record.payloadHash)) !== record.recordHash || digestPayload(record.input, record.result, record) !== record.payloadHash)
    throw new Error("\u7EC4\u5408\u5B9E\u9A8C Hash \u6821\u9A8C\u4E0D\u4E00\u81F4\u3002");
  const replay = runPortfolio(record.input);
  const payloadHash = digestPayload(record.input, replay, record);
  if (payloadHash !== record.payloadHash)
    throw new Error("\u7EC4\u5408\u5B9E\u9A8C\u91CD\u7B97\u4E0D\u4E00\u81F4\uFF0C\u65E0\u6CD5\u6253\u5F00\u3002");
  observeReplay?.({
    ...record,
    result: replay,
    payloadHash,
    recordHash: contentHash(header(record, payloadHash))
  });
  return record;
}

// src/core/shared-pool/ledger.ts
function checked(n) {
  if (n < 0n || n >= ACCOUNTING_LIMIT)
    throw new Error("\u5171\u4EAB\u8D26\u672C\u8D85\u51FA\u975E\u8D1F\u4E14\u5C0F\u4E8E 10^78 \u7684\u8303\u56F4\u3002");
  return n;
}
var mark = (qty, price) => checked(qty * price / SCALE);
var PoolLedger = class {
  constructor(initial, assets) {
    this.initial = initial;
    this.assets = assets;
    this.cash = initial;
  }
  initial;
  assets;
  cash;
  fees = 0n;
  fillCount = 0;
  orders = [];
  // At most one order per bar, symbol and execution phase.
  seen = /* @__PURE__ */ new Set();
  execute(asset, order) {
    const { barIndex, barOpenUtcMs, phase, side, reason, reference, trigger } = order;
    const id = [barIndex, asset.symbol, phase].join("/");
    if (this.seen.has(id)) throw new Error("\u68C0\u6D4B\u5230\u91CD\u590D\u8BA2\u5355\u3002");
    this.seen.add(id);
    const cashBefore = this.cash;
    const quantityBefore = asset.quantity;
    const buy = side === "buy";
    let execution = order.rejection ? { rejected: order.rejection } : executeAtReference(
      { cash: order.approved ?? cashBefore, quantity: quantityBefore },
      reference,
      { side, quantity: order.quantity },
      asset.config
    );
    let protection = null;
    if (buy && !("rejected" in execution) && (asset.risk.stopLossBps || asset.risk.takeProfitBps)) {
      protection = entryProtection(execution.price, asset.risk);
      if (!protection) execution = { rejected: "stop-price-underflow" };
    }
    const fill = "rejected" in execution ? null : execution;
    const spent = buy && fill ? fill.notional + fill.fee : 0n;
    if (fill) {
      const expectedPrice = buy ? ceilDiv(reference * (BPS + BigInt(asset.config.buySlippageBps)), BPS) : reference * (BPS - BigInt(asset.config.sellSlippageBps)) / BPS;
      const step = 10n ** BigInt(18 - asset.config.quantityDecimals);
      const expectedFee = ceilDiv(
        fill.notional * BigInt(asset.config.feeBps),
        BPS
      );
      const expectedNotional = buy ? ceilDiv(fill.price * fill.quantity, SCALE) : fill.price * fill.quantity / SCALE;
      if (fill.price !== expectedPrice || fill.quantity % step !== 0n || fill.fee !== expectedFee || fill.notional !== expectedNotional || fill.quantity <= 0n || buy && (order.approved === void 0 || spent > order.approved || spent > cashBefore))
        throw new Error("\u6210\u4EA4\u8D39\u7528\u3001\u6570\u91CF\u3001\u540D\u4E49\u989D\u6216\u6279\u51C6\u9884\u7B97\u672A\u80FD\u5BF9\u8D26\u3002");
      if (buy) {
        this.cash -= spent;
        asset.quantity += fill.quantity;
        asset.purchased += fill.quantity;
        asset.buySpend += spent;
        if (protection) asset.protection = protection;
      } else {
        const proceeds = fill.notional - fill.fee;
        this.cash += proceeds;
        asset.quantity -= fill.quantity;
        asset.sold += fill.quantity;
        asset.sellProceeds += proceeds;
      }
      this.fees += fill.fee;
      asset.fees += fill.fee;
      this.fillCount++;
      checked(this.cash);
      checked(asset.quantity);
      const cashAudit = this.assets.reduce(
        (sum2, a) => sum2 + a.sellProceeds - a.buySpend,
        this.initial
      );
      const feeAudit = this.assets.reduce((sum2, a) => sum2 + a.fees, 0n);
      if (asset.quantity !== asset.purchased - asset.sold || this.cash !== cashAudit || this.fees !== feeAudit)
        throw new Error("\u5171\u4EAB\u73B0\u91D1\u3001\u6301\u4ED3\u6216\u8D39\u7528\u4E0D\u5B88\u6052\u3002");
    }
    this.orders.push({
      sequence: this.orders.length + 1,
      barIndex,
      barOpenUtcMs,
      symbol: asset.symbol,
      phase,
      side,
      reason,
      status: fill ? "filled" : "rejected",
      rejection: "rejected" in execution ? execution.rejected : null,
      ...trigger ? { trigger } : {},
      referencePrice: decimal(reference),
      requestedBudget: order.requested === void 0 ? null : decimal(order.requested),
      approvedBudget: order.approved === void 0 ? null : decimal(order.approved),
      unusedBudget: order.approved === void 0 ? null : decimal(order.approved - spent),
      price: fill ? decimal(fill.price) : null,
      quantity: decimal(fill?.quantity ?? 0n),
      notional: decimal(fill?.notional ?? 0n),
      fee: decimal(fill?.fee ?? 0n),
      cashBefore: decimal(cashBefore),
      cashAfter: decimal(this.cash),
      quantityBefore: decimal(quantityBefore),
      quantityAfter: decimal(asset.quantity)
    });
    return fill;
  }
};

// src/core/shared-pool/prepare.ts
var HUNDRED = 100n * SCALE;
function prepareSharedPool(input) {
  const common = [
    "mode",
    "assets",
    "initialCash",
    "quoteCurrency",
    "startUtcMs",
    "endUtcMs",
    "rangeConfirmed",
    "completedThroughUtcMs"
  ];
  if (input?.mode === "rebalance") {
    requireFields(input, [...common, "cashWeightPercent", "rebalanceEvery"]);
    if (!Number.isSafeInteger(input.rebalanceEvery) || input.rebalanceEvery <= 0)
      throw new Error("\u518D\u5E73\u8861\u5468\u671F\u5FC5\u987B\u4E3A\u6B63\u6574\u6570\u3002");
  } else {
    if (input?.mode !== "shared-strategy")
      throw new Error("\u5171\u4EAB\u7EC4\u5408\u6A21\u5F0F\u4E0D\u652F\u6301\u3002");
    requireFields(input, common);
  }
  const initial = parseDecimal(input.initialCash);
  if (!initial) throw new Error("\u7EC4\u5408\u672C\u91D1\u5FC5\u987B\u5927\u4E8E\u96F6\u3002");
  const alignment = alignPortfolioSources(input);
  const assets = input.assets.map((asset, i) => {
    const cover = alignment.assets[i];
    if (cover.sourceEndUtcMs + alignment.intervalMs > input.completedThroughUtcMs)
      throw new Error(cover.symbol + " \u539F\u59CB\u5FEB\u7167\u542B\u672A\u5B8C\u6210\u6536\u76D8\u7684 K \u7EBF\u3002");
    const strategyAsset = input.mode === "shared-strategy" ? input.assets[i] : null;
    const fields2 = ["dataset", "weightPercent", "costs"];
    requireFields(
      asset,
      strategyAsset ? [...fields2, "strategy", "risk"] : fields2,
      strategyAsset ? ["ruleRecord"] : []
    );
    const strategy = strategyAsset ? createStrategy(
      assetStrategy(strategyAsset, cover.symbol),
      alignment.intervalMs
    ) : null;
    const bars = asset.dataset.candles.slice(
      cover.beforeCount,
      asset.dataset.candles.length - cover.afterCount
    );
    for (const bar of bars) {
      for (const price of [bar.open, bar.high, bar.low, bar.close])
        if (parseDecimal(String(price)) === 0n)
          throw new Error("K \u7EBF\u4EF7\u683C\u8FC7\u5C0F\u3002");
    }
    return {
      symbol: cover.symbol,
      bars,
      strategy,
      risk: strategyAsset ? normalizeRisk(strategyAsset.risk) : {},
      weight: parseDecimal(asset.weightPercent),
      config: executionConfig(asset.costs, input.initialCash),
      quantity: 0n,
      purchased: 0n,
      sold: 0n,
      buySpend: 0n,
      sellProceeds: 0n,
      fees: 0n
    };
  });
  const bySymbol = (a, b) => a.symbol < b.symbol ? -1 : a.symbol > b.symbol ? 1 : 0;
  assets.sort(bySymbol);
  alignment.assets.sort(bySymbol);
  const assetWeight = assets.reduce((sum2, asset) => sum2 + asset.weight, 0n);
  const cashWeight = input.mode === "rebalance" ? parseDecimal(input.cashWeightPercent) : HUNDRED - assetWeight;
  if (cashWeight < 0n || assetWeight + cashWeight !== HUNDRED)
    throw new Error(
      "\u8D44\u4EA7\u4E0E\u73B0\u91D1\u76EE\u6807\u6743\u91CD\u5FC5\u987B\u5408\u8BA1 100%\uFF0C\u7B56\u7565\u9884\u7B97\u603B\u548C\u4E0D\u5F97\u8D85\u8FC7 100%\u3002"
    );
  return { assets, alignment, initial, cashWeight };
}

// src/core/shared-pool/trading.ts
var sum = (amounts) => amounts.reduce((total, amount) => total + amount, 0n);
var positive = (n) => n > 0n ? n : 0n;
function valuesAt(assets, prices) {
  return assets.map((asset, i) => mark(asset.quantity, prices[i]));
}
function weightVector(values, cash) {
  const equity = checked(cash + sum(values));
  return [...values, cash].map(
    (value) => equity ? decimal(value * HUNDRED / equity) : null
  );
}
function approveBudgets(requests, capacity) {
  const total = sum(requests);
  if (total <= capacity) return [...requests];
  const approvals = requests.map((amount) => amount * capacity / total);
  let dust = capacity - sum(approvals);
  for (let i = 0; dust && i < requests.length; i++) {
    if (approvals[i] < requests[i]) {
      approvals[i]++;
      dust--;
    }
  }
  if (dust) throw new Error("\u8D44\u91D1\u9884\u7B97\u5C3E\u5DEE\u4E0D\u5B88\u6052\u3002");
  return approvals;
}
function exit(ledger, asset, clock, phase, trigger) {
  const fill = ledger.execute(asset, {
    barIndex: clock.barIndex,
    barOpenUtcMs: clock.barOpenUtcMs,
    phase,
    side: "sell",
    reason: trigger.kind,
    reference: readUnits(trigger.referencePrice),
    quantity: "all",
    trigger
  });
  if (fill) asset.protection = void 0;
}
function executeBarOrders(ledger, assets, clock, cashWeight, pending, rebalance, allocations, rebalances) {
  const { barIndex, barOpenUtcMs, closeUtcMs, opens } = clock;
  const before = valuesAt(assets, opens);
  const openingEquity = checked(ledger.cash + sum(before));
  const beforePercent = rebalance ? weightVector(before, ledger.cash) : [];
  const protectedAtOpen = assets.map((asset, i) => {
    const trigger = asset.protection && triggerAtOpen(asset.protection, opens[i], barOpenUtcMs, closeUtcMs);
    if (trigger) exit(ledger, asset, clock, "protection-open", trigger);
    return !!trigger;
  });
  for (const [i, asset] of assets.entries()) {
    const target = openingEquity * asset.weight / HUNDRED;
    const reduction = before[i] - target;
    const signal = pending[i];
    if (rebalance ? reduction <= 0n : signal?.action !== "sell") continue;
    const fill = ledger.execute(asset, {
      barIndex,
      barOpenUtcMs,
      phase: "sell",
      side: "sell",
      reason: rebalance ? "rebalance" : signal.reason,
      reference: opens[i],
      quantity: rebalance ? reduction * SCALE / opens[i] : "all",
      rejection: protectedAtOpen[i] ? "risk-priority" : asset.quantity === 0n ? "position-already-flat" : void 0
    });
    if (fill && asset.quantity === 0n) asset.protection = void 0;
  }
  const market = valuesAt(assets, opens);
  const cashBeforeBuys = ledger.cash;
  const openEquity = checked(cashBeforeBuys + sum(market));
  const reserve = openEquity * cashWeight / HUNDRED;
  const capacity = positive(cashBeforeBuys - reserve);
  const candidates = assets.map((asset, i) => {
    const deficit = positive(openEquity * asset.weight / HUNDRED - market[i]);
    if (rebalance) return { active: deficit > 0n, request: deficit };
    const active = pending[i]?.action === "buy";
    const blocked = protectedAtOpen[i] ? "risk-priority" : asset.quantity ? "position-already-open" : void 0;
    return { active, request: active && !blocked ? deficit : 0n, blocked };
  });
  const requests = candidates.map((c) => c.request);
  const approved = approveBudgets(requests, capacity);
  for (const [i, asset] of assets.entries()) {
    const candidate2 = candidates[i];
    if (!candidate2.active) continue;
    let rejection = candidate2.blocked ?? null;
    if (!rejection && candidate2.request > 0n && approved[i] === 0n)
      rejection = reserve > 0n && capacity === 0n && cashBeforeBuys > 0n ? "cash-reserve" : "insufficient-cash";
    ledger.execute(asset, {
      barIndex,
      barOpenUtcMs,
      phase: "buy",
      reason: rebalance ? "rebalance" : pending[i].reason,
      side: "buy",
      reference: opens[i],
      quantity: "all",
      approved: approved[i],
      requested: candidate2.request,
      rejection: rejection ?? void 0
    });
  }
  const spent = cashBeforeBuys - ledger.cash;
  if (spent > capacity || spent > sum(approved))
    throw new Error("\u5171\u4EAB\u4E70\u5165\u8D85\u51FA\u53EF\u7528\u73B0\u91D1\u6216\u6279\u51C6\u9884\u7B97\u3002");
  if (rebalance || candidates.some((c) => c.active))
    allocations.push({
      barIndex,
      openEquity: decimal(openEquity),
      cashBeforeBuys: decimal(cashBeforeBuys),
      reserve: decimal(reserve),
      capacity: decimal(capacity),
      requested: decimal(sum(requests)),
      approved: decimal(sum(approved)),
      spent: decimal(spent),
      cashAfterBuys: decimal(ledger.cash)
    });
  if (rebalance) {
    const afterPercent = weightVector(valuesAt(assets, opens), ledger.cash);
    const targets = [...assets.map((a) => a.weight), cashWeight];
    rebalances.push({
      barIndex,
      barOpenUtcMs,
      beforePercent,
      afterPercent,
      deviationPercent: afterPercent.map(
        (p, i) => p === null ? null : decimal(readUnits(p) - targets[i])
      )
    });
  }
  for (const [i, asset] of assets.entries()) {
    if (!asset.protection || protectedAtOpen[i]) continue;
    const bar = asset.bars[barIndex];
    const trigger = triggerAtOpen(asset.protection, opens[i], barOpenUtcMs, closeUtcMs) ?? triggerIntrabar(
      asset.protection,
      parseDecimal(String(bar.high)),
      parseDecimal(String(bar.low)),
      barOpenUtcMs,
      closeUtcMs
    );
    if (trigger) exit(ledger, asset, clock, "protection-after-buys", trigger);
  }
}

// src/core/shared-pool/types.ts
var SHARED_EXECUTION_VERSION = "shared-spot-clock-v1";
var SHARED_POOL_VERSIONS = {
  "shared-strategy": "shared-spot-strategy-v1",
  rebalance: "shared-spot-rebalance-v1"
};

// src/core/shared-pool/index.ts
var assumptions = [
  "\u6A21\u62DF\u73B0\u8D27\u4E0E\u5171\u4EAB\u865A\u62DF\u73B0\u91D1\uFF0C\u6BCF\u7B14\u5E02\u4EF7\u5355\u6309\u5DF2\u77E5\u5F15\u7528\u4EF7\u548C\u914D\u7F6E\u7684\u6210\u672C\u6210\u4EA4\uFF0C\u5FFD\u7565\u6210\u4EA4\u91CF\u3001\u771F\u5B9E\u6D41\u52A8\u6027\u548C\u76D8\u53E3\u51B2\u51FB\u3002",
  "\u6536\u76D8\u51B3\u7B56\u3001\u4E0B\u4E00\u6839\u5F00\u76D8\u6267\u884C\u3002\u5148\u6267\u884C\u4FDD\u62A4\u548C\u5356\u51FA\uFF0C\u540C\u4E00\u5F00\u76D8\u5356\u6B3E\u89C6\u4E3A\u7ACB\u5373\u5230\u8D26\uFF0C\u53EF\u7528\u4E8E\u672C\u8F6E\u4E70\u5165\u3002\u6839\u5185\u5356\u6B3E\u53EA\u80FD\u7528\u4E8E\u540E\u7EED\u5F00\u76D8\u3002",
  "\u5F00\u76D8\u51CF\u4ED3\u540E\u7EDF\u4E00\u4F30\u503C\uFF1B\u9884\u7559\u76EE\u6807\u73B0\u91D1\uFF0C\u6309\u7533\u8BF7\u989D\u540C\u6BD4\u6279\u51C6\uFF0C18 \u4F4D\u5C3E\u5DEE\u6309\u89C4\u8303\u4EA4\u6613\u5BF9 ASCII \u987A\u5E8F\u8865\u8DB3\u3002\u8D39\u7528\u7EB3\u5165\u9884\u7B97\uFF0C\u6570\u91CF\u5411\u4E0B\u53D6\u6574\uFF0C\u4E0D\u518D\u6B21\u5206\u914D\u4F59\u6B3E\u3002",
  "\u5165\u573A\u524D\u6309\u5B9E\u9645\u6A21\u62DF\u6210\u4EA4\u4EF7\u8BA1\u7B97\u4FDD\u62A4\u9608\u503C\uFF1B\u6B62\u635F\u4EF7\u820D\u5165\u4E3A\u96F6\u65F6\u62D2\u7EDD\u4E70\u5165\uFF0C\u6279\u51C6\u7684\u9884\u7B97\u4FDD\u7559\u4E3A\u73B0\u91D1\u3002",
  "\u5F00\u76D8\u4FDD\u62A4\u4F18\u5148\uFF0C\u6839\u5185\u53CC\u89E6\u53D1\u65F6\u6B62\u635F\u4F18\u5148\uFF0C\u89E6\u53D1\u540E\u5E94\u7528\u5356\u51FA\u6210\u672C\u3002\u6839\u5185\u786E\u5207\u6210\u4EA4\u65F6\u95F4\u672A\u77E5\u3002\u518D\u5E73\u8861\u53EA\u6309\u5468\u671F\u6307\u4EE4\u6267\u884C\u3002",
  "\u4E70\u5165\u6301\u6709\u5728\u5171\u540C\u533A\u95F4\u9996\u5F00\u76D8\u6309\u521D\u59CB\u76EE\u6807\u914D\u7F6E\u4E70\u5165\u4E00\u6B21\uFF0C\u6263\u76F8\u540C\u4E70\u5165\u8D39\u3001\u6ED1\u70B9\u3001\u6570\u91CF\u7CBE\u5EA6\u53CA\u6700\u5C0F\u989D\uFF0C\u62D2\u5355\u7559\u73B0\u91D1\uFF1B\u672B\u6536\u76D8\u4F30\u503C\uFF0C\u65E0\u5356\u51FA\u8D39\u7528\u3002",
  "\u6536\u76D8\u6743\u76CA\u4E0E\u7EC4\u5408\u521D\u59CB\u672C\u91D1\u951A\u70B9\u8BA1\u7B97\u6700\u5927\u56DE\u64A4\u3002\u8D44\u4EA7\u8D21\u732E\u7B49\u4E8E\u4E70\u5165\u603B\u652F\u51FA\u7684\u8D1F\u503C\u52A0\u51C0\u5356\u51FA\u6536\u5165\u53CA\u6536\u76D8\u5E02\u503C\u3002\u6743\u91CD\u4EE5\u767E\u5206\u6570\u8868\u793A\uFF0C\u6536\u76CA\u4E0E\u56DE\u64A4\u4E3A\u5C0F\u6570\u6BD4\u4F8B\u3002"
];
function buyAndHold(assets, initial) {
  let cash = initial;
  const reasons = [];
  const quantities = assets.map((asset) => {
    if (asset.weight === 0n) return 0n;
    const budget = initial * asset.weight / HUNDRED;
    const fill = executeAtReference(
      { cash: budget, quantity: 0n },
      parseDecimal(String(asset.bars[0].open)),
      { side: "buy", quantity: "all" },
      asset.config
    );
    if ("rejected" in fill) {
      reasons.push({ symbol: asset.symbol, reason: fill.rejected });
      return 0n;
    }
    cash -= fill.notional + fill.fee;
    return fill.quantity;
  });
  return { cash: checked(cash), quantities, reasons };
}
function runSharedPool(input) {
  const { assets, alignment, initial, cashWeight } = prepareSharedPool(input);
  const ledger = new PoolLedger(initial, assets);
  const benchmark = buyAndHold(assets, initial);
  const allocations = [];
  const decisions = [];
  const rebalances = [];
  const zeros = assets.map(() => "0");
  const curve = [
    {
      timestampUtcMs: alignment.startUtcMs,
      cash: decimal(initial),
      equity: decimal(initial),
      marketValue: "0",
      benchmarkEquity: decimal(initial),
      drawdown: "0",
      cashWeightPercent: "100",
      weightsPercent: [...zeros],
      contributions: [...zeros]
    }
  ];
  let peak = initial, maxDrop = 0n, worstPeak = initial, equity = initial, benchmarkEquity = initial;
  let pending = assets.map(() => null);
  let rebalance = false;
  let marketValues = assets.map(() => 0n);
  for (let barIndex = 0; barIndex < alignment.barCount; barIndex++) {
    const barOpenUtcMs = alignment.startUtcMs + barIndex * alignment.intervalMs;
    const closeUtcMs = barOpenUtcMs + alignment.intervalMs;
    const opens = assets.map(
      (a) => parseDecimal(String(a.bars[barIndex].open))
    );
    executeBarOrders(
      ledger,
      assets,
      { barIndex, barOpenUtcMs, closeUtcMs, opens },
      cashWeight,
      pending,
      rebalance,
      allocations,
      rebalances
    );
    const closes = assets.map(
      (a) => parseDecimal(String(a.bars[barIndex].close))
    );
    marketValues = valuesAt(assets, closes);
    const marketValue = checked(marketValues.reduce((a, b) => a + b, 0n));
    equity = checked(ledger.cash + marketValue);
    const contributions = assets.map(
      (a, i) => a.sellProceeds - a.buySpend + marketValues[i]
    );
    if (contributions.reduce((a, b) => a + b, 0n) !== equity - initial)
      throw new Error("\u8D44\u4EA7\u51C0\u8D21\u732E\u5408\u8BA1\u4E0E\u7EC4\u5408\u51C0\u76C8\u4E8F\u4E0D\u4E00\u81F4\u3002");
    benchmarkEquity = checked(
      benchmark.quantities.reduce(
        (v, qty, i) => v + mark(qty, closes[i]),
        benchmark.cash
      )
    );
    if (equity > peak) peak = equity;
    const drop = peak - equity;
    if (drop * worstPeak > maxDrop * peak) {
      maxDrop = drop;
      worstPeak = peak;
    }
    const weights = weightVector(marketValues, ledger.cash);
    curve.push({
      timestampUtcMs: closeUtcMs,
      cash: decimal(ledger.cash),
      equity: decimal(equity),
      marketValue: decimal(marketValue),
      benchmarkEquity: decimal(benchmarkEquity),
      drawdown: fraction(drop, peak),
      cashWeightPercent: weights[assets.length],
      weightsPercent: weights.slice(0, assets.length),
      contributions: contributions.map(decimal)
    });
    if (input.mode === "rebalance") {
      rebalance = (barIndex + 1) % input.rebalanceEvery === 0;
      if (rebalance)
        decisions.push({
          barIndex,
          closeUtcMs,
          symbol: null,
          action: "rebalance",
          reason: "period-complete"
        });
    } else {
      pending = assets.map((asset) => {
        const signal = asset.strategy.onClose(asset.bars[barIndex]);
        decisions.push({
          barIndex,
          closeUtcMs,
          symbol: asset.symbol,
          ...signal
        });
        return signal;
      });
    }
  }
  return {
    version: SHARED_POOL_VERSIONS[input.mode],
    executionVersion: SHARED_EXECUTION_VERSION,
    conversionVersion: CONVERSION_VERSION,
    mode: input.mode,
    assumptions,
    alignment,
    initialCash: decimal(initial),
    cashWeightPercent: decimal(cashWeight),
    assets: assets.map((a, i) => ({
      symbol: a.symbol,
      weightPercent: decimal(a.weight),
      quantity: decimal(a.quantity),
      marketValue: decimal(marketValues[i]),
      strategyVersion: a.strategy?.version ?? null,
      netPnl: decimal(a.sellProceeds - a.buySpend + marketValues[i]),
      buySpend: decimal(a.buySpend),
      sellProceeds: decimal(a.sellProceeds),
      fees: decimal(a.fees)
    })),
    orders: ledger.orders,
    allocations,
    decisions,
    rebalances,
    curve,
    netPnl: decimal(equity - initial),
    fees: decimal(ledger.fees),
    fillCount: ledger.fillCount,
    totalReturn: fraction(equity - initial, initial),
    maxDrawdown: fraction(maxDrop, worstPeak),
    benchmarkReturn: fraction(benchmarkEquity - initial, initial),
    benchmarkReasons: benchmark.reasons
  };
}

// src/core/shared-pool/report.ts
var FORMAT3 = "riverlab-shared-pool-experiment";
var SCHEMA = 2;
function header2({ id, name, createdUtcMs }, payloadHash) {
  return {
    format: FORMAT3,
    schemaVersion: SCHEMA,
    id,
    name,
    createdUtcMs,
    payloadHash
  };
}
function digest(input, result, metadata2) {
  const zero = "0".repeat(64);
  return digestPortfolioPayload(input, result, {
    ...header2(metadata2, zero),
    recordHash: zero
  });
}
function createSharedPoolExperiment(input, metadata2, observedUtcMs) {
  assertMetadata(metadata2);
  assertPortfolioMemoryBudget(input, true);
  checkSource(input, observedUtcMs);
  const quote = input.quoteCurrency.trim().toUpperCase();
  function snapshotAssets(assets) {
    return assets.map((asset) => {
      const { candles, ...datasetMetadata } = asset.dataset;
      return {
        ...asset,
        dataset: { ...JSON.parse(JSON.stringify(datasetMetadata)), candles }
      };
    }).sort((a, b) => {
      const left = canonicalSymbol(a.dataset.symbol, quote);
      const right = canonicalSymbol(b.dataset.symbol, quote);
      return left < right ? -1 : left > right ? 1 : 0;
    });
  }
  const snapshot2 = input.mode === "rebalance" ? { ...input, assets: snapshotAssets(input.assets) } : { ...input, assets: snapshotAssets(input.assets) };
  const result = runSharedPool(snapshot2);
  const body = header2(metadata2, digest(snapshot2, result, metadata2));
  return { ...body, recordHash: contentHash(body), input: snapshot2, result };
}
function verifySharedPoolExperiment(value, observedUtcMs, observeReplay) {
  const r = value;
  if (!r || r.format !== FORMAT3 || r.schemaVersion !== SCHEMA)
    throw new Error("\u5171\u4EAB\u8D44\u91D1\u6C60\u62A5\u544A\u683C\u5F0F\u6216\u7248\u672C\u4E0D\u652F\u6301\u3002");
  const keys = [
    "format",
    "schemaVersion",
    "id",
    "name",
    "createdUtcMs",
    "input",
    "result",
    "payloadHash",
    "recordHash"
  ];
  if (Object.keys(r).length !== keys.length || keys.some((key) => !Object.hasOwn(r, key)))
    throw new Error("\u5171\u4EAB\u8D44\u91D1\u6C60\u62A5\u544A\u5B57\u6BB5\u7F3A\u5931\u6216\u542B\u6709\u672A\u77E5\u5B57\u6BB5\u3002");
  assertMetadata(r);
  const mode = r.input?.mode;
  if (mode !== "rebalance" && mode !== "shared-strategy" || r.result?.mode !== mode || r.result.version !== SHARED_POOL_VERSIONS[mode] || r.result.executionVersion !== SHARED_EXECUTION_VERSION || r.result.conversionVersion !== CONVERSION_VERSION)
    throw new Error("\u5171\u4EAB\u8D44\u91D1\u6C60\u7B97\u6CD5\u6216\u4EF7\u683C\u8F6C\u6362\u7248\u672C\u4E0D\u652F\u6301\u3002");
  if (!Array.isArray(r.result.assets) || r.result.assets.length !== r.input.assets?.length || r.result.assets.some((a) => {
    if (!a) return true;
    if (mode === "rebalance") return a.strategyVersion !== null;
    return a.strategyVersion !== STRATEGY_VERSION && a.strategyVersion !== RULE_STRATEGY_VERSION;
  }))
    throw new Error("\u5171\u4EAB\u8D44\u91D1\u6C60\u8D44\u4EA7\u6216\u7B56\u7565\u7248\u672C\u4E0D\u652F\u6301\u3002");
  if (typeof r.payloadHash !== "string" || typeof r.recordHash !== "string" || !digestPattern.test(r.payloadHash) || !digestPattern.test(r.recordHash) || contentHash(header2(r, r.payloadHash)) !== r.recordHash)
    throw new Error("\u5171\u4EAB\u8D44\u91D1\u6C60\u62A5\u544A Hash \u6821\u9A8C\u5931\u8D25\u3002");
  checkSource(r.input, observedUtcMs);
  if (digest(r.input, r.result, r) !== r.payloadHash)
    throw new Error("\u5171\u4EAB\u8D44\u91D1\u6C60\u62A5\u544A Hash \u6821\u9A8C\u5931\u8D25\u3002");
  const quote = r.input.quoteCurrency.trim().toUpperCase();
  let previous = "";
  for (const { dataset } of r.input.assets) {
    const symbol = canonicalSymbol(dataset.symbol, quote);
    if (symbol <= previous)
      throw new Error("\u5171\u4EAB\u8D44\u91D1\u6C60\u6765\u6E90\u987B\u6309\u89C4\u8303\u4EA4\u6613\u5BF9\u987A\u5E8F\u4FDD\u5B58\u3002");
    previous = symbol;
  }
  const replay = runSharedPool(r.input);
  const payloadHash = digest(r.input, replay, r);
  if (payloadHash !== r.payloadHash)
    throw new Error("\u5171\u4EAB\u8D44\u91D1\u6C60\u5B8C\u6574\u91CD\u7B97\u4E0D\u4E00\u81F4\u3002");
  observeReplay?.({
    ...r,
    result: replay,
    payloadHash,
    recordHash: contentHash(header2(r, payloadHash))
  });
  return r;
}

// src/core/market-regime/source.ts
function singleVersions(result, statisticsVersion) {
  const m = result.manifest;
  return {
    engine: m.algorithmVersion,
    conversion: m.conversionVersion,
    statistics: statisticsVersion,
    strategy: m.strategy.version,
    signalHash: m.signalHash,
    runHash: m.runHash,
    dataHash: m.dataHash
  };
}
function sourceCandles(source, reference) {
  if (source.kind === "single") {
    if (reference !== null) throw new Error("\u5355\u5E01\u79CD\u7814\u7A76\u4F7F\u7528\u539F\u5B9E\u9A8C\u884C\u60C5\u3002");
    return source.input.dataset.candles;
  }
  const { startUtcMs, endUtcMs, assets } = source.input;
  const asset = assets.find((a) => a.dataset.symbol === reference);
  if (!asset) throw new Error("\u8BF7\u663E\u5F0F\u9009\u62E9\u7EC4\u5408\u539F\u59CB\u5FEB\u7167\u4E2D\u7684\u53C2\u8003\u8D44\u4EA7\u3002");
  return asset.dataset.candles.filter(
    (bar) => bar.timestampUtcMs >= startUtcMs && bar.timestampUtcMs <= endUtcMs
  );
}
function metadata({ id, name, createdUtcMs }) {
  return { id, name, createdUtcMs };
}
function fromSingle(e, reference, now) {
  const { result, statistics, dataset } = e.payload;
  const m = result.manifest;
  if (!Number.isSafeInteger(now) || m.completedThroughUtcMs > now)
    throw new Error("\u6E90\u5B9E\u9A8C\u58F0\u660E\u7684\u6536\u76D8\u65F6\u95F4\u665A\u4E8E\u5F53\u524D\u65F6\u95F4\u6216\u65E0\u6548\u3002");
  validateSnapshotFields(dataset);
  const input = {
    dataset,
    config: m.config,
    risk: m.risk,
    strategy: m.strategy.config,
    completedThroughUtcMs: m.completedThroughUtcMs
  };
  const source = {
    kind: "single",
    schemaVersion: e.schemaVersion,
    ...metadata(e),
    elapsedMs: e.elapsedMs,
    payloadHash: e.payloadHash,
    input,
    runHash: m.runHash,
    dataHash: m.dataHash,
    versions: singleVersions(result, statistics.version)
  };
  const candles = sourceCandles(source, reference);
  return {
    source,
    candles,
    series: {
      candles,
      intervalMs: m.intervalMs,
      completedThroughUtcMs: m.completedThroughUtcMs,
      initialCash: m.config.initialCash,
      netPnl: statistics.netPnl,
      bars: singleBars(result, statistics)
    }
  };
}
function fromPortfolio(e, reference) {
  const common = {
    ...metadata(e),
    payloadHash: e.payloadHash,
    recordHash: e.recordHash
  };
  const source = e.format === "riverlab-portfolio-experiment" ? {
    ...common,
    kind: "portfolio",
    schemaVersion: e.schemaVersion,
    input: e.input,
    versions: {
      algorithm: e.result.version,
      assets: e.result.assets.map((a) => ({
        symbol: a.symbol,
        versions: singleVersions(a.result, a.statistics.version)
      }))
    }
  } : {
    ...common,
    kind: "shared",
    schemaVersion: e.schemaVersion,
    input: e.input,
    versions: {
      algorithm: e.result.version,
      execution: e.result.executionVersion,
      conversion: e.result.conversionVersion,
      assets: e.result.assets.map((a) => ({
        symbol: a.symbol,
        strategy: a.strategyVersion
      }))
    }
  };
  const candles = sourceCandles(source, reference);
  return {
    source,
    candles,
    series: {
      candles,
      intervalMs: e.result.alignment.intervalMs,
      completedThroughUtcMs: e.input.completedThroughUtcMs,
      initialCash: e.result.initialCash,
      netPnl: e.result.netPnl,
      bars: e.format === "riverlab-portfolio-experiment" ? portfolioBars(e.result) : sharedBars(e.result)
    }
  };
}
function replayIdentity(source) {
  if (source.kind === "single") {
    const { input: input2, ...identity2 } = source;
    const { dataset, ...settings } = input2;
    return canonicalJson({ identity: identity2, settings, datasetId: dataset.id });
  }
  const { input, ...identity } = source;
  return canonicalJson({
    identity,
    symbols: input.assets.map((a) => a.dataset.symbol)
  });
}
function replaySource(snapshot2, reference, now) {
  const meta = metadata(snapshot2);
  let restored;
  if (snapshot2.kind === "single") {
    if (snapshot2.schemaVersion !== 1) throw new Error("\u6E90\u5B9E\u9A8C\u7248\u672C\u4E0D\u652F\u6301\u3002");
    assertExperimentMetadata(snapshot2);
    requireFields(snapshot2.input, [
      "dataset",
      "config",
      "risk",
      "strategy",
      "completedThroughUtcMs"
    ]);
    const actual = runExperiment(snapshot2.input);
    restored = fromSingle(
      sealExperiment(actual, { ...meta, elapsedMs: snapshot2.elapsedMs }),
      reference,
      now
    );
  } else if (snapshot2.kind === "portfolio") {
    if (snapshot2.schemaVersion !== 1) throw new Error("\u6E90\u7EC4\u5408\u5B9E\u9A8C\u7248\u672C\u4E0D\u652F\u6301\u3002");
    restored = fromPortfolio(
      createPortfolioExperiment(snapshot2.input, meta, now),
      reference
    );
  } else if (snapshot2.kind === "shared") {
    if (snapshot2.schemaVersion !== 2)
      throw new Error("\u6E90\u5171\u4EAB\u8D44\u91D1\u6C60\u62A5\u544A\u7248\u672C\u4E0D\u652F\u6301\u3002");
    restored = fromPortfolio(
      createSharedPoolExperiment(snapshot2.input, meta, now),
      reference
    );
  } else throw new Error("\u4E0D\u652F\u6301\u7684\u6E90\u5B9E\u9A8C\u7C7B\u578B\u3002");
  if (replayIdentity(snapshot2) !== replayIdentity(restored.source))
    throw new Error("\u6E90\u5B9E\u9A8C\u7248\u672C\u3001\u8EAB\u4EFD\u6216 Hash \u4E0E\u539F\u5185\u6838\u91CD\u7B97\u4E0D\u7B26\u3002");
  return restored;
}

// src/core/market-regime/report.ts
var REGIME_VERSION = REGIME_ATTRIBUTION_VERSION;
var MAX_REGIME_REPORT_BYTES = MAX_PORTFOLIO_REPORT_BYTES;
var FORMAT4 = "riverlab-market-regime";
function digest2(body) {
  assertPortfolioMemoryBudget(body);
  const hash3 = sha256.create();
  let bytes = ',"reportHash":""'.length + 64;
  forEachCanonicalChunk(body, (chunk) => {
    bytes += chunk.length;
    if (bytes > MAX_REGIME_REPORT_BYTES)
      throw new Error("\u5E02\u573A\u72B6\u6001\u62A5\u544A\u8D85\u8FC7 32 MiB\uFF0C\u8BF7\u7F29\u77ED\u539F\u5B9E\u9A8C\u533A\u95F4\u3002");
    hash3.update(chunk);
  });
  return Array.from(hash3.digest(), (b) => b.toString(16).padStart(2, "0")).join(
    ""
  );
}
function seal(captured, reference, params, metadata2) {
  const body = {
    format: FORMAT4,
    schemaVersion: 1,
    algorithmVersion: REGIME_VERSION,
    modelVersion: REGIME_MODEL_VERSION,
    id: metadata2.id,
    name: metadata2.name,
    createdUtcMs: metadata2.createdUtcMs,
    reference,
    params: { ...params },
    source: captured.source,
    result: analyzeRegimes(captured.series, params)
  };
  return { ...body, reportHash: digest2(body) };
}
function verifyRegimeReport(value, observedUtcMs) {
  const r = value;
  if (r?.format !== FORMAT4 || r.schemaVersion !== 1 || r.modelVersion !== REGIME_MODEL_VERSION || r.algorithmVersion !== REGIME_VERSION)
    throw new Error("\u5E02\u573A\u72B6\u6001\u62A5\u544A\u683C\u5F0F\u6216\u7248\u672C\u4E0D\u652F\u6301\u3002");
  assertMetadata(r);
  const { reportHash, ...body } = r;
  if (typeof reportHash !== "string" || !digestPattern.test(reportHash) || digest2(body) !== reportHash)
    throw new Error("\u5E02\u573A\u72B6\u6001\u62A5\u544A Hash \u4E0D\u7B26\u3002");
  const rebuilt = seal(
    replaySource(r.source, r.reference, observedUtcMs),
    r.reference,
    r.params,
    r
  );
  if (rebuilt.reportHash !== reportHash)
    throw new Error("\u5E02\u573A\u72B6\u6001\u62A5\u544A\u4E0E\u539F\u5B9E\u9A8C\u91CD\u7B97\u7ED3\u679C\u4E0D\u7B26\u3002");
  return rebuilt;
}

// src/core/replay/index.ts
var REPLAY_VERSION = "interactive-prefix-replay-v1";
var REPLAY_LIMITS = Object.freeze({
  decisions: 1e3,
  notes: 1e3,
  noteLength: 2e3
});
function integer3(n, min, max) {
  if (!Number.isSafeInteger(n) || n < min || n > max)
    throw new Error("\u56DE\u653E\u6E38\u6807/\u8BA1\u6570\u5FC5\u987B\u4E3A\u8303\u56F4\u5185\u6574\u6570\u3002");
}
var text = (v, max) => typeof v === "string" && !!v.trim() && v.length <= max;
var hash2 = (v) => typeof v === "string" && /^[a-f0-9]{64}$/.test(v);
function summarizeReplay(r) {
  return {
    id: r.id,
    name: r.name,
    createdUtcMs: r.createdUtcMs,
    payloadHash: r.payloadHash,
    symbol: r.payload.symbol,
    cursor: r.payload.cursor
  };
}
function assertReplayCheckpoint(value) {
  const r = value;
  if (!r || r.format !== "riverlab-replay" || r.schemaVersion !== 1 || !text(r.id, 100) || !text(r.name, 160) || !Number.isSafeInteger(r.createdUtcMs) || r.createdUtcMs < 0 || r.createdUtcMs > 41024448e5 || r.disclaimer !== DISCLAIMER || !r.payload || contentHash(r.payload) !== r.payloadHash)
    throw new Error("\u56DE\u653E\u8BB0\u5F55\u635F\u574F\u6216\u6821\u9A8C\u4E0D\u7B26\uFF0C\u672A\u4FEE\u590D\u3002");
  const p = r.payload;
  if (p.version !== REPLAY_VERSION || p.engineVersion !== ALGORITHM_VERSION || p.conversionVersion !== CONVERSION_VERSION || !text(p.datasetId, 100) || !text(p.symbol, 80) || !hash2(p.sourceHash) || !hash2(p.sourceFileSha256) || !hash2(p.resultHash) || !hash2(p.stateHash) || !Array.isArray(p.decisions) || p.decisions.length > REPLAY_LIMITS.decisions || !Array.isArray(p.notes) || p.notes.length > REPLAY_LIMITS.notes)
    throw new Error("\u56DE\u653E\u8EAB\u4EFD\u3001\u7248\u672C\u6216\u52A8\u4F5C\u8BB0\u5F55\u65E0\u6548\u3002");
  integer3(p.cursor, 1, 5e4);
  normalizeConfig(p.config);
  normalizeRisk(p.risk);
  let previous = -1;
  for (const s of p.decisions) {
    if (!s || !Number.isInteger(s.candleIndex) || s.candleIndex <= previous || s.candleIndex >= p.cursor || s.action !== "buy" && s.action !== "sell" || s.reason !== "manual-" + s.action || Object.keys(s).some(
      (k) => !["candleIndex", "action", "quantity", "reason"].includes(k)
    ))
      throw new Error("\u56DE\u653E\u624B\u5DE5\u51B3\u7B56\u987A\u5E8F/\u5B57\u6BB5\u65E0\u6548\u3002");
    if (s.quantity !== "all") parseDecimal(s.quantity);
    previous = s.candleIndex;
  }
  previous = 0;
  for (const n of p.notes) {
    if (!n || !text(n.text, REPLAY_LIMITS.noteLength) || !Number.isInteger(n.cursor) || n.cursor < Math.max(1, previous) || n.cursor > p.cursor || Object.keys(n).some((k) => !["cursor", "text"].includes(k)))
      throw new Error("\u56DE\u653E\u65E5\u8BB0\u65E0\u6548\u3002");
    previous = n.cursor;
  }
}
var ReplaySession = class _ReplaySession {
  constructor(dataset, config, risk) {
    this.dataset = dataset;
    assertDataset(dataset);
    const { candles, ...metadata2 } = dataset;
    this.dataset = {
      ...JSON.parse(JSON.stringify(metadata2)),
      candles: candles.map((c) => ({ ...c }))
    };
    dataset = this.dataset;
    this.config = normalizeConfig(config);
    this.risk = normalizeRisk(risk);
    if (parseDecimal(this.config.initialCash) === 0n)
      throw new Error("\u521D\u59CB\u672C\u91D1\u5FC5\u987B\u5927\u4E8E0\u3002");
    this.sourceHash = contentHash(dataset);
    this.execution = createBacktestSession(
      {
        dataset,
        config: this.config,
        risk: this.risk,
        signals: [],
        completedThroughUtcMs: dataset.candles.at(-1).timestampUtcMs + dataset.quality.intervalMs
      },
      true
    );
  }
  dataset;
  execution;
  sourceHash;
  decisions = [];
  notes = [];
  config;
  risk;
  get cursor() {
    return this.execution.cursor;
  }
  get total() {
    return this.dataset.candles.length;
  }
  advance(count = 1) {
    integer3(count, 1, 5e4);
    if (this.cursor === this.total)
      throw new Error("\u56DE\u653E\u5DF2\u7ED3\u675F\uFF0C\u65E0\u4E0B\u4E00\u6839\uFF1B\u672A\u5F3A\u5236\u5E73\u4ED3\u3002");
    const target = Math.min(this.total, this.cursor + count);
    while (this.cursor < target) this.execution.advance();
    if (this.cursor === this.total) this.execution.finish();
  }
  trade(action, quantity) {
    if (this.cursor < 1 || this.cursor === this.total)
      throw new Error("\u4EC5\u5728\u5DF2\u64AD\u653E\u4E14\u975E\u672B\u6839\u7684\u6536\u76D8\u53EF\u4EE5\u63D0\u4EA4\u51B3\u7B56\u3002");
    if (this.decisions.length >= REPLAY_LIMITS.decisions)
      throw new Error("\u624B\u5DE5\u51B3\u7B56\u6700\u591A1000\u6B21\u3002");
    if (action !== "buy" && action !== "sell")
      throw new Error("\u4EC5\u652F\u6301\u865A\u62DF\u4E70\u5356\u3002");
    const signal = {
      candleIndex: this.cursor - 1,
      action,
      quantity,
      reason: "manual-" + action
    };
    this.execution.submit(signal);
    this.decisions.push({ ...this.execution.result.signals.at(-1).signal });
  }
  note(value) {
    if (!this.cursor || !text(value, REPLAY_LIMITS.noteLength) || this.notes.length >= REPLAY_LIMITS.notes)
      throw new Error("\u65E5\u8BB0\u97001\u20132000\u5B57\u7B26\uFF0C\u6700\u591A1000\u6761\uFF0C\u4E14\u5FC5\u987B\u6709\u5DF2\u64AD\u653EK\u7EBF\u3002");
    this.notes.push({ cursor: this.cursor, text: value });
  }
  state() {
    return {
      version: REPLAY_VERSION,
      sourceHash: this.sourceHash,
      config: this.config,
      risk: this.risk,
      cursor: this.cursor,
      decisions: this.decisions,
      notes: this.notes,
      account: this.execution.result.final,
      pending: this.execution.pending
    };
  }
  view(fromCursor = 0) {
    integer3(fromCursor, 0, this.cursor);
    if (!this.cursor) throw new Error("\u5C1A\u672A\u64AD\u653E\u9996\u6839\u3002");
    const statistics = calculateStatistics(
      this.execution.result,
      String(this.dataset.candles[0].open)
    );
    const { curve, completedTrades, ...rest } = statistics;
    return {
      source: JSON.parse(JSON.stringify(summarizeDataset(this.dataset))),
      version: REPLAY_VERSION,
      engineVersion: ALGORITHM_VERSION,
      config: { ...this.config },
      risk: { ...this.risk },
      cursor: this.cursor,
      total: this.total,
      fromCursor,
      candles: this.dataset.candles.slice(fromCursor, this.cursor).map((c) => ({ ...c })),
      curve: curve.slice(fromCursor === 0 ? 0 : fromCursor + 1),
      account: {
        ...this.execution.result.final,
        position: { ...this.execution.result.final.position }
      },
      pending: this.execution.pending ? { ...this.execution.pending } : null,
      orders: JSON.parse(
        JSON.stringify(this.execution.result.orders.slice(-100))
      ),
      fills: JSON.parse(
        JSON.stringify(this.execution.result.fills.slice(-100))
      ),
      orderCount: this.execution.result.orders.length,
      fillCount: this.execution.result.fills.length,
      statistics: { ...rest, completedTradeCount: completedTrades.length },
      notes: this.notes.map((n) => ({ ...n })),
      stateHash: contentHash(this.state()),
      definitions: METRIC_DEFINITIONS,
      assumptions: [
        ...RUN_ASSUMPTIONS,
        "\u4EC5\u5DF2\u64AD\u653E\u524D\u7F00\uFF1B\u624B\u5DE5\u5F53\u524D\u6536\u76D8\u51B3\u7B56\u2192\u4E0B\u4E00\u6839\u5F00\u76D8\uFF1B\u6BCF\u6839\u6700\u591A\u4E00\u7B14\uFF1B\u4E0D\u5141\u8BB8\u56DE\u9000\u3002",
        "\u72B6\u6001\u5907\u4EFD\u4E0D\u542B\u884C\u60C5\uFF0C\u6062\u590D\u987B\u539F\u4FDD\u5B58\u6570\u636E\u96C6\u5B58\u5728\u4E14hash\u4E00\u81F4\uFF1B\u67E5\u770B\u5176\u4ED6\u9875\u9762\u6216\u6E90CSV\u53EF\u7834\u574F\u76F2\u56DE\u653E\u4F53\u9A8C\u3002"
      ]
    };
  }
  checkpoint(metadata2) {
    if (!this.cursor) throw new Error("\u5C1A\u65E0\u56DE\u653E\u72B6\u6001\u3002");
    const r = this.execution.result;
    const payload = {
      version: REPLAY_VERSION,
      engineVersion: ALGORITHM_VERSION,
      conversionVersion: CONVERSION_VERSION,
      datasetId: this.dataset.id,
      sourceHash: this.sourceHash,
      sourceFileSha256: this.dataset.file.sha256,
      symbol: this.dataset.symbol,
      config: { ...this.config },
      risk: { ...this.risk },
      cursor: this.cursor,
      decisions: this.decisions.map((s) => ({ ...s })),
      notes: this.notes.map((n) => ({ ...n })),
      resultHash: contentHash({
        fills: r.fills,
        orders: r.orders,
        closes: r.closes,
        final: r.final
      }),
      stateHash: contentHash(this.state())
    };
    const record = {
      format: "riverlab-replay",
      schemaVersion: 1,
      ...metadata2,
      payload,
      payloadHash: contentHash(payload),
      disclaimer: DISCLAIMER
    };
    assertReplayCheckpoint(record);
    return record;
  }
  static restore(dataset, value) {
    assertReplayCheckpoint(value);
    const p = value.payload;
    const session = new _ReplaySession(dataset, p.config, p.risk);
    if (dataset.id !== p.datasetId || session.sourceHash !== p.sourceHash || dataset.file.sha256 !== p.sourceFileSha256 || dataset.symbol !== p.symbol)
      throw new Error(
        "\u539F\u6570\u636E\u96C6\u7F3A\u5931\u3001\u5DF2\u6539\u53D8\u6216\u8EAB\u4EFD\u4E0D\u4E00\u81F4\uFF1B\u4E0D\u80FD\u6062\u590D\uFF0C\u4E0D\u81EA\u52A8\u66FF\u6362\u3002"
      );
    integer3(p.cursor, 1, dataset.candles.length);
    if (p.decisions.some((s) => s.candleIndex >= dataset.candles.length - 1))
      throw new Error("\u672B\u6839\u4E4B\u540E\u4E0D\u80FD\u6392\u961F\u51B3\u7B56\u3002");
    let index = 0;
    while (session.cursor < p.cursor) {
      session.advance();
      const decision2 = p.decisions[index];
      if (decision2?.candleIndex === session.cursor - 1 && decision2.action !== "hold") {
        session.trade(decision2.action, decision2.quantity);
        index++;
      }
    }
    p.notes.forEach((n) => session.notes.push({ ...n }));
    const actual = session.checkpoint({
      id: value.id,
      name: value.name,
      createdUtcMs: value.createdUtcMs
    });
    if (canonicalJson(actual) !== canonicalJson(value))
      throw new Error("\u56DE\u653E\u91CD\u7B97\u4E0D\u4E00\u81F4\uFF0C\u8BB0\u5F55\u635F\u574F\u6216\u7248\u672C\u4E0D\u652F\u6301\uFF1B\u672A\u4FEE\u590D\u3002");
    return session;
  }
  csv() {
    const cell = (value) => {
      let s = value == null ? "" : String(value);
      if (/^[\s]*[=+\-@]/.test(s) && !/^-[0-9]+(?:\.[0-9]+)?$/.test(s))
        s = "'" + s;
      return '"' + s.replace(/"/g, '""') + '"';
    };
    const rows = [
      [DISCLAIMER],
      ["replayVersion", REPLAY_VERSION],
      ["stateHash", contentHash(this.state())],
      [
        "type",
        "candleIndex",
        "timestampUtcMs",
        "side",
        "quantity",
        "price",
        "fee",
        "cashAfter",
        "positionAfter",
        "equityAfter",
        "reasonOrNote",
        "intrabarAssumption",
        "orderStatus",
        "barOpenUtcMs",
        "barCloseUtcMs"
      ]
    ];
    this.execution.result.fills.forEach(
      (f) => rows.push([
        "fill",
        f.candleIndex,
        f.timestampUtcMs,
        f.side,
        f.quantity,
        f.price,
        f.fee,
        f.after.cash,
        f.after.position.quantity,
        f.after.equity,
        f.reason,
        f.trigger?.assumption ?? "",
        "filled",
        f.trigger?.barOpenUtcMs ?? "",
        f.trigger?.barCloseUtcMs ?? ""
      ])
    );
    this.execution.result.orders.forEach(
      (o) => rows.push([
        "order",
        o.intent.targetCandleIndex,
        o.resolvedUtcMs,
        o.intent.side,
        o.intent.quantity,
        "",
        "",
        "",
        "",
        "",
        o.reason ?? o.intent.reason,
        o.intent.trigger?.assumption ?? "",
        o.status,
        o.intent.trigger?.barOpenUtcMs ?? "",
        o.intent.trigger?.barCloseUtcMs ?? ""
      ])
    );
    this.notes.forEach(
      (n) => rows.push([
        "note",
        n.cursor - 1,
        this.dataset.candles[n.cursor - 1].timestampUtcMs + this.dataset.quality.intervalMs,
        "",
        "",
        "",
        "",
        "",
        "",
        "",
        n.text,
        "",
        "",
        "",
        ""
      ])
    );
    return "\uFEFF" + rows.map((r) => r.map(cell).join(",")).join("\r\n") + "\r\n";
  }
};

// src/core/risk-analysis/simulation.ts
var SIMULATION_VERSION = "net-equity-bootstrap-fixed18-v1";
var RISK_LIMITS = Object.freeze({
  minPeriods: 20,
  paths: 2e3,
  steps: 5e4,
  evaluations: 2e6,
  bands: 101
});
var integer4 = (n, min, max, label) => {
  if (!Number.isSafeInteger(n) || n < min || n > max)
    throw new Error(label + "\u5FC5\u987B\u4E3A" + min + "\u2013" + max + "\u6574\u6570\u3002");
};
function normalizeRiskSettings(input, periods) {
  integer4(periods, RISK_LIMITS.minPeriods, 5e4, "\u6E90\u6837\u672C\u6570");
  if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).some(
    (k) => ![
      "method",
      "seed",
      "paths",
      "steps",
      "blockSize",
      "thresholdPct"
    ].includes(k)
  ))
    throw new Error("\u98CE\u9669\u8BBE\u7F6E\u5B57\u6BB5\u65E0\u6548\u3002");
  if (input.method !== "iid" && input.method !== "block")
    throw new Error("\u62BD\u6837\u65B9\u6CD5\u5FC5\u987B\u4E3AIID\u6216\u8FDE\u7EED\u533A\u5757\u3002");
  integer4(input.seed, 0, 4294967295, "\u79CD\u5B50");
  integer4(input.paths, 20, RISK_LIMITS.paths, "\u8DEF\u5F84\u6570");
  integer4(input.steps, 1, RISK_LIMITS.steps, "\u6B65\u6570");
  integer4(input.thresholdPct, 1, 99, "\u672C\u91D1\u9608\u503C\u767E\u5206\u6BD4");
  integer4(input.blockSize, 1, Math.min(periods, 1e3), "\u533A\u5757\u957F\u5EA6");
  if (input.method === "iid" && input.blockSize !== 1)
    throw new Error("IID\u7684\u533A\u5757\u957F\u5EA6\u5FC5\u987B\u4E3A1\u3002");
  if (input.paths * input.steps > RISK_LIMITS.evaluations)
    throw new Error("\u8D85\u8FC7200\u4E07\u6B65\u9884\u7B97\uFF0C\u8BF7\u660E\u786E\u51CF\u5C11\u8DEF\u5F84\u6216\u6B65\u6570\uFF1B\u4E0D\u4F1A\u81EA\u52A8\u622A\u65AD\u3002");
  return {
    method: input.method,
    seed: input.seed,
    paths: input.paths,
    steps: input.steps,
    blockSize: input.blockSize,
    thresholdPct: input.thresholdPct
  };
}
var compare2 = (a, b) => a < b ? -1 : a > b ? 1 : 0;
var rank = (count, p) => Math.ceil(count * p / 100) - 1;
function simulateEquity(equities, input, progress) {
  if (!Array.isArray(equities)) throw new Error("\u7F3A\u5C11\u6E90\u6743\u76CA\u8DEF\u5F84\u3002");
  const settings = normalizeRiskSettings(input, equities.length - 1);
  const values = equities.map((s) => {
    const n = readUnits(s);
    if (n <= 0n || n >= ACCOUNTING_LIMIT)
      throw new Error("\u6E90\u6743\u76CA\u5FC5\u987B\u4E25\u683C\u4E3A\u6B63\u4E14\u5C0F\u4E8E\u6D3E\u751F\u8D26\u672C\u4E0A\u9650\uFF0C\u542B0\u4E0D\u80FD\u91CD\u91C7\u6837\u3002");
    return n;
  });
  if (values[0] >= 10n ** 48n) throw new Error("\u6E90\u521D\u59CB\u672C\u91D1\u5FC5\u987B\u5C0F\u4E8E1e30\u3002");
  if (values.every((v) => v === values[0]))
    throw new Error("\u6E90\u6743\u76CA\u6052\u5B9A\uFF0C\u7F3A\u5C11\u53EF\u91CD\u91C7\u6837\u98CE\u9669\u4FE1\u606F\uFF1B\u4E0D\u751F\u6210\u8BEF\u5BFC\u60270%\u98CE\u9669\u3002");
  const pairs = values.slice(1).map((n, i) => ({ n, d: values[i] })), initial = values[0], threshold = initial * BigInt(settings.thresholdPct) / 100n;
  const points = Array.from(
    { length: Math.min(RISK_LIMITS.bands, settings.steps + 1) },
    (_, i) => Math.floor(
      i * settings.steps / (Math.min(RISK_LIMITS.bands, settings.steps + 1) - 1)
    )
  );
  const buckets = points.map(() => []), traces = [], paths = [], ddPairs = [], finals = [];
  let loss = 0, hits = 0, zeros = 0, sum2 = 0n;
  const random = pcg32(settings.seed);
  for (let path = 0; path < settings.paths; path++) {
    let capital = initial, peak = initial, maxN = 0n, maxD = initial, hit = false, zero = false, blockRemaining = 0, sourceIndex = 0, bandIndex = 1;
    const trace = [
      { step: 0, equity: decimal(initial) }
    ];
    buckets[0].push(initial);
    for (let step = 1; step <= settings.steps; step++) {
      if (settings.method === "iid") sourceIndex = random.bounded(pairs.length);
      else {
        if (!blockRemaining) {
          sourceIndex = random.bounded(pairs.length - settings.blockSize + 1);
          blockRemaining = settings.blockSize;
        }
        blockRemaining--;
      }
      const pair = pairs[sourceIndex];
      if (settings.method === "block") sourceIndex++;
      if (pair.n !== pair.d) capital = capital * pair.n / pair.d;
      if (capital >= ACCOUNTING_LIMIT)
        throw new Error(
          "\u91CD\u91C7\u6837\u8DEF\u5F84\u8D85\u51FA\u6D3E\u751F\u91D1\u989D\u4E0A\u9650\uFF0C\u6574\u6279\u7EC8\u6B62\uFF1B\u672A\u88C1\u526A\u6216\u5220\u9664\u6781\u7AEF\u8DEF\u5F84\u3002"
        );
      if (capital > peak) peak = capital;
      const drop = peak - capital;
      if (drop * maxD > maxN * peak) {
        maxN = drop;
        maxD = peak;
      }
      if (capital <= threshold) hit = true;
      if (capital === 0n) zero = true;
      if (step === points[bandIndex]) {
        buckets[bandIndex].push(capital);
        if (path < 5) trace.push({ step, equity: decimal(capital) });
        bandIndex++;
      }
    }
    if (path < 5) traces.push({ path: path + 1, points: trace });
    finals.push(capital);
    ddPairs.push({ n: maxN, d: maxD });
    sum2 += capital;
    if (capital < initial) loss++;
    if (hit) hits++;
    if (zero) zeros++;
    paths.push({
      path: path + 1,
      finalEquity: decimal(capital),
      netPnl: decimal(capital - initial),
      totalReturn: fraction(capital - initial, initial),
      maxDrawdown: fraction(maxN, maxD),
      thresholdHit: hit,
      zero
    });
    if ((path + 1) % 20 === 0 || path + 1 === settings.paths)
      progress?.(path + 1, settings.paths);
  }
  const sorted = [...finals].sort(compare2), sortedDD = ddPairs.sort((a, b) => compare2(a.n * b.d, b.n * a.d));
  const quantiles = [5, 50, 95].map((p) => {
    const i = rank(settings.paths, p), dd = sortedDD[i];
    return {
      percentile: p,
      finalEquity: decimal(sorted[i]),
      totalReturn: fraction(sorted[i] - initial, initial),
      maxDrawdown: fraction(dd.n, dd.d)
    };
  });
  const frequency = (count) => ({
    count,
    total: settings.paths,
    fraction: fraction(BigInt(count), BigInt(settings.paths))
  });
  const min = sorted[0], max = sorted.at(-1), span = max - min;
  const binCount = span === 0n ? 1 : span < 10n ? Number(span) : 10;
  const ceil = (n, d) => (n + d - 1n) / d;
  const histogram = Array.from({ length: binCount }, (_, i) => ({
    lower: decimal(min + ceil(span * BigInt(i), BigInt(binCount))),
    upper: decimal(min + ceil(span * BigInt(i + 1), BigInt(binCount))),
    count: 0
  }));
  finals.forEach((v) => {
    const index = span === 0n ? 0 : Math.min(binCount - 1, Number((v - min) * BigInt(binCount) / span));
    histogram[index].count++;
  });
  return {
    version: SIMULATION_VERSION,
    rngVersion: RNG_VERSION,
    settings,
    sourcePeriods: pairs.length,
    initialEquity: decimal(initial),
    thresholdEquity: decimal(threshold),
    meanFinalEquity: decimal(sum2 / BigInt(settings.paths)),
    quantiles,
    loss: frequency(loss),
    thresholdHits: frequency(hits),
    zeros: frequency(zeros),
    histogram,
    bands: points.map((step, i) => {
      const b = buckets[i].sort(compare2);
      return {
        step,
        p05: decimal(b[rank(settings.paths, 5)]),
        p50: decimal(b[rank(settings.paths, 50)]),
        p95: decimal(b[rank(settings.paths, 95)])
      };
    }),
    traces,
    paths,
    warnings: [
      "\u6A21\u578B\u5185\u6837\u672C\u9891\u7387\u4E0E\u5206\u4F4D\u4E0D\u662F\u672A\u6765\u6982\u7387\u3001\u7F6E\u4FE1\u533A\u95F4\u6216\u6536\u76CA\u4FDD\u8BC1\uFF1B0/\u8DEF\u5F84\u6570\u4E0D\u4EE3\u8868\u771F\u5B9E\u98CE\u9669\u4E3A0\u3002",
      settings.method === "iid" ? "IID\u6709\u653E\u56DE\u62BD\u6837\u7834\u574F\u539F\u5E8F\u5217\u76F8\u5173\u6027\u3002" : "\u533A\u5757\u62BD\u6837\u4EC5\u4FDD\u7559\u5757\u5185\u987A\u5E8F\uFF1B\u8DE8\u5757\u5173\u7CFB\u3001\u5E02\u573A\u72B6\u6001\u4E0E\u771F\u5B9E\u72EC\u7ACB\u6027\u5747\u4E0D\u4FDD\u8BC1\u3002",
      "\u91CD\u91C7\u6837\u542B\u5B9E\u9645\u8D39\u7528/\u6ED1\u70B9\u4E0E\u6D6E\u52A8\u76C8\u4E8F\u7684\u5386\u53F2\u51C0\u6743\u76CA\u6BD4\u4F8B\uFF0C\u4E0D\u91CD\u65B0\u64AE\u5408\u3001\u4E0D\u91CD\u7B97\u6210\u672C\u6216\u4FDD\u62A4\uFF0C\u4E0D\u4FDD\u8BC1\u65B0\u8DEF\u5F84\u53EF\u6210\u4EA4\u3002",
      "\u6240\u6709\u6B65\u9AA4\u53C2\u4E0E\u7EDF\u8BA1\uFF1B\u6700\u591A101\u4E2A\u5E26\u70B9\u3001\u99965\u6761\u8DEF\u5F84\u4EC5\u4F5C\u5C55\u793A\uFF1B\u6B65\u6570\u8F74\u4E0D\u4EE3\u8868\u672A\u6765UTC\uFF0C\u4E0D\u8BA1\u7B97\u5E74\u5316\u3002",
      "\u5386\u53F2\u6837\u672C\u548C\u53C2\u6570\u9009\u62E9\u504F\u5DEE\u4E0D\u4F1A\u56E0\u589E\u52A0\u6A21\u62DF\u8DEF\u5F84\u6570\u6D88\u5931\uFF1B\u9700\u72EC\u7ACB\u6837\u672C\u5916\u8BC1\u636E\u3002"
    ]
  };
}

// src/core/risk-analysis/studies.ts
var RISK_STUDY_VERSION = "risk-study-net-equity-v1";
var definitions = Object.freeze([
  "\u6E90\u56E0\u5B50=\u672C\u6839\u51C0\u6743\u76CA/\u4E0A\u6839\u51C0\u6743\u76CA\uFF0C\u542B\u521D\u59CB\u672C\u91D1\u951A\u70B9\uFF1B\u8D44\u91D1\u6309\u6BCF\u6B65\u4E58\u9664\u540E\u5411\u4E0B\u820D\u5165\u81F318\u4F4D\uFF0C\u5F52\u96F6\u5438\u6536\u3002",
  "\u5206\u4F4Dnearest-rank=ceil(\u5206\u4F4D\u767E\u5206\u6BD4\xD7\u8DEF\u5F84\u6570/100)-1\uFF1B\u56DE\u64A4\u5206\u4F4D\u548C\u7EC8\u503C\u5206\u4F4D\u72EC\u7ACB\u6392\u5E8F\uFF0C\u4E0D\u4EE3\u8868\u540C\u4E00\u6761\u8DEF\u5F84\u3002",
  "\u56DE\u64A4\u6309\u542B\u521D\u59CB\u672C\u91D1\u7684\u5386\u53F2\u6743\u76CA\u5CF0\u503C\u8BA1\u7B97\uFF0C\u91D1\u989D\u548C\u5206\u6570\u7528BigInt\uFF0C\u4E0D\u4EE3\u8868K\u7EBF\u6839\u5185\u98CE\u9669\u3002",
  "\u6700\u7EC8\u4E8F\u635F\u9891\u7387=\u672B\u6743\u76CA<\u672C\u91D1\u7684\u8DEF\u5F84\u6570/\u603B\u8DEF\u5F84\u6570\uFF1B\u9608\u503C\u9891\u7387=\u4EFB\u4E00\u6A21\u62DF\u6B65\u6743\u76CA<=floor(\u521D\u59CB\u672C\u91D1\xD7\u9608\u503C%)/\u603B\u8DEF\u5F84\u6570\u3002",
  "\u9608\u503C\u76F8\u5BF9\u4E8E\u521D\u59CB\u672C\u91D1\uFF0C\u4E0D\u662F\u4ECE\u5CF0\u503C\u56DE\u64A4\uFF1B\u5F52\u96F6\u542B18\u4F4D\u820D\u5165\uFF1B0\u6B21\u53EA\u662F\u672C\u6279\u6B21\u672A\u89C2\u6D4B\u3002",
  "\u76F4\u65B9\u56FE\u5DE6\u95ED\u53F3\u5F00\u3001\u6700\u540E\u4E00\u7EC4\u542B\u6700\u5927\u503C\uFF1B\u9000\u5316\u5355\u503C\u5206\u5E03\u53EA\u6709\u4E00\u4E2A\u7B49\u7AEF\u70B9\u7EC4\uFF1B\u663E\u793A\u70B9\u62BD\u6837\u4E0D\u6539\u53D8\u5168\u6B65\u7EDF\u8BA1\u3002"
]);
function sourcePreview(e) {
  const p = e.payload, m = p.result.manifest, s = p.statistics;
  return {
    id: e.id,
    name: e.name,
    symbol: m.symbol,
    source: p.dataset.source.label,
    periods: m.signals.length,
    intervalMs: m.intervalMs,
    startUtcMs: p.dataset.candles[0].timestampUtcMs,
    endUtcMs: p.dataset.candles.at(-1).timestampUtcMs + m.intervalMs,
    initialCash: m.config.initialCash,
    fees: s.fees,
    realizedPnl: s.realizedPnl,
    unrealizedPnl: s.unrealizedPnl,
    completedTrades: s.completedTrades.length,
    winRate: s.winRate,
    config: m.config,
    risk: m.risk,
    strategy: m.strategy.config,
    payloadHash: e.payloadHash,
    dataHash: m.dataHash,
    runHash: m.runHash,
    fileHash: m.sourceFileSha256,
    warnings: p.dataset.quality.issues.map((q) => q.code + "\uFF1A" + q.message)
  };
}
function analyze(payload, identity, settings, progress) {
  const m = payload.result.manifest;
  if (!m.strategy) throw new Error("\u4EC5\u652F\u6301\u6B63\u5F0F\u4E09\u7B56\u7565\u4FDD\u5B58\u5B9E\u9A8C\u3002");
  const source = {
    identity: { ...identity },
    input: JSON.parse(
      JSON.stringify({
        dataset: payload.dataset,
        config: m.config,
        risk: m.risk,
        strategy: m.strategy.config,
        completedThroughUtcMs: m.completedThroughUtcMs
      })
    ),
    dataHash: m.dataHash,
    runHash: m.runHash,
    engineVersion: m.algorithmVersion,
    conversionVersion: m.conversionVersion,
    statisticsVersion: payload.statistics.version
  };
  const e = { schemaVersion: 1, ...identity, payload };
  return {
    version: RISK_STUDY_VERSION,
    source,
    preview: JSON.parse(JSON.stringify(sourcePreview(e))),
    simulation: simulateEquity(
      payload.statistics.curve.map((p) => p.equity),
      settings,
      progress
    ),
    definitions,
    disclaimer: DISCLAIMER
  };
}
var text2 = (v, max) => typeof v === "string" && !!v.trim() && v.length <= max;
function assertRiskStudy(value) {
  const e = value;
  if (!e || e.format !== "riverlab-risk-study" || e.schemaVersion !== 1 || !text2(e.id, 100) || !text2(e.name, 160) || !Number.isSafeInteger(e.createdUtcMs) || e.createdUtcMs < 0 || e.createdUtcMs > 41024448e5 || !Number.isFinite(e.elapsedMs) || e.elapsedMs < 0 || !e.payload || e.payload.version !== RISK_STUDY_VERSION || e.payload.disclaimer !== DISCLAIMER || contentHash(e.payload) !== e.payloadHash)
    throw new Error("\u98CE\u9669\u62A5\u544A\u683C\u5F0F\u3001\u7248\u672C\u6216\u6821\u9A8C\u65E0\u6548\uFF1B\u672A\u4FEE\u590D\u3002");
}
function verifyRiskStudy(value, progress, observeReplay) {
  assertRiskStudy(value);
  const s = value.payload.source, i = s.identity;
  if (s.engineVersion !== ALGORITHM_VERSION || s.conversionVersion !== CONVERSION_VERSION || s.statisticsVersion !== STATISTICS_VERSION || !i || !text2(i.id, 100) || !text2(i.name, 160) || !Number.isSafeInteger(i.createdUtcMs) || i.createdUtcMs < 0 || i.createdUtcMs > 41024448e5 || !Number.isFinite(i.elapsedMs) || i.elapsedMs < 0)
    throw new Error("\u6E90\u5B9E\u9A8C\u8EAB\u4EFD\u6216\u7B97\u6CD5\u7248\u672C\u4E0D\u652F\u6301\u3002");
  const payload = runExperiment(s.input);
  if (contentHash(payload) !== i.payloadHash)
    throw new Error("\u6E90\u5B9E\u9A8C\u5FEB\u7167\u4E0D\u80FD\u6309\u539Fhash\u590D\u73B0\u3002");
  const actual = analyze(
    payload,
    i,
    value.payload.simulation.settings,
    progress
  );
  if (canonicalJson(actual) !== canonicalJson(value.payload))
    throw new Error("\u98CE\u9669\u62A5\u544A\u91CD\u7B97\u4E0D\u4E00\u81F4\uFF1B\u672A\u81EA\u52A8\u4FEE\u590D\u3002");
  observeReplay?.({
    ...value,
    payload: actual,
    payloadHash: contentHash(actual)
  });
  return value;
}
function summarizeRisk(e) {
  return {
    id: e.id,
    name: e.name,
    createdUtcMs: e.createdUtcMs,
    payloadHash: e.payloadHash,
    sourceName: e.payload.preview.name,
    symbol: e.payload.preview.symbol
  };
}

// src/infrastructure/desktop-repository.ts
var chunkBytes = 1024 * 1024;
var maxBodyBytes = 256 * chunkBytes;

// src/infrastructure/advanced-store.ts
function checkSummary(summary) {
  assertMetadata(summary);
  if (typeof summary.reportHash !== "string" || !digestPattern.test(summary.reportHash))
    throw new Error("\u9AD8\u7EA7\u7814\u7A76\u62A5\u544A\u6458\u8981\u635F\u574F\u3002");
}

// src/infrastructure/experiment-store.ts
function assertExperimentSummary(row) {
  if (!row || typeof row.id !== "string" || !row.id.length || row.id.length > 100 || typeof row.name !== "string" || !row.name.trim() || row.name.length > 160 || typeof row.symbol !== "string" || !row.symbol.length || row.symbol.length > 80 || !Number.isSafeInteger(row.createdUtcMs) || row.createdUtcMs < 0 || row.createdUtcMs > 41024448e5 || typeof row.payloadHash !== "string" || !/^[a-f0-9]{64}$/.test(row.payloadHash) || typeof row.runHash !== "string" || !/^[a-f0-9]{64}$/.test(row.runHash) || !["ma", "rsi", "breakout", "rules"].includes(row.strategy))
    throw new Error("\u5B9E\u9A8C\u6458\u8981\u635F\u574F\u3002");
}

// src/infrastructure/dataset-store.ts
var MAX_BACKUP_BYTES = 20 * 1024 * 1024;

// src/infrastructure/market-regime-store.ts
function checkSummary2(row) {
  if (!row || typeof row.id !== "string" || !row.id.trim() || row.id.length > 100 || typeof row.name !== "string" || !row.name.trim() || row.name.length > 160 || !Number.isSafeInteger(row.createdUtcMs) || row.createdUtcMs < 0 || row.createdUtcMs > 41024448e5 || typeof row.reportHash !== "string" || !/^[a-f0-9]{64}$/.test(row.reportHash))
    throw new Error("\u5E02\u573A\u72B6\u6001\u62A5\u544A\u6458\u8981\u635F\u574F\u3002");
}

// src/infrastructure/replay-store.ts
function checkSummary3(r) {
  if (!r || typeof r.id !== "string" || !r.id || r.id.length > 100 || typeof r.name !== "string" || !r.name.trim() || r.name.length > 160 || typeof r.symbol !== "string" || !r.symbol.length || r.symbol.length > 80 || !Number.isSafeInteger(r.cursor) || r.cursor < 1 || r.cursor > 5e4 || !Number.isSafeInteger(r.createdUtcMs) || r.createdUtcMs < 0 || r.createdUtcMs > 41024448e5 || typeof r.payloadHash !== "string" || !/^[a-f0-9]{64}$/.test(r.payloadHash))
    throw new Error("\u56DE\u653E\u6458\u8981\u635F\u574F\uFF0C\u672A\u6253\u5F00\u6216\u4FEE\u590D\u3002");
}

// src/infrastructure/risk-store.ts
function checkSummary4(s) {
  if (!s || typeof s.id !== "string" || !s.id || s.id.length > 100 || typeof s.name !== "string" || !s.name.trim() || s.name.length > 160 || typeof s.symbol !== "string" || !s.symbol.trim() || s.symbol.length > 80 || typeof s.sourceName !== "string" || !s.sourceName.trim() || s.sourceName.length > 160 || !Number.isSafeInteger(s.createdUtcMs) || s.createdUtcMs < 0 || s.createdUtcMs > 41024448e5 || typeof s.payloadHash !== "string" || !/^[a-f0-9]{64}$/.test(s.payloadHash))
    throw new Error("\u98CE\u9669\u6458\u8981\u635F\u574F\uFF0C\u672A\u81EA\u52A8\u4FEE\u590D\u3002");
}

// src/infrastructure/snapshot-validation.ts
function checkSummary5(kind, value) {
  switch (kind) {
    case "dataset":
      return assertDatasetSummary(value);
    case "experiment":
      return assertExperimentSummary(value);
    case "replay":
      return checkSummary3(value);
    case "risk":
      return checkSummary4(value);
    case "portfolio":
    case "shared_pool":
      return assertPortfolioSummary(value);
    case "regime":
      return checkSummary2(value);
    case "advanced":
      return checkSummary(value);
    case "rule":
      throw new Error("\u89C4\u5219\u5E93\u6CA1\u6709\u72EC\u7ACB\u7684\u6458\u8981\u5B58\u50A8\u3002");
  }
}
function sortedSummary(value) {
  const copies = /* @__PURE__ */ new WeakMap();
  const parents = /* @__PURE__ */ new WeakSet();
  function visit(node, depth) {
    if (!node || typeof node !== "object") return node;
    if (depth > 64 || parents.has(node))
      throw new Error("\u6458\u8981\u542B\u5FAA\u73AF\u5F15\u7528\u6216\u5D4C\u5957\u8D85\u8FC7\u683C\u5F0F\u4E0A\u9650\u3002");
    const previous = copies.get(node);
    if (previous) return previous;
    parents.add(node);
    let result;
    if (Array.isArray(node)) {
      result = node.map((item) => visit(item, depth + 1));
    } else if (Object.getPrototypeOf(node) === Object.prototype) {
      const record = node;
      result = Object.fromEntries(
        Object.keys(record).sort().map((key) => [key, visit(record[key], depth + 1)])
      );
    } else {
      result = node;
    }
    parents.delete(node);
    copies.set(node, result);
    return result;
  }
  return visit(value, 0);
}
async function summaryFingerprint(kind, summary) {
  const digest4 = await fingerprintSnapshotValue(
    kind,
    "summary",
    sortedSummary(summary)
  );
  return digest4.projectionSha256 + "/" + digest4.cloneSha256;
}
function reportSummary({
  id,
  name,
  createdUtcMs,
  reportHash
}) {
  return { id, name, createdUtcMs, reportHash };
}
var ReplaySourceError = class extends Error {
};
var experimentFields = [
  "schemaVersion",
  "id",
  "name",
  "createdUtcMs",
  "elapsedMs",
  "payloadHash",
  "payload"
];
var riskFields = [...experimentFields, "format"];
function checkEnvelope(value, fields2) {
  if (!value || typeof value !== "object" || Object.keys(value).length !== fields2.length || fields2.some((field3) => !Object.hasOwn(value, field3)))
    throw new Error("\u7814\u7A76\u6B63\u6587\u9876\u5C42\u5B57\u6BB5\u7F3A\u5931\u6216\u542B\u4E0D\u652F\u6301\u7684\u5B57\u6BB5\u3002");
}
var SnapshotValidation = class {
  constructor(options) {
    this.options = options;
    if (!Number.isSafeInteger(options.observedUtcMs) || options.observedUtcMs < 0 || options.observedUtcMs > 41024448e5)
      throw new Error("\u5FEB\u7167\u6821\u9A8C\u65F6\u523B\u65E0\u6548\u3002");
  }
  options;
  pairs = /* @__PURE__ */ new Map();
  datasetIds = /* @__PURE__ */ new Set();
  checkCompletion(end) {
    if (!Number.isSafeInteger(end) || end > this.options.observedUtcMs)
      throw new Error("\u7814\u7A76\u5B8C\u6210\u65F6\u523B\u65E0\u6548\u6216\u665A\u4E8E\u5FEB\u7167\u6821\u9A8C\u65F6\u523B\u3002");
  }
  async verifyBody(kind, value, readDataset) {
    const { observedUtcMs, observeReplay } = this.options;
    const observe = observeReplay && ((rebuilt) => observeReplay(kind, value, rebuilt));
    switch (kind) {
      case "dataset": {
        assertDataset(value);
        validateSnapshotFields(value);
        return summarizeDataset(value);
      }
      case "rule": {
        const verified = verifyRuleRecord(value);
        if (observe) observe(sealRule(verified.rule, verified));
        return void 0;
      }
      case "experiment": {
        checkEnvelope(value, experimentFields);
        const verified = verifyExperiment(value, observe);
        this.checkCompletion(
          verified.payload.result.manifest.completedThroughUtcMs
        );
        validateSnapshotFields(verified.payload.dataset);
        return summarizeExperiment(verified);
      }
      case "replay": {
        assertReplayCheckpoint(value);
        const id = value.payload.datasetId;
        if (!this.datasetIds.has(id) || !readDataset)
          throw new ReplaySourceError("\u540C\u4E00\u5FEB\u7167\u4E2D\u7F3A\u5C11\u5DF2\u6821\u9A8C\u7684\u539F\u6570\u636E\u96C6\u3002");
        const dataset = await readDataset(id);
        assertDataset(dataset);
        if (dataset.id !== id || dataset.file.sha256 !== value.payload.sourceFileSha256 || dataset.symbol !== value.payload.symbol)
          throw new ReplaySourceError(
            "\u539F\u6570\u636E\u96C6 ID\u3001\u4EA4\u6613\u5BF9\u6216\u6765\u6E90\u6587\u4EF6 SHA-256 \u4E0D\u4E00\u81F4\u3002"
          );
        const restored = ReplaySession.restore(dataset, value);
        if (observe) {
          const { id: id2, name, createdUtcMs } = value;
          observe(restored.checkpoint({ id: id2, name, createdUtcMs }));
        }
        return summarizeReplay(value);
      }
      case "risk": {
        checkEnvelope(value, riskFields);
        const verified = verifyRiskStudy(value, void 0, observe);
        this.checkCompletion(
          verified.payload.source.input.completedThroughUtcMs
        );
        validateSnapshotFields(verified.payload.source.input.dataset);
        return summarizeRisk(verified);
      }
      case "portfolio":
        return summarizePortfolio(
          verifyPortfolioExperiment(value, observedUtcMs, observe)
        );
      case "shared_pool":
        return summarizePortfolio(
          verifySharedPoolExperiment(value, observedUtcMs, observe)
        );
      case "regime": {
        const rebuilt = verifyRegimeReport(value, observedUtcMs);
        observe?.(rebuilt);
        return reportSummary(rebuilt);
      }
      case "advanced": {
        const rebuilt = verifyAdvancedReport(value, observedUtcMs);
        observe?.(rebuilt);
        return reportSummary(rebuilt);
      }
    }
  }
  async accept(kind, role, key, value, readDataset) {
    const issue = (code, message2) => [
      { kind, role, key, code, message: message2 }
    ];
    if (typeof key !== "string" || !key.length || !value || typeof value !== "object" || !Object.hasOwn(value, "id") || value.id !== key)
      return issue(
        "invalidKey",
        "\u5B9E\u9645\u4E3B\u952E\u4E0E\u8BB0\u5F55\u5185\u90E8 ID \u7F3A\u5931\u3001\u7C7B\u578B\u9519\u8BEF\u6216\u4E0D\u4E00\u81F4\u3002"
      );
    if (kind === "rule" && role === "summary")
      return issue("invalidSummary", "\u89C4\u5219\u5E93\u53EA\u80FD\u5177\u6709 versions \u6B63\u6587\u5B58\u50A8\u3002");
    let rows = this.pairs.get(kind);
    if (!rows) {
      rows = /* @__PURE__ */ new Map();
      this.pairs.set(kind, rows);
    }
    const pair = rows.get(key) ?? {};
    if (pair[role] !== void 0)
      return issue("duplicateKey", "\u540C\u4E00\u5B58\u50A8\u91CD\u590D\u51FA\u73B0\u6B64\u4E3B\u952E\u3002");
    rows.set(key, pair);
    pair[role] = null;
    if (kind === "rule" && rows.size > 100)
      return issue("ruleLimit", "\u7B56\u7565\u5E93\u8D85\u8FC7\u65E2\u6709\u7684 100 \u7248\u672C\u9884\u7B97\u3002");
    try {
      const summary = role === "body" ? await this.verifyBody(kind, value, readDataset) : value;
      if (kind === "rule") return [];
      checkSummary5(kind, summary);
      pair[role] = await summaryFingerprint(kind, summary);
      if (kind === "dataset" && role === "body") this.datasetIds.add(key);
      if (pair.body && pair.summary && pair.body !== pair.summary)
        return issue(
          "summaryMismatch",
          "\u5B9E\u5B58\u6458\u8981\u4E0E\u5DF2\u6821\u9A8C\u6B63\u6587\u7684\u6D3E\u751F\u6458\u8981\u4E0D\u4E00\u81F4\u3002"
        );
      return [];
    } catch (error) {
      const code = error instanceof ReplaySourceError ? "replaySource" : role === "body" ? "invalidBody" : "invalidSummary";
      return issue(
        code,
        error instanceof Error ? error.message : "\u8BB0\u5F55\u672A\u901A\u8FC7\u9886\u57DF\u6821\u9A8C\u3002"
      );
    }
  }
  finish(kind) {
    const rows = this.pairs.get(kind);
    this.pairs.delete(kind);
    if (kind === "rule" || !rows) return [];
    const issues = [];
    let missing = 0;
    for (const [key, pair] of rows) {
      if (pair.body !== void 0 && pair.summary !== void 0) continue;
      missing++;
      if (issues.length >= 16) continue;
      const bodyMissing = pair.body === void 0;
      issues.push({
        kind,
        key,
        role: bodyMissing ? "summary" : "body",
        code: bodyMissing ? "missingBody" : "missingSummary",
        message: bodyMissing ? "\u5B64\u7ACB\u6458\u8981\u7F3A\u5C11\u540C\u4E3B\u952E\u6B63\u6587\u3002" : "\u6B63\u6587\u7F3A\u5C11\u540C\u4E3B\u952E\u5B9E\u5B58\u6458\u8981\u3002"
      });
    }
    if (missing > issues.length)
      issues[issues.length - 1].message += ` \u6B64\u5E93\u5171 ${missing} \u6761\u914D\u5BF9\u7F3A\u5931\uFF0C\u5217\u51FA\u524D ${issues.length} \u6761\u3002`;
    return issues;
  }
};

// scripts/phase6c/recompute.ts
var kinds = Object.keys(layouts);
function digest3(text3) {
  return createHash("sha256").update(text3).digest("hex");
}
function message(e) {
  return e instanceof Error ? e.message : String(e);
}
async function verifyCandidate(candidate2, decoded2) {
  const started = performance.now();
  const manifest = JSON.parse(
    readFileSync(join(decoded2, "manifest.json"), "utf8")
  );
  const expected = /* @__PURE__ */ new Map();
  const byKind = new Map(kinds.map((kind) => [kind, /* @__PURE__ */ new Set()]));
  const keyOf = (kind, role, id) => JSON.stringify([kind, role, id]);
  assert2.equal(manifest.members.length, manifest.rows);
  for (const member of manifest.members) {
    const kind = kinds.find((kind2) => layouts[kind2][0] === member.database);
    assert2(
      kind && member.key === member.id && member.key.length > 0,
      "\u539F\u59CB\u6210\u5458\u8EAB\u4EFD\u65E0\u6548"
    );
    assert2(
      member.role === "body" ? member.store === layouts[kind][1] : member.role === "summary" && kind !== "rule" && member.store === "summaries",
      "\u539F\u59CB\u89D2\u8272/\u5B58\u50A8\u4E0D\u5339\u914D"
    );
    const key = keyOf(kind, member.role, member.id);
    assert2(!expected.has(key), "\u539F\u6E05\u5355\u91CD\u590D\u952E " + key);
    expected.set(key, member);
    byKind.get(kind).add(member.id);
  }
  const records = [];
  const errors = [];
  const db = new DatabaseSync(candidate2, {
    readOnly: true,
    allowExtension: false
  });
  try {
    db.exec("PRAGMA query_only=ON; PRAGMA trusted_schema=OFF; BEGIN");
    assert2.equal(
      db.prepare("PRAGMA application_id").get()?.application_id,
      1381387330
    );
    assert2.equal(db.prepare("PRAGMA user_version").get()?.user_version, 1);
    const descriptor2 = db.prepare(
      "SELECT CAST(descriptor AS BLOB) AS bytes,projection_sha256,clone_sha256 FROM migration_members WHERE kind=? AND id=? AND role=? AND typeof(descriptor)='text' AND octet_length(descriptor)<=20971520"
    );
    const body = db.prepare(
      "SELECT CAST(body AS BLOB) AS bytes FROM records WHERE kind=? AND id=? AND typeof(body)='text' AND octet_length(body)<=268435456"
    );
    const summary = db.prepare(
      "SELECT CAST(summary AS BLOB) AS bytes FROM summaries WHERE kind=? AND id=? AND typeof(summary)='text' AND octet_length(summary)<=20971520"
    );
    const decode = (bytes) => new TextDecoder("utf-8", { fatal: true, ignoreBOM: true }).decode(bytes);
    const read = (kind, id) => {
      const found = body.get(kind, id);
      if (!found) {
        assert2(
          !byKind.get(kind)?.has(id),
          "\u6E90\u6E05\u5355\u5185\u7684\u5173\u8054\u6B63\u6587\u672A\u80FD\u4ECE\u5019\u9009\u8BFB\u53D6 " + kind + " " + id
        );
        return void 0;
      }
      return JSON.parse(decode(found.bytes));
    };
    async function memberValue(kind, id, role) {
      const member = expected.get(keyOf(kind, role, id));
      assert2(member, "\u7F3A\u5C11\u539F\u59CB\u6210\u5458 " + role);
      const data = (role === "body" ? body : summary).get(kind, id)?.bytes;
      const desc = descriptor2.get(kind, id, role);
      assert2(
        data instanceof Uint8Array && desc?.bytes instanceof Uint8Array,
        "SQLite \u6210\u5458\u7F3A\u5931\u6216\u8D85\u8FC7\u5BB9\u91CF"
      );
      assert2.equal(data.length, member.projectionBytes);
      assert2.equal(digest3(data), member.projectionSha256);
      assert2.equal(desc.bytes.length, member.cloneBytes);
      assert2.equal(digest3(desc.bytes), member.cloneSha256);
      assert2.equal(desc.projection_sha256, member.projectionSha256);
      assert2.equal(desc.clone_sha256, member.cloneSha256);
      const value = restoreSnapshotValue(decode(data), decode(desc.bytes));
      const actual = await fingerprintSnapshotValue(kind, role, value);
      assert2.equal(
        actual.projectionSha256,
        member.projectionSha256,
        "\u8FD8\u539F\u540E\u7684\u6295\u5F71\u4E0E\u539F SHA \u4E0D\u7B26"
      );
      assert2.equal(
        actual.cloneSha256,
        member.cloneSha256,
        "\u8FD8\u539F\u540E\u7684\u5171\u4EAB\u5F15\u7528\u3001\u663E\u5F0F undefined \u6216\u952E\u5E8F\u4E0E\u539F SHA \u4E0D\u7B26"
      );
      return value;
    }
    const rules = byKind.get("rule");
    for (const [table, role] of [
      ["records", "body"],
      ["summaries", "summary"],
      ["migration_members", "member"]
    ]) {
      const seen = /* @__PURE__ */ new Set();
      for (const row of db.prepare(
        "SELECT kind,id" + (role === "member" ? ",role" : "") + " FROM " + table
      ).iterate()) {
        const kind = row.kind, id = row.id;
        const sourceRole = role === "member" ? row.role : role;
        const physicalKey = keyOf(kind, sourceRole, id);
        if (seen.has(physicalKey))
          errors.push(
            "SQLite \u91CD\u590D\u884C " + JSON.stringify([table, kind, id, sourceRole])
          );
        seen.add(physicalKey);
        if (!expected.has(keyOf(kind, sourceRole, id)) && !(role === "summary" && kind === "rule" && rules.has(id)))
          errors.push(
            "SQLite \u989D\u5916\u884C " + JSON.stringify([table, kind, id, sourceRole])
          );
      }
    }
    let current;
    const validation = new SnapshotValidation({
      observedUtcMs: manifest.source.barrierUtcMs,
      observeReplay(kind, original, rebuilt) {
        const paths = [...comparisonPaths[kind]];
        if (kind === "portfolio") {
          const assets = field(original, "result.assets");
          for (const index of assets.keys())
            for (const metric of [
              "result.manifest",
              "result.orders",
              "result.fills",
              "result.closes",
              "statistics",
              "fees"
            ])
              paths.push("result.assets." + index + "." + metric);
        } else if (kind === "advanced") {
          const folds = field(original, "result.folds");
          for (const index of folds.keys())
            paths.push(
              "result.folds." + index + ".train",
              "result.folds." + index + ".test"
            );
        }
        for (const path of paths) {
          const before = field(original, path), after = field(rebuilt, path);
          const equal2 = isDeepStrictEqual(before, after);
          const result = { path, equal: equal2 };
          if (Array.isArray(before)) result.entries = before.length;
          if (typeof before === "string" && /^[a-f0-9]{64}$/.test(before))
            result.hash = before;
          current.comparisons.push(result);
          if (!equal2) current.errors.push("\u9010\u9879\u590D\u7B97\u4E0D\u7B26 " + path);
        }
        const equal = isDeepStrictEqual(original, rebuilt);
        current.comparisons.push({ path: "$", equal });
        if (!equal) current.errors.push("\u5B8C\u6574\u590D\u7B97\u5BF9\u8C61\u4E0E\u539F\u8BB0\u5F55\u4E0D\u4E00\u81F4");
      }
    });
    for (const kind of kinds) {
      for (const id of byKind.get(kind)) {
        const start = performance.now();
        current = {
          kind,
          id,
          status: "FAIL",
          mode: kind === "dataset" ? "source-data-validation" : kind === "rule" ? "rule-revision-verification" : "full-replay",
          comparisons: [],
          relations: [],
          errors: [],
          elapsedMs: 0,
          originalBusinessHashes: {},
          summaryVerified: false,
          sourceRows: []
        };
        records.push(current);
        try {
          const value = await memberValue(kind, id, "body");
          const sourceBody = expected.get(keyOf(kind, "body", id));
          current.sourceRows.push({
            role: "body",
            projectionSha256: sourceBody.projectionSha256,
            cloneSha256: sourceBody.cloneSha256
          });
          const issues = await validation.accept(
            kind,
            "body",
            id,
            value,
            async (datasetId) => memberValue("dataset", datasetId, "body")
          );
          for (const issue of issues)
            current.errors.push(issue.code + ": " + issue.message);
          if (!issues.length) {
            if (kind === "dataset") {
              const d = value;
              current.dataset = {
                schemaVersion: d.schemaVersion,
                candles: d.candles.length,
                coverage: "Stored OHLCV, identity, source metadata, quality counts, original body and summary. The RLIDB001 snapshot contains no raw CSV bytes."
              };
            }
            current.relations = relationships(kind, value, read);
            current.errors.push(
              ...current.relations.filter(
                (r) => r.status === "CONFLICT" || r.status === "MISSING"
              ).map((r) => r.status + " " + r.kind + " " + r.id)
            );
          }
          for (const path of hashes[kind])
            current.originalBusinessHashes[path] = field(value, path);
          if (kind === "rule") {
            const copied = summary.get(kind, id)?.bytes;
            assert2(copied instanceof Uint8Array);
            assert2.equal(
              digest3(copied),
              expected.get(keyOf(kind, "body", id)).projectionSha256,
              "\u89C4\u5219\u6D3E\u751F\u6458\u8981\u5FC5\u987B\u5B58\u50A8\u539F\u7248\u672C\u5168\u884C"
            );
            current.summaryVerified = true;
          } else {
            const saved = await memberValue(kind, id, "summary");
            const sourceSummary = expected.get(keyOf(kind, "summary", id));
            current.sourceRows.push({
              role: "summary",
              projectionSha256: sourceSummary.projectionSha256,
              cloneSha256: sourceSummary.cloneSha256
            });
            const issues2 = await validation.accept(kind, "summary", id, saved);
            current.summaryVerified = issues2.length === 0 && current.errors.length === 0;
            for (const issue of issues2)
              current.errors.push(issue.code + ": " + issue.message);
          }
        } catch (error) {
          current.errors.push(message(error));
        }
        current.status = current.errors.length ? "FAIL" : "PASS";
        current.elapsedMs = performance.now() - start;
      }
      for (const issue of validation.finish(kind))
        errors.push(JSON.stringify(issue));
    }
    db.exec("ROLLBACK");
  } finally {
    db.close();
  }
  return {
    status: errors.length || records.some((r) => r.status === "FAIL") ? "FAIL" : "PASS",
    sourceSha256: manifest.packageSha256,
    snapshotContentId: manifest.snapshotContentId,
    observedUtcMs: manifest.source.barrierUtcMs,
    elapsedMs: performance.now() - started,
    records,
    errors
  };
}
var [candidate, decoded, output] = process.argv.slice(2);
try {
  assert2(
    candidate && decoded && output && process.argv.length === 5,
    "\u7528\u6CD5\uFF1Anode recompute.mjs <\u5019\u9009\u5E93> <\u6B63\u5F0F\u89E3\u7801\u76EE\u5F55> <\u65B0\u62A5\u544A.json>"
  );
  const report = await verifyCandidate(candidate, decoded);
  writeFileSync(output, JSON.stringify(report, null, 2) + "\n", { flag: "wx" });
  if (report.status !== "PASS") process.exitCode = 1;
} catch (error) {
  console.error(message(error));
  process.exitCode = 1;
}
export {
  verifyCandidate
};
